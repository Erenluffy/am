import random
import asyncio
import os
import requests
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, CallbackQuery
from datetime import datetime, timedelta
from helper.database import DARKXSIDE78
from helper.utils import is_subscribed , not_joined
from config import *
import time
from config import Config
import aiohttp
from urllib.parse import quote
import string
from telegraph import upload_file
import logging
import pytz
from functools import wraps
import secrets
from typing import Dict, Optional
from helper.utils import is_subscribed, FORCE_MSG, FORCE_PIC
from helper.database import DARKXSIDE78 as db
# Enhanced logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)
@Client.on_callback_query(filters.regex("^reload$"))
async def reload_callback(client, query: CallbackQuery):
    """Handle reload callback for force subscription check"""
    user = query.from_user
    
    # Edit the message to show "Checking..." status
    try:
        # Try to edit caption if it's a photo message
        await query.message.edit_caption(
            caption="🔄 Checking subscription status..."
        )
    except:
        try:
            # Try to edit text if it's a text message
            await query.message.edit_text(
                text="🔄 Checking subscription status..."
            )
        except Exception as e:
            print(f"Error editing reload message: {e}")
            await query.answer("Error checking status", show_alert=True)
            return
    
    # Wait a moment to ensure Telegram updates
    await asyncio.sleep(1)
    
    # Check if user is now subscribed
    if await is_subscribed(client, user.id):
        try:
            await query.message.edit_caption(
                caption=f"✅ Thanks {user.mention}, you are now subscribed!\n\nTap /start to continue."
            )
        except:
            await query.message.edit_text(
                text=f"✅ Thanks {user.mention}, you are now subscribed!\n\nTap /start to continue."
            )
    else:
        # User still not subscribed, show the force sub message again
        channels = await db.show_channels()
        buttons = []
        active_channels = 0
        
        for channel_id in channels:
            try:
                # Check if channel mode is on
                channel_mode = await db.get_channel_mode(channel_id)
                if channel_mode == "off":
                    continue
                    
                chat = await client.get_chat(channel_id)
                if chat.username:
                    url = f"https://t.me/{chat.username}"
                else:
                    url = f"https://t.me/c/{str(channel_id)[4:]}"
                buttons.append([InlineKeyboardButton(text=chat.title, url=url)])
                active_channels += 1
            except Exception as e:
                print(f"Error getting chat {channel_id} for reload: {e}")
                continue
        
        # If no active channels, allow access
        if active_channels == 0:
            try:
                await query.message.edit_caption(
                    caption=f"✅ Thanks {user.mention}, you can now continue!\n\nTap /start to continue."
                )
            except:
                await query.message.edit_text(
                    text=f"✅ Thanks {user.mention}, you can now continue!\n\nTap /start to continue."
                )
            return
        
        buttons.append([InlineKeyboardButton(text='♻️ Reload', callback_data='reload')])
        
        try:
            await query.message.edit_caption(
                caption=FORCE_MSG.format(first=user.first_name),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except:
            await query.message.edit_text(
                text=FORCE_MSG.format(first=user.first_name),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        
        await query.answer(
            "❌ You still haven't joined all required channels!",
            show_alert=True
        )
MESSAGE_EFFECT_IDS = [
        # Latest working effect IDs (2024)
        5104841245755180586,  # 🔥 Fire effect
   #     5107584321108051014,  # 👍 Thumbs up effect
   #     5044134455711629726,  # ❤️ Heart effect
    #    5046509860389126642,  # 🎉 Celebration effect
    #    5104858069142078462,  # 👎 Thumbs down effect
    #    5046589136895476101,  # 💩 Poop effect
    #   5107584321108051014
        
    ]
# Global variables for manual mode
manual_rename_queue = {}
pending_manual_requests = {}

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Renaming modes constants
RENAMING_MODES = {
    "autorename": "Autorename - Use predefined template",
    "manual": "Manual - Custom name entry",
    "replace": "Replace - Swap specific text"
}
# Add this function to handle database reconnections
async def safe_db_operation(operation, *args, **kwargs):
    max_retries = 3
    for attempt in range(max_retries):
        try:
            return await operation(*args, **kwargs)
        except Exception as e:
            if attempt == max_retries - 1:
                raise e
            await asyncio.sleep(1 * (attempt + 1))
def check_ban_status(func):
    @wraps(func)
    async def wrapper(client, message, *args, **kwargs):
        user_id = message.from_user.id
        is_banned, ban_reason = await DARKXSIDE78.is_user_banned(user_id)
        if is_banned:
            await message.reply_text(
                f"**Yᴏᴜ ᴀʀᴇ ʙᴀɴɴᴇᴅ ғʀᴏᴍ ᴜsɪɴɢ ᴛʜɪs ʙᴏᴛ.**\n\n**Rᴇᴀsᴏɴ:** {ban_reason}"
            )
            return
        return await func(client, message, *args, **kwargs)
    return wrapper

# ==================== MODE SELECTION SYSTEM ====================
@Client.on_message(filters.command("mode") & filters.private)
@check_ban_status
async def renaming_mode_selection(client, message: Message):
    """Show renaming mode selection interface"""
    user_id = message.from_user.id
    current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "Autorename"
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"ᴀᴜᴛᴏʀᴇɴᴀᴍᴇ" + (" ✅" if current_mode == "autorename" else ""), callback_data="set_mode_autorename")],
        [InlineKeyboardButton(f"ᴍᴀɴᴜᴀʟ" + (" ✅" if current_mode == "manual" else ""), callback_data="set_mode_manual")],
        [InlineKeyboardButton(f"ʀᴇᴘʟᴀᴄᴇ" + (" ✅" if current_mode == "replace" else ""), callback_data="set_mode_replace")],
        [InlineKeyboardButton("Close", callback_data="close")]
    ])
    
    mode_info = {
        "autorename": "• **Auto Mode**: Files rename automatically using template\n• **Usage**: `/Room [template]`",
        "manual": "• **Manual Mode**: Enter custom name for each file\n• **Usage**: Send file → Enter name", 
        "replace": "• **Replace Mode**: Swap specific text in filenames\n• **Usage**: `/replace \"old\" \"new\"`"
    }
    
    caption = f"""**📳 Rename Mode**

**Current Mode:** `{current_mode.upper()}`

{mode_info[current_mode]}

💡 Select a mode below to change:
"""
    
    # Edit existing message if it's a callback, otherwise send new
    if hasattr(message, 'data'):  # It's a callback
        await message.edit_text(caption, reply_markup=keyboard, disable_web_page_preview=True)
    else:
        await message.reply_text(caption, reply_markup=keyboard, disable_web_page_preview=True)

# ==================== MODE HANDLING CALLBACKS ====================
@Client.on_callback_query(filters.regex(r"^set_mode_"))
async def set_renaming_mode_callback(client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    mode = callback_query.data.split("_")[2]
    
    await DARKXSIDE78.set_renaming_mode(user_id, mode)
    current_mode = await DARKXSIDE78.get_renaming_mode(user_id)
    
    # Update the keyboard with new selection
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"ᴀᴜᴛᴏʀᴇɴᴀᴍᴇ" + (" ✅" if current_mode == "autorename" else ""), callback_data="set_mode_autorename")],
        [InlineKeyboardButton(f"ᴍᴀɴᴜᴀʟ" + (" ✅" if current_mode == "manual" else ""), callback_data="set_mode_manual")],
        [InlineKeyboardButton(f"ʀᴇᴘʟᴀᴄᴇ" + (" ✅" if current_mode == "replace" else ""), callback_data="set_mode_replace")],
        [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")]
    ])
    
    mode_info = {
        "autorename": "• **ᴀᴜᴛᴏʀᴇɴᴀᴍᴇ ᴍᴏᴅᴇ**: Files rename automatically using template\n• **Usage**: `/Room [template]`",
        "manual": "• **ᴍᴀɴᴜᴀʟ ᴍᴏᴅᴇ**: Enter custom name for each file\n• **Usage**: Send file → Enter name",
        "replace": "• **ʀᴇᴘʟᴀᴄᴇ ᴍᴏᴅᴇ**: Swap specific text in filenames\n• **Usage**: `/replace \"old\" \"new\"`"
    }
    
    await callback_query.message.edit_text(
        text=f"""**✅ Mode Changed**

**Current Mode:** `{current_mode.upper()}`

{mode_info[current_mode]}

💡 Select a mode below to change:
""",
        reply_markup=keyboard,
        disable_web_page_preview=True
    )
    await callback_query.answer(f"Switched to {current_mode.title()} Mode")

# ==================== AUTO-UPDATE MODE DISPLAY ====================
@Client.on_message(filters.private & (filters.document | filters.video | filters.audio))
async def show_mode_indicator(client, message: Message):
    try:
        user_id = message.from_user.id
        
        # Check file size to prevent abuse
        if hasattr(message, message.media.value) and getattr(message, message.media.value).file_size > 500 * 1024 * 1024:  # 500MB limit
            await message.reply_text("❌ File too large. Maximum size is 500MB.")
            return
    except Exception as e:
        logger.error(f"Error max size fetch {user_id}: {e}")
    try:
        current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "autorename"
    except Exception as e:
        logger.error(f"Error fetching mode for user {user_id}: {e}")
        current_mode = "autorename"
    
    mode_messages = {
        "autorename": " **ᴀᴜᴛᴏʀᴇɴᴀᴍᴇ ᴍᴏᴅᴇ** - File will be renamed automatically",
        "manual": " **ᴍᴀɴᴜᴀʟ ᴍᴏᴅᴇ** - Please enter custom filename",
        "replace": " **ʀᴇᴘʟᴀᴄᴇ ᴍᴏᴅᴇ** - Text replacement will be applied"
    }
    
    if current_mode not in mode_messages:
        return
    
    try:
        indicator = await message.reply_text(
            f"{mode_messages[current_mode]}\n\n`/mode` to change mode"
        )
    except Exception as e:
        logger.error(f"Failed to send indicator for user {user_id}: {e}")
        return
    
    await asyncio.sleep(4)
    try:
        await indicator.delete()
    except Exception as e:
        logger.error(f"Failed to delete indicator for user {user_id}: {e}")

# ==================== MODE STATUS INDICATOR ====================
async def get_mode_status(user_id: int) -> str:
    try:
        current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "autorename"
        mode_icons = {"autorename": "🤖", "manual": "👤", "replace": "🔄"}
        return f"{mode_icons[current_mode]} {current_mode.upper()}"
    except Exception as e:
        logger.error(f"Database error in get_mode_status: {e}")
        return "🤖 AUTORENAME"
# ==================== AUTO-UPDATE MODE DISPLAY ====================
@Client.on_message(filters.private & (filters.document | filters.video | filters.audio))
async def show_mode_indicator(client, message: Message):
    """Show current mode when user sends a file"""
    user_id = message.from_user.id
    logger.info(f"Received file from user {user_id}, fetching mode")
    try:
        current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "autorename"
        logger.info(f"User {user_id} mode: {current_mode}")
    except Exception as e:
        logger.error(f"Error fetching mode for user {user_id}: {e}")
        current_mode = "autorename"
    
    mode_icons = {"autorename": "🤖", "manual": "👤", "replace": "🔄"}
    mode_messages = {
        "autorename": "🤖 **Auto Mode** - Using template",
        "manual": "👤 **Manual Mode**", 
        "replace": "🔄 **Replace Mode** - Text replacement"
    }
    
    if current_mode not in mode_messages:
        logger.error(f"Invalid mode {current_mode} for user {user_id}")
        return
    
    logger.info(f"Sending mode indicator for user {user_id}: {mode_messages[current_mode]}")
    try:
        indicator = await message.reply_text(
            f"{mode_messages[current_mode]}\n`/mode` to change"
        )
        logger.info(f"Sent indicator message {indicator.id} for user {user_id}")
    except Exception as e:
        logger.error(f"Failed to send indicator for user {user_id}: {e}")
        return
    
    await asyncio.sleep(3)
    try:
        await indicator.delete()
        logger.info(f"Deleted indicator message {indicator.id} for user {user_id}")
    except Exception as e:
        logger.error(f"Failed to delete indicator for user {user_id}: {e}")
        
# ==================== REPLACE COMMAND ====================
@Client.on_message(filters.command("replace") & filters.private)
@check_ban_status
async def set_replace_pattern_cmd(client, message: Message):
    user_id = message.from_user.id
    args = message.text.split(maxsplit=2)
    
    if len(args) < 3:
        await message.reply_text(
            "**🔧 Rᴇᴘʟᴀᴄᴇ Mᴏᴅᴇ Sᴇᴛᴜᴘ**\n\n"
            "**Usᴀɢᴇ:** `/replace \"old_text\" \"new_text\"`\n\n"
            "**ᴇxᴀᴍᴘʟᴇ:** `/replace \"S01\" \"Season 01\"`\n"
            "**ᴇxᴀᴍᴘʟᴇ:** `/replace \"x264\" \"HEVC\"`"
        )
        return
    
    old_text = args[1].strip('"\'')
    new_text = args[2].strip('"\'')
    
    await DARKXSIDE78.set_replace_pattern(user_id, old_text, new_text)
    await message.reply_text(f"**🔧 Rᴇᴘʟᴀᴄᴇ Pᴀᴛᴛᴇʀɴ Sᴇᴛ**\n\n**Oʟᴅ:** `{old_text}` → **Nᴇᴡ:** `{new_text}`")
# ==================== START COMMAND ====================
@Client.on_message(filters.private & filters.command("start"))
@check_ban_status
async def start(client, message: Message):
    user = message.from_user
    user_id = user.id
        
  # ✅ Check Force Subscription FIRST (priority check)
    if not await is_subscribed(client, user_id):
        return await not_joined(client, message)

    if len(message.command) > 1:
        arg = message.command[1]
        if arg.startswith("ref_"):
            referral_code = arg[4:]
            referrer = await DARKXSIDE78.col.find_one({"referral_code": referral_code})
            if referrer and referrer["_id"] != user_id:
                updated = await DARKXSIDE78.col.update_one(
                    {"_id": referrer["_id"]},
                    {"$addToSet": {"referrals": user_id}}
                )
                if updated.modified_count > 0:
                    await DARKXSIDE78.col.update_one(
                        {"_id": referrer["_id"]},
                        {"$inc": {"token": Config.REFER_TOKEN}}
                    )
                    try:
                        await client.send_message(
                            referrer["_id"],
                            f"**You received {Config.REFER_TOKEN} tokens for referring {user.mention}!**"
                        )
                    except Exception:
                        pass
        else:
            await handle_token_redemption(client, message, arg)
            return


    await DARKXSIDE78.add_user(client, message)
    # First text
    '''   # Send sticker in the middle
    sticker_msg = await message.reply_sticker("CAACAgUAAxkBAAKGiWkqENXbVp-gldEcRnPDTS6tLaJ5AAJICgAClA0IV8APF_-7z1a6HgQ")
    await asyncio.sleep(0.6)
    await sticker_msg.delete()

    m = await message.reply_text("🖤 ROOM awakens… all bends to my will.")
    await asyncio.sleep(0.6)
    # Edit the same message for second text
    await m.edit_text("⚔️ Shambles… swap positions, twist fate.")
    await asyncio.sleep(0.5)

    # Edit the same message for third text
    await m.edit_text("💀 None escape the Surgeon of Death.")
    await asyncio.sleep(0.5)

    # Delete the text message after dramatic sequence
    await m.delete()

    # Send final startup sticker
    final_sticker_msg = await message.reply_sticker(Config.START_STICKER)
    await asyncio.sleep(0.8)  # dramatic pause after sticker '''

    # 🔥 Dramatic Start Animation (Safe)
    try:
        sticker_msg = await message.reply_sticker("CAACAgUAAxkBAAKGiWkqENXbVp-gldEcRnPDTS6tLaJ5AAJICgAClA0IV8APF_-7z1a6HgQ")
        await asyncio.sleep(0.7)
        await sticker_msg.delete()
    except:
        pass

    try:
        m = await message.reply_text("🖤 ROOM awakens… all bends to my will.")
        await asyncio.sleep(0.7)

        await m.edit("⚔️ Shambles… swap positions, twist fate.")
        await asyncio.sleep(0.6)

        await m.edit("💀 None escape the Surgeon of Death.")
        await asyncio.sleep(0.6)

        await m.delete()
    except Exception:
        pass

    # 🔥 Final Sticker (Stable)
    try:
        await message.reply_sticker(Config.START_STICKER)
    except:
        await message.reply_text("⚔️ **ROOM... Shambles!**")

    buttons = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("⚔️ ", callback_data="help"),
            InlineKeyboardButton("🩺 ", callback_data="admin_cmds"),
            InlineKeyboardButton("💉 ", callback_data="settings_menu")
        ],
    #    [
    #        InlineKeyboardButton("⚓ ᴜᴘᴅᴀᴛᴇꜱ", url="https://t.me/Rbotz"),
    #        InlineKeyboardButton("🏴 ꜱᴜᴘᴘᴏʀᴛ", url="https://t.me/+sT7FKCfO9DRkYTBl")
    #    ],
    #    [
    #        InlineKeyboardButton("💀 ᴀʙᴏᴜᴛ", callback_data="about"),
    #        InlineKeyboardButton("🪙 ᴘʀᴇᴍɪᴜᴍ", callback_data="premiumx")
    #    ],
        [
            InlineKeyboardButton("⚔️ ᴏᴘᴇʀᴀᴛɪᴏɴ ᴘᴀɴᴇʟ", callback_data="help")
        ]
    ])

    if Config.START_PIC:
        try:
            # Try with message effect (newer Pyrogram versions)
            await message.reply_photo(
                Config.START_PIC,
                caption=Txt.START_TXT.format(user.mention),
                reply_markup=buttons,
                effect_id=5104841245755180586  # Correct parameter name
            )
        except TypeError:
            # Fallback without message effect (older Pyrogram versions)
            await message.reply_photo(
                Config.START_PIC,
                caption=Txt.START_TXT.format(user.mention),
                reply_markup=buttons
            )
    else:
        await message.reply_text(
            text=Txt.START_TXT.format(user.mention),
            reply_markup=buttons,
            disable_web_page_preview=True
        )

# ==================== CALLBACK HANDLERS ====================
#@Client.on_callback_query(filters.regex(r"^renaming_mode$"))
#async def renaming_mode_callback(client, callback_query: CallbackQuery):
 #   await renaming_mode_selection(client, callback_query.message)
  #  await callback_query.answer()

@Client.on_callback_query()
async def cb_handler(client, query: CallbackQuery):
    data = query.data
    user_id = query.from_user.id

    if data == "home":
        # Fetch the current renaming mode from the database
        current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "autorename"
        mode_display = current_mode.title()  # Capitalize the mode for display (e.g., Autorename, Manual, Replace)

        await query.message.edit_text(
            text=Txt.START_TXT.format(query.from_user.mention),
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
                
                    [
                        InlineKeyboardButton("⚔️ ", callback_data="help"),
                        InlineKeyboardButton("🩺 ", callback_data="admin_cmds"),
                        InlineKeyboardButton("💉 ", callback_data="settings_menu")
                    ],
                    [
                        InlineKeyboardButton("⚓ ᴜᴘᴅᴀᴛᴇꜱ", url="https://t.me/Rbotz"),
                        InlineKeyboardButton("🩸 ꜱᴜᴘᴘᴏʀᴛ", url="https://t.me/+sT7FKCfO9DRkYTBl")
                    ],
                    [
                        InlineKeyboardButton("☠ ᴀʙᴏᴜᴛ", callback_data="about"),
                        InlineKeyboardButton("⚜ Premium", callback_data="premiumx")
                    ],
                    [
                        InlineKeyboardButton("⚔️ ᴏᴘᴇʀᴀᴛɪᴏɴ ᴘᴀɴᴇʟ", callback_data="help")
                    ]
            ])
        )
    elif data == "caption":
        await query.message.edit_text(
            text=Txt.CAPTION_TXT,
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")]
            ])
        )
    elif data == "renaming_mode":
            # Edit the same message instead of sending new one
            current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "autorename"
            
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(f"ᴀᴜᴛᴏʀᴇɴᴀᴍᴇ" + (" ✅" if current_mode == "autorename" else ""), callback_data="set_mode_autorename")],
                [InlineKeyboardButton(f"ᴍᴀɴᴜᴀʟ" + (" ✅" if current_mode == "manual" else ""), callback_data="set_mode_manual")],
                [InlineKeyboardButton(f"ʀᴇᴘʟᴀᴄᴇ" + (" ✅" if current_mode == "replace" else ""), callback_data="set_mode_replace")],
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")]
            ])
            
            mode_info = {
                "autorename": "• **ᴀᴜᴛᴏʀᴇɴᴀᴍᴇ ᴍᴏᴅᴇ**: Files rename automatically using template\n• **Usage**: `/Room [template]`",
                "manual": "• **ᴍᴀɴᴜᴀʟ ᴍᴏᴅᴇ**: Enter custom name for each file\n• **Usage**: Send file → Enter name",
                "replace": "• **ʀᴇᴘʟᴀᴄᴇ ᴍᴏᴅᴇ**: Swap specific text in filenames\n• **Usage**: `/replace \"old\" \"new\"`"
            }
            
            await query.message.edit_text(
                text=f"""**📳 ʀᴇɴᴀᴍᴇ ᴍᴏᴅᴇ**
    
    **Current Mode:** `{current_mode.upper()}`
    
    {mode_info[current_mode]}
    
    💡 ꜱᴇʟᴇᴄᴛ ᴀ ᴍᴏᴅᴇ ʙᴇʟᴏᴡ ᴛᴏ ᴄʜᴀɴɢᴇ:
    """,
                reply_markup=keyboard,
                disable_web_page_preview=True
            )
            await query.answer()
    elif data == "admin_cmds":
        await query.message.edit_text(
            text=Txt.ADMIN_TXT,
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")]
            ])
        )
    elif data == "help":
        # Get current mode for display in help menu
        current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "autorename"
        mode_display = current_mode.upper()

        await query.message.edit_text(
            text=Txt.HELP_TXT.format(client.mention),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴀᴜᴛᴏ ʀᴇɴᴀᴍᴇ ғᴏʀᴍᴀᴛ", callback_data='file_names')],
                [InlineKeyboardButton('ᴛʜᴜᴍʙɴᴀɪʟ', callback_data='thumbnail'), InlineKeyboardButton('ꜱᴇǫᴜᴇɴᴄɪɴɢ', callback_data='sort')],
                [InlineKeyboardButton('ᴍᴇᴛᴀᴅᴀᴛᴀ', callback_data='meta'), InlineKeyboardButton('ᴍᴏʀᴇ', callback_data='settings_menu')],
                [InlineKeyboardButton(f'📳 ʀᴇɴᴀᴍᴇ ᴍᴏᴅᴇ: {mode_display}', callback_data='renaming_mode')],
                [InlineKeyboardButton('ʜᴏᴍᴇ', callback_data='home')]
            ])
        )
    elif data == "meta":
        await query.message.edit_text(
            text=Txt.SEND_METADATA,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")]
            ])
        )
    elif data == "file_names":
        await query.message.edit_text(
            text=Txt.FILE_NAME_TXT,
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton('ᴀᴜᴛᴏ ʀᴇɴᴀᴍᴇ', callback_data='thumbnail'), InlineKeyboardButton('ꜱᴇᴛ ꜱᴏᴜʀᴄᴇ', callback_data='source')],
                [InlineKeyboardButton('ʀᴇɴᴀᴍᴇ', callback_data='renaming_mode')],
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")] 


            ])
        )
    elif data == "thumbnail":
        await query.message.edit_caption(
            caption=Txt.THUMBNAIL_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton('ᴛʜᴜᴍʙɴᴀɪʟ', callback_data='file_names'), InlineKeyboardButton('ꜱᴇᴛ ꜱᴏᴜʀᴄᴇ', callback_data='source')],
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")]

            ])
        )
    elif data == "metadatax":
        await query.message.edit_caption(
            caption=Txt.SEND_METADATA,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help")]
            ])
        )
    elif data == "source":
        await query.message.edit_caption(
            caption=Txt.SOURCE_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="home")]
            ])
        )
    elif data == "premiumx":
        await query.message.edit_caption(
            caption=Txt.PREMIUM_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="help"), InlineKeyboardButton("ʙᴜʏ ᴘʀᴇᴍɪᴜᴍ", url=f'https://t.me/{Config.OWNER_USERNAME}')]
            ])
        )
    elif data == "plans":
        await query.message.edit_caption(
            caption=Txt.PREPLANS_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close"), InlineKeyboardButton("ʙᴜʏ ᴘʀᴇᴍɪᴜᴍ", url=f'https://t.me/{Config.OWNER_USERNAME}')]
            ])
        )
    elif data == "about":
        await query.message.edit_text(
            text=Txt.ABOUT_TXT,
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("sᴜᴘᴘᴏʀᴛ", url=f'https://t.me/+sT7FKCfO9DRkYTBl'), InlineKeyboardButton("ᴄᴏᴍᴍᴀɴᴅs", callback_data="help")],
                [InlineKeyboardButton("ᴅᴇᴠᴇʟᴏᴘᴇʀ", url=f'https://t.me/Rbotz')],
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="home")]
            ])
        )
    elif data == "close":
        try:
            await query.message.delete()
            await query.message.reply_to_message.delete()
            await query.message.continue_propagation()
        except:
            await query.message.delete()
            await query.message.continue_propagation()
    elif data == "settings_menu":
        await query.message.edit_text(
            text="**WHERE DO YOU WANT TO OPEN THE SETTINGS MENU?**",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄᴀᴘᴛɪᴏɴ", callback_data="caption"), InlineKeyboardButton("ᴜᴘꜱᴄᴀʟᴇ", callback_data="upscale_settings"), InlineKeyboardButton("ꜰᴏɴᴛ", callback_data="font_settings")],
                [InlineKeyboardButton("ᴛᴏᴏʟꜱ", callback_data="tools_settings"), InlineKeyboardButton("ᴀᴛᴛᴀᴄʜᴍᴇɴᴛ", callback_data="attchment"), InlineKeyboardButton("ᴀɴɪᴍᴇ", callback_data="anime_settings")],
                [InlineKeyboardButton("ᴘᴅꜰ ᴛᴏᴏʟꜱ", callback_data="pdf_tools_settings"), InlineKeyboardButton("ᴛᴇʟᴇɢʀᴀᴘʜ", callback_data="tmg_link_settings"), InlineKeyboardButton("ꜱᴛɪᴄᴋᴇʀ", callback_data="sticker_settings")],
                [InlineKeyboardButton("◁", callback_data="help"), InlineKeyboardButton("• ʜᴏᴍᴇ •", callback_data="help"), InlineKeyboardButton("▷", callback_data="next_page_settings")]
            ])
        )
    elif data == "sort":
        await query.message.edit_caption(
            caption=Txt.SORT_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "attchment":
        await query.message.edit_caption(
            caption=Txt.ATTACHMENT_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "upscale_settings":
        await query.message.edit_caption(
            caption=Txt.UPSCALE_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "font_settings":
        await query.message.edit_caption(
            caption=Txt.FONT_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "tools_settings":
        await query.message.edit_caption(
            caption=Txt.TOOLS_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "tokens_settings":
        await query.message.edit_caption(
            caption=Txt.TOKEN_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "anime_settings":
        await query.message.edit_caption(
            caption=Txt.ANIME_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "pdf_tools_settings":
        await query.message.edit_caption(
            caption=Txt.PDF_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "tmg_link_settings":
        await query.message.edit_caption(
            caption=Txt.TELEGRAPH_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "sticker_settings":
        await query.message.edit_caption(
            caption=Txt.STICKER_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "shareandsupport":
        await query.answer("SHARE AND SUPPORT US ", show_alert=False)
    elif data in ["gen_tokens", "premium_info", "refresh_tokens", "token_back"]:
        await token_buttons_handler(client, query)
    elif data == "next_page_settings":
        await query.message.edit_text(
            text="**WHERE DO YOU WANT TO OPEN THE SETTINGS MENU?**",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
            #    [InlineKeyboardButton("ᴄᴀᴘᴛɪᴏɴ", callback_data="caption"), InlineKeyboardButton("ᴜᴘꜱᴄᴀʟᴇ", callback_data="upscale_settings"), InlineKeyboardButton("ꜰᴏɴᴛ", callback_data="font_settings")],
             #   [InlineKeyboardButton("ᴛᴏᴏʟꜱ", callback_data="tools_settings"), InlineKeyboardButton("ᴛᴏᴋᴇɴꜱ", callback_data="tokens_settings"), InlineKeyboardButton("ᴀɴɪᴍᴇ", callback_data="anime_settings")],
                [InlineKeyboardButton("ᴠɪᴅᴇᴏ ᴛᴏᴏʟꜱ", callback_data="videotools"), InlineKeyboardButton("ɪᴍɢ ᴛᴏᴏʟꜱ", callback_data="imgtools")],
                [InlineKeyboardButton("◁", callback_data="help"), InlineKeyboardButton("• ʜᴏᴍᴇ •", callback_data="help"), InlineKeyboardButton("▷", callback_data="shareandsupport")]
            ])
        )
    elif data == "videotools":
        await query.message.edit_caption(
            caption=Txt.VIDEOTOOLS_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "imgtools":
        await query.message.edit_caption(
            caption=Txt.IMGTOOLS_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ʙᴀᴄᴋ", callback_data="settings_menu")]
            ])
        )
    elif data == "shareandsupport":
        await query.answer("SHARE AND SUPPORT US ", show_alert=False)

    
# ==================== TOKEN AND REFERRAL SYSTEM ====================
@Client.on_message(filters.command("refer") & filters.private)
@check_ban_status
async def refer(client, message):
    user_id = message.from_user.id
    user = await DARKXSIDE78.col.find_one({"_id": user_id})

    if not user or not user.get("referral_code"):
        referral_code = secrets.token_hex(4)
        await DARKXSIDE78.col.update_one(
            {"_id": user_id},
            {"$set": {"referral_code": referral_code}},
            upsert=True
        )
    else:
        referral_code = user["referral_code"]

    referrals = user.get("referrals", []) if user else []
    count = len(referrals)

    refer_link = f"https://t.me/{Config.BOT_USERNAME}?start=ref_{referral_code}"
    await message.reply_text(
        f"**Your Referral Link:**\n{refer_link}\n\n"
        f"**Total Referrals:** {count}\n"
        f"**You get {Config.REFER_TOKEN} tokens for every successful referral!**"
    )

@Client.on_message(filters.command("add_token") & filters.user(Config.ADMIN))
async def add_tokens(client, message: Message):
    try:
        if len(message.command) < 3:
            return await message.reply_text("**Usᴀɢᴇ:** `/add_token <amount> @username/userid`")

        amount = message.command[1]
        user_ref = message.command[2]
        
        try:
            amount = int(amount)
        except ValueError:
            return await message.reply_text("**Amount must be a number!**")

        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            try:
                user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
            except ValueError:
                return await message.reply_text("**Invalid user ID!**")
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        new_tokens = user.get('token', Config.DEFAULT_TOKEN) + amount
        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {"token": new_tokens}}
        )
        await message.reply_text(f"🗸 Aᴅᴅᴇᴅ {amount} ᴛᴏᴋᴇɴs ᴛᴏ ᴜsᴇʀ {user['_id']}. Nᴇᴡ ʙᴀʟᴀɴᴄᴇ: {new_tokens}")
    except Exception as e:
        await message.reply_text(f"Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /add_token <amount> @username/userid")

@Client.on_message(filters.command("remove_token") & filters.user(Config.ADMIN))
async def remove_tokens(client, message: Message):
    try:
        if len(message.command) < 3:
            return await message.reply_text("**Usᴀɢᴇ:** `/remove_token <amount> @username/userid`")

        amount = message.command[1]
        user_ref = message.command[2]
        
        try:
            amount = int(amount)
        except ValueError:
            return await message.reply_text("**Amount must be a number!**")

        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            try:
                user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
            except ValueError:
                return await message.reply_text("**Invalid user ID!**")
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        new_tokens = max(0, user.get('token', Config.DEFAULT_TOKEN) - amount)
        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {"token": new_tokens}}
        )
        await message.reply_text(f"**✘ Rᴇᴍᴏᴠᴇᴅ {amount} ᴛᴏᴋᴇɴs ғʀᴏᴍ ᴜsᴇʀ {user['_id']}. Nᴇᴡ ʙᴀʟᴀɴᴄᴇ: {new_tokens}**")
    except Exception as e:
        await message.reply_text(f"Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /remove_token <amount> @username/userid")

@Client.on_message(filters.private & filters.command(["token", "mytokens", "bal"]))
async def check_tokens(client, message: Message):
    user_id = message.from_user.id
    user_data = await DARKXSIDE78.col.find_one({"_id": user_id})
    
    if not user_data:
        # Initialize user if not found
        await DARKXSIDE78.add_user(client, message)
        user_data = await DARKXSIDE78.col.find_one({"_id": user_id})
    
    is_premium = user_data.get("is_premium", False)
    premium_expiry = user_data.get("premium_expiry")

    if is_premium and premium_expiry:
        if datetime.now(pytz.UTC) > premium_expiry.replace(tzinfo=pytz.UTC):
            is_premium = False
            await DARKXSIDE78.col.update_one(
                {"_id": user_id},
                {"$set": {"is_premium": False, "premium_expiry": None}}
            )

    token_count = user_data.get("token", Config.DEFAULT_TOKEN)
    msg = [
        "**Yᴏᴜʀ Aᴄᴄᴏᴜɴᴛ Sᴛᴀᴛᴜs**",
        "",
        f"**Pʀᴇᴍɪᴜᴍ Sᴛᴀᴛᴜs:** {'🗸 Aᴄᴛɪᴠᴇ' if is_premium else '✘ Iɴᴀᴄᴛɪᴠᴇ'}"
    ]
    
    if is_premium and premium_expiry:
        msg.append(f"**Pʀᴇᴍɪᴜᴍ Exᴘɪʀʏ:** {premium_expiry.strftime('%d %b %Y %H:%M')}")
    else:
        msg.extend([
            f"**Aᴠᴀɪʟᴀʙʟᴇ Tᴏᴋᴇɴs:** {token_count}",
            "",
            "**1 ᴛᴏᴋᴇɴ = 1 ғɪʟᴇ ʀᴇɴᴀᴍᴇ**",
            ""
        ])
    
    buttons = []
    if not is_premium:
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("Gᴇɴᴇʀᴀᴛᴇ Mᴏʀᴇ Tᴏᴋᴇɴs", callback_data="gen_tokens")],
            [InlineKeyboardButton("Gᴇᴛ Pʀᴇᴍɪᴜᴍ", callback_data="premium_info")]
        ])
    else:
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("Rᴇғʀᴇsʜ Sᴛᴀᴛᴜs", callback_data="refresh_tokens")]
        ])
    
    sent_message = await message.reply_text(
        "\n".join(msg),
        reply_markup=buttons,
        disable_web_page_preview=True
    )
    
    # Auto-delete after 5 minutes (300 seconds)
    await asyncio.sleep(300)
    try:
        await sent_message.delete()
    except:
        pass

@Client.on_callback_query(filters.regex(r"^(gen_tokens|premium_info|refresh_tokens|token_back)$"))
async def token_buttons_handler(client, query: CallbackQuery):
    data = query.data
    user_id = query.from_user.id
    
    if data == "gen_tokens":
        await query.message.edit_text(
            "**Yᴏᴜ ᴄᴀɴ ɢᴇɴᴇʀᴀᴛᴇ ᴛᴏᴋᴇɴs ᴜsɪɴɢ /gentoken** 🔗",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Sᴜᴘᴘᴏʀᴛ", url=f"https://t.me/+sT7FKCfO9DRkYTBl")],
                [InlineKeyboardButton("Bᴀᴄᴋ", callback_data="token_back")]
            ]),
            disable_web_page_preview=True
        )
    elif data == "premium_info":
        await query.message.edit_text(
            Txt.PREMIUM_TXT,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Sᴜᴘᴘᴏʀᴛ", url=f"https://t.me/+sT7FKCfO9DRkYTBl")],
                [InlineKeyboardButton("Bᴀᴄᴋ", callback_data="token_back")]
            ]),
            disable_web_page_preview=True
        )
    elif data == "refresh_tokens":
        # Create a fake message object for the check_tokens function
        class FakeMessage:
            def __init__(self, message):
                self._client = message._client
                self.chat = message.chat
                self.from_user = query.from_user
                self.reply_to_message = None
                
            async def reply_text(self, *args, **kwargs):
                return await self.chat.send_message(*args, **kwargs)
        
        fake_msg = FakeMessage(query.message)
        await check_tokens(client, fake_msg)
        await query.answer("Status refreshed!")
    elif data == "token_back":
        fake_msg = FakeMessage(query.message)
        await check_tokens(client, fake_msg)
@Client.on_message(filters.command("gentoken") & filters.private)
@check_ban_status
async def generate_token(client: Client, message: Message):
    user_id = message.from_user.id
    
    try:
        # Generate token ID
        token_id = "".join(random.choices(string.ascii_uppercase + string.digits, k=getattr(Config, 'TOKEN_ID_LENGTH', 8)))
        
        # Generate random token amount
        base_tokens = getattr(Config, 'SHORTENER_TOKEN_GEN', 100)
        min_tokens = getattr(Config, 'TOKEN_RANDOM_RANGE', (25, 100))[0]
        max_tokens = getattr(Config, 'TOKEN_RANDOM_RANGE', (25, 100))[1]
        percentage_var = getattr(Config, 'TOKEN_PERCENTAGE_VARIATION', 0.3)
        
        variation = random.randint(-int(base_tokens * percentage_var), int(base_tokens * percentage_var))
        token_amount = max(min_tokens, min(max_tokens, base_tokens + variation))
        
        deep_link = f"https://t.me/{Config.BOT_USERNAME}?start={token_id}"
        
        # Get shortened URL with retry mechanism
        short_url = await shorten_url(deep_link)
        
        # If shortening failed, create a cleaner display
        if short_url == deep_link:
            # Create a minimal display version
            display_url = f"t.me/{Config.BOT_USERNAME}?start={token_id}"
        else:
            display_url = short_url
        
        # Store token in database
        await DARKXSIDE78.create_token_link(user_id, token_id, token_amount)
        
        # Create enhanced buttons
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 Share Token Link", url=f"https://t.me/share/url?url={quote(short_url)}&text=🎁 Get {token_amount} FREE Tokens for File Renamer Bot! Use this link: {short_url}")],
            [InlineKeyboardButton("📋 Copy Link", callback_data=f"copy_{token_id}")],
            [InlineKeyboardButton("📊 Check Balance", callback_data="refresh_tokens"), InlineKeyboardButton("❌ Close", callback_data="close")]
        ])
        
        # Create message with better formatting
        progress = "🟢" * min(token_amount // 20, 5) + "⚪" * (5 - min(token_amount // 20, 5))
        
        message_text = f"""
**🎉 TOKEN GENERATED!**

{progress}
**💰 Amount:** `{token_amount} tokens`
**⏰ Valid:** 24 hours
**🔗 Your Link:** `{display_url}`

💡 *Share this link to get {token_amount} tokens when someone uses it!*
"""
        
        # Send the main message
        sent_message = await message.reply_text(
            text=message_text,
            reply_markup=buttons,
            disable_web_page_preview=True
        )
        
        # Auto-delete after 5 minutes
        await asyncio.sleep(300)
        try:
            await sent_message.delete()
        except:
            pass
            
    except Exception as e:
        logger.error(f"Error in token generation: {e}")
        await message.reply_text("❌ Failed to generate token. Please try again later.")
async def handle_token_redemption(client: Client, message: Message, token_id: str):
    user_id = message.from_user.id
    
    try:
        token_data = await DARKXSIDE78.get_token_link(token_id)
        
        if not token_data:
            return await message.reply_text("❌ Invalid or expired token link.")
        
        if token_data['used']:
            return await message.reply_text("⚠️ This token has already been used.")
        
        # Check expiry
        expiry_utc = token_data['expiry'].replace(tzinfo=pytz.UTC)
        if datetime.now(pytz.UTC) > expiry_utc:
            return await message.reply_text("⌛ This token has expired.")
        
        # Add tokens to user
        await DARKXSIDE78.col.update_one(
            {"_id": user_id},
            {"$inc": {"token": token_data['tokens']}}
        )
        
        # Mark token as used
        await DARKXSIDE78.mark_token_used(token_id, user_id)
        
        # Notify both users
        await message.reply_text(
            f"🎊 **WELCOME BONUS!**\n\n"
            f"You received `{token_data['tokens']}` tokens!\n"
            f"Use `/help` to see how to use them for file renaming."
        )
        
        # Notify token creator
        try:
            await client.send_message(
                token_data['user_id'],
                f"✅ **Token Redeemed!**\n\n"
                f"Someone used your token link!\n"
                f"+{token_data['tokens']} tokens added to your balance."
            )
        except:
            pass  # User might have blocked bot
            
    except Exception as e:
        logger.error(f"Token redemption error: {e}")
        await message.reply_text("❌ Error processing token. Please try again.")
async def shorten_url(deep_link: str) -> str:
    """Enhanced URL shortening with multiple fallback options"""
    original_link = deep_link
    
    # If no shortener configured, use a fallback
    if not hasattr(Config, 'SHORTENER_URL') or not Config.SHORTENER_URL:
        logger.warning("No shortener configured, using direct link")
        return original_link
    
    try:
        # Method 1: Primary Shortener
        api_url = f"{Config.SHORTENER_URL}?api={Config.TOKEN_API}&url={quote(deep_link)}&format=text"
        logger.info(f"Attempting to shorten: {api_url}")
        
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(api_url, ssl=True) as response:
                if response.status == 200:
                    shortened = (await response.text()).strip()
                    if shortened and shortened.startswith(('http://', 'https://')):
                        logger.info(f"Successfully shortened: {shortened}")
                        return shortened
        
        # Method 2: Fallback Shortener (if primary fails)
        logger.warning("Primary shortener failed, trying fallback...")
        fallback_apis = [
            f"https://api.shorte.st/s/{Config.TOKEN_API}/{quote(deep_link)}",
            f"https://is.gd/create.php?format=simple&url={quote(deep_link)}",
        ]
        
        for api_url in fallback_apis:
            try:
                async with session.get(api_url, ssl=True) as response:
                    if response.status == 200:
                        shortened = (await response.text()).strip()
                        if shortened and shortened.startswith(('http://', 'https://')):
                            logger.info(f"Fallback shortener worked: {shortened}")
                            return shortened
            except:
                continue
                
    except Exception as e:
        logger.error(f"All shortening methods failed: {e}")
    
    logger.warning("All shortening failed, returning original link")
    return original_link
@Client.on_message(filters.command("add_premium") & filters.user(Config.ADMIN))
async def add_premium(bot: Client, message: Message):
    try:
        cmd, user_ref, duration = message.text.split(maxsplit=2)
        duration = duration.lower()
        
        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        if duration == "lifetime":
            expiry = datetime(9999, 12, 31)
        else:
            num, unit = duration[:-1], duration[-1]
            unit_map = {
                'h': 'hours',
                'd': 'days',
                'm': 'months',
                'y': 'years'
            }
            delta = timedelta(**{unit_map[unit]: int(num)})
            expiry = datetime.now() + delta
        
        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {
                "is_premium": True,
                "premium_expiry": expiry
            }}
        )
        await message.reply_text(f"**🗸 Pʀᴇᴍɪᴜᴍ ᴀᴅᴅᴇᴅ ᴜɴᴛɪʟ {expiry}**")
    except Exception as e:
        await message.reply_text(f"Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /add_premium @username/userid ")

@Client.on_message(filters.command("remove_premium") & filters.user(Config.ADMIN))
async def remove_premium(bot: Client, message: Message):
    try:
        _, user_ref = message.text.split(maxsplit=1)
        
        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {
                "is_premium": False,
                "premium_expiry": None
            }}
        )
        await message.reply_text("**✘ Pʀᴇᴍɪᴜᴍ ᴀᴄᴄᴇss ʀᴇᴍᴏᴠᴇᴅ**")
    except Exception as e:
        await message.reply_text(f"Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /remove_premium @username/userid")

# ==================== OTHER COMMANDS ====================
@Client.on_message(filters.command("premium"))
@check_ban_status
async def getpremium(bot, message):
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("ᴏᴡɴᴇʀ", url=f"https://t.me/{Config.OWNER_USERNAME}"), InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close")]
    ])
    yt = await message.reply_photo(photo='https://graph.org/file/feebef43bbdf76e796b1b.jpg', caption=Txt.PREMIUM_TXT, reply_markup=buttons)
    await asyncio.sleep(300)
    await yt.delete()
    await message.delete()

@Client.on_message(filters.command("plan"))
@check_ban_status
async def premium(bot, message):
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("sᴇɴᴅ ss", url=f"https://t.me/{Config.OWNER_USERNAME}"), InlineKeyboardButton("ᴄʟᴏsᴇ", callback_data="close")]
    ])
    yt = await message.reply_photo(photo='https://graph.org/file/8b50e21db819f296661b7.jpg', caption=Txt.PREPLANS_TXT, reply_markup=buttons)
    await asyncio.sleep(300)
    await yt.delete()
    await message.delete()

@Client.on_message(filters.command("bought") & filters.private)
@check_ban_status
async def bought(client, message):
    msg = await message.reply('Wᴀɪᴛ ᴄʜᴇᴄᴋɪɴɢ...')
    replied = message.reply_to_message

    if not replied:
        await msg.edit("<b>Please reply with the screenshot of your payment for the premium purchase to proceed.\n\nFor example, first upload your screenshot, then reply to it using the '/bought' command</b>")
    elif replied.photo:
        await client.send_photo(
            chat_id=LOG_CHANNEL,
            photo=replied.photo.file_id,
            caption=f'<b>User - {message.from_user.mention}\nUser id - <code>{message.from_user.id}</code>\nUsername - <code>{message.from_user.username}</code>\nName - <code>{message.from_user.first_name}</code></b>',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Close", callback_data="close_data")]
            ])
        )
        await msg.edit_text('<b>Yᴏᴜʀ sᴄʀᴇᴇɴsʜᴏᴛ ʜᴀs ʙᴇᴇɴ sᴇɴᴛ ᴛᴏ Aᴅᴍɪɴs</b>')

@Client.on_message(filters.private & filters.command("help"))
@check_ban_status
async def help_command(client, message):
    bot = await client.get_me()
    mention = bot.mention
    user_id = message.from_user.id        
     # Get current mode for display in help menu
    current_mode = await DARKXSIDE78.get_renaming_mode(user_id) or "autorename"
    mode_display = current_mode.upper()

    await message.reply_text(
        text=Txt.HELP_TXT.format(mention=mention),
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("ᴀᴜᴛᴏ ʀᴇɴᴀᴍᴇ ғᴏʀᴍᴀᴛ", callback_data='file_names')],
            [InlineKeyboardButton('ᴛʜᴜᴍʙɴᴀɪʟ', callback_data='thumbnail'), InlineKeyboardButton('ꜱᴇǫᴜᴇɴᴄɪɴɢ', callback_data='sort')],
            [InlineKeyboardButton('ᴍᴇᴛᴀᴅᴀᴛᴀ', callback_data='meta'), InlineKeyboardButton('ᴍᴏʀᴇ', callback_data='settings_menu')],
            [InlineKeyboardButton(f'📳 ʀᴇɴᴀᴍᴇ ᴍᴏᴅᴇ: {mode_display}', callback_data='renaming_mode')],
            [InlineKeyboardButton('ʜᴏᴍᴇ', callback_data='home')]
        ])
    )
@Client.on_message(filters.private & filters.command(["settings", "panel"]))
async def settings_command(client, message):
    # Use START_PIC if available
    if hasattr(Config, 'START_PIC') and Config.START_PIC:
        await message.reply_photo(
            photo=Config.START_PIC,
            caption="**WHERE DO YOU WANT TO OPEN THE SETTINGS MENU?**",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄᴀᴘᴛɪᴏɴ", callback_data="caption"), InlineKeyboardButton("ᴜᴘꜱᴄᴀʟᴇ", callback_data="upscale_settings"), InlineKeyboardButton("ꜰᴏɴᴛ", callback_data="font_settings")],
                [InlineKeyboardButton("ᴛᴏᴏʟꜱ", callback_data="tools_settings"), InlineKeyboardButton("ᴛᴏᴋᴇɴꜱ", callback_data="tokens_settings"), InlineKeyboardButton("ᴀɴɪᴍᴇ", callback_data="anime_settings")],
                [InlineKeyboardButton("ᴘᴅꜰ ᴛᴏᴏʟꜱ", callback_data="pdf_tools_settings"), InlineKeyboardButton("ᴛᴇʟᴇɢʀᴀᴘʜ", callback_data="tmg_link_settings"), InlineKeyboardButton("ꜱᴛɪᴄᴋᴇʀ", callback_data="sticker_settings")],
                [InlineKeyboardButton("◁", callback_data="help"), InlineKeyboardButton("• ʜᴏᴍᴇ •", callback_data="help"), InlineKeyboardButton("▷", callback_data="next_page_settings")]
            ])
        )
    else:
        await message.reply_text(
            text="**WHERE DO YOU WANT TO OPEN THE SETTINGS MENU?**",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("ᴄᴀᴘᴛɪᴏɴ", callback_data="caption"), InlineKeyboardButton("ᴜᴘꜱᴄᴀʟᴇ", callback_data="upscale_settings"), InlineKeyboardButton("ꜰᴏɴᴛ", callback_data="font_settings")],
                [InlineKeyboardButton("ᴛᴏᴏʟꜱ", callback_data="tools_settings"), InlineKeyboardButton("ᴛᴏᴋᴇɴꜱ", callback_data="tokens_settings"), InlineKeyboardButton("ᴀɴɪᴍᴇ", callback_data="anime_settings")],
                [InlineKeyboardButton("ᴘᴅꜰ ᴛᴏᴏʟꜱ", callback_data="pdf_tools_settings"), InlineKeyboardButton("ᴛᴇʟᴇɢʀᴀᴘʜ", callback_data="tmg_link_settings"), InlineKeyboardButton("ꜱᴛɪᴄᴋᴇʀ", callback_data="sticker_settings")],
                [InlineKeyboardButton("◁", callback_data="help"), InlineKeyboardButton("• ʜᴏᴍᴇ •", callback_data="help"), InlineKeyboardButton("▷", callback_data="next_page_settings")]
            ])
        )
class FakeMessage:
    def __init__(self, client, chat, from_user):
        self._client = client
        self.chat = chat
        self.from_user = from_user
        self.reply_to_message = None
        
    async def reply_text(self, *args, **kwargs):
        return await self.chat.send_message(*args, **kwargs)
@Client.on_message(filters.command(["img", "tgm", "telegraph"], prefixes="/") & filters.reply)
async def c_upload(client, message: Message):
    reply = message.reply_to_message
    if not reply.media:
        return await message.reply_text("Reply to a media to upload it to Cloud.")
    if reply.document and reply.document.file_size > 5 * 1024 * 1024:  # 5 MB
        return await message.reply_text("File size limit is 5 MB.")
    msg = await message.reply_text("Processing...")
    try:
        downloaded_media = await reply.download()
        if not downloaded_media:
            return await msg.edit_text("Something went wrong during download.")
        with open(downloaded_media, "rb") as f:
            data = f.read()
            resp = requests.post("https://envs.sh", files={"file": data})
            if resp.status_code == 200:
                await msg.edit_text(f"{resp.text}")
            else:
                await msg.edit_text("Something went wrong. Please try again later.")
        os.remove(downloaded_media)
    except Exception as e:
        await msg.edit_text(f"Error: {str(e)}")   

