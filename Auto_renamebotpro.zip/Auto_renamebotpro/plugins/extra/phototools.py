import os
import asyncio
import logging
import time
import random
import string
import math
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter, ImageEnhance
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from helper.utils import humanbytes, progress_for_pyrogram

logger = logging.getLogger(__name__)

class PhotoTools:
    def __init__(self, bot: Client):
        self.bot = bot
        
    def _generate_random_id(self, length=8):
        """Generate random ID for filenames"""
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    
    def _is_image_file(self, message: Message) -> bool:
        """Check if the replied message contains an image file"""
        if not message.reply_to_message:
            return False
            
        msg = message.reply_to_message
        
        # Check for photo message
        if msg.photo:
            return True
            
        # Check for document with image mime type
        if msg.document:
            mime_type = msg.document.mime_type or ""
            file_name = msg.document.file_name or ""
            
            # Check mime type
            if 'image' in mime_type.lower():
                return True
                
            # Check file extension
            image_extensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.tiff', '.ico']
            if any(file_name.lower().endswith(ext) for ext in image_extensions):
                return True
                
        return False
    
    async def _download_media(self, message: Message, user_id: int, operation: str) -> str:
        """Download media from replied message WITH progress"""
        try:
            if not message.reply_to_message:
                return None
            
            msg = message.reply_to_message
            timestamp = int(time.time())
            random_id = self._generate_random_id()
            
            # Determine file type and extension
            if msg.photo:
                # Photos in Telegram are sent in different sizes, get the largest
                photo_sizes = msg.photo
                largest_photo = max(photo_sizes, key=lambda x: x.file_size)
                ext = ".jpg"
                media_type = "photo"
            elif msg.document:
                media = msg.document
                file_name = media.file_name or "image"
                ext = os.path.splitext(file_name)[1]
                if not ext:
                    # Guess extension from mime type
                    if media.mime_type:
                        if 'png' in media.mime_type:
                            ext = '.png'
                        elif 'jpeg' in media.mime_type or 'jpg' in media.mime_type:
                            ext = '.jpg'
                        elif 'webp' in media.mime_type:
                            ext = '.webp'
                        elif 'gif' in media.mime_type:
                            ext = '.gif'
                        else:
                            ext = '.jpg'
                    else:
                        ext = '.jpg'
                media_type = "image"
            else:
                return None
            
            # Create downloads directory if not exists
            os.makedirs("downloads", exist_ok=True)
            
            # Generate clean filename
            clean_filename = f"{operation}_{random_id}{ext}"
            file_path = f"downloads/{clean_filename}"
            
            # Download with progress
            download_msg = await message.reply_text(f"**⬇️ Downloading image for {operation.replace('_', ' ')}...**")
            
            start_time = time.time()
            
            # Define progress callback wrapper
            async def progress_callback(current, total):
                await progress_for_pyrogram(
                    current, total, 
                    f"Downloading image for {operation.replace('_', ' ')}...", 
                    download_msg, 
                    start_time
                )
            
            download_path = await self.bot.download_media(
                message=msg,
                file_name=file_path,
                progress=progress_callback
            )
            
            await download_msg.delete()
            
            if download_path and os.path.exists(download_path):
                return download_path
            return None
            
        except Exception as e:
            logger.error(f"Download error: {e}")
            return None
    
    async def _cleanup_files(self, *paths):
        """Clean up temporary files with error handling"""
        for path in paths:
            try:
                if path and os.path.exists(path):
                    os.remove(path)
                    logger.debug(f"Cleaned up: {path}")
            except Exception as e:
                logger.error(f"Cleanup error for {path}: {e}")
    
    async def _update_progress(self, message: Message, text: str):
        """Update progress message"""
        try:
            await message.edit_text(f"**{text}**")
        except:
            pass
    async def crop_image(self, message: Message, user_id: int, coordinates: str = None):
        """Crop image with specified coordinates"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to crop**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if not coordinates:
                return await message.reply_text(
                    "**✂️ Crop Image**\n\n"
                    "**Usage:** `/crop x1,y1,x2,y2`\n"
                    "**Example:** `/crop 100,100,500,500`\n\n"
                    "Reply to an image with coordinates."
                )
            
            # Parse coordinates (format: x1,y1,x2,y2)
            try:
                coords = [int(x.strip()) for x in coordinates.split(',')]
                if len(coords) != 4:
                    raise ValueError("Need 4 coordinates")
                x1, y1, x2, y2 = coords
            except:
                return await message.reply_text("**❌ Invalid coordinates! Use format: x1,y1,x2,y2**")
            
            processing_msg = await message.reply_text("**✂️ Cropping image...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "crop")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Crop image
            await self._update_progress(processing_msg, "✂️ Cropping image...")
            
            with Image.open(image_path) as img:
                # Ensure coordinates are within image bounds
                width, height = img.size
                x1 = max(0, min(x1, width))
                y1 = max(0, min(y1, height))
                x2 = max(0, min(x2, width))
                y2 = max(0, min(y2, height))
                
                if x2 <= x1 or y2 <= y1:
                    await processing_msg.edit_text("**❌ Invalid crop area!**")
                    return
                
                cropped_img = img.crop((x1, y1, x2, y2))
                
                random_id = self._generate_random_id()
                output_filename = f"cropped_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                cropped_img.save(output_path, "JPEG", quality=95)
            
            # Send cropped image
            await self._update_progress(processing_msg, "📤 Sending cropped image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**✂️ Cropped Image**\n**Area:** ({x1},{y1}) to ({x2},{y2})",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Image crop error: {e}")
            await message.reply_text(f"**❌ Error cropping image:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    async def resize_image(self, message: Message, user_id: int, dimensions: str = None):
        """Resize image to specified dimensions"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to resize**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if not dimensions:
                return await message.reply_text(
                    "**🖌 Resize Image**\n\n"
                    "**Usage:** `/resize dimensions`\n"
                    "**Formats:**\n"
                    "• `widthxheight` (e.g., 800x600)\n"
                    "• `percentage` (e.g., 50 or 50%)\n"
                    "**Example:** `/resize 800x600` or `/resize 50%`"
                )
            
            # Parse dimensions
            try:
                if 'x' in dimensions:
                    width, height = map(int, dimensions.split('x'))
                elif dimensions.endswith('%'):
                    scale = float(dimensions.rstrip('%')) / 100.0
                else:
                    scale = float(dimensions) / 100.0
            except:
                await message.reply_text("**❌ Invalid dimensions!**")
                return
            
            processing_msg = await message.reply_text("**🖌 Resizing image...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "resize")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Calculate dimensions if percentage
            if 'scale' in locals():
                with Image.open(image_path) as img:
                    orig_width, orig_height = img.size
                    width = int(orig_width * scale)
                    height = int(orig_height * scale)
            
            # Resize image
            await self._update_progress(processing_msg, "🖌 Resizing image...")
            
            with Image.open(image_path) as img:
                # Use LANCZOS for high-quality resampling
                resized_img = img.resize((width, height), Image.Resampling.LANCZOS)
                
                random_id = self._generate_random_id()
                output_filename = f"resized_{width}x{height}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                resized_img.save(output_path, "JPEG", quality=95)
            
            # Send resized image
            await self._update_progress(processing_msg, "📤 Sending resized image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🖌 Resized Image**\n**Dimensions:** {width}x{height}",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Image resize error: {e}")
            await message.reply_text(f"**❌ Error resizing image:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    async def convert_format(self, message: Message, user_id: int, target_format: str = None):
        """Convert image to different format"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to convert**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            valid_formats = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'ico', 'tiff']
            
            if target_format:
                if target_format.lower() not in valid_formats:
                    return await message.reply_text(
                        f"**❌ Invalid format! Supported formats:** {', '.join(valid_formats)}"
                    )
            else:
                target_format = "png"  # Default
            
            processing_msg = await message.reply_text(f"**🖼 Converting to {target_format.upper()}...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "convert")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # If no format provided, ask for it
            if not target_format:
                keyboard = InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("PNG", callback_data="pformat:png"),
                        InlineKeyboardButton("JPG", callback_data="pformat:jpg")
                    ],
                    [
                        InlineKeyboardButton("WEBP", callback_data="pformat:webp"),
                        InlineKeyboardButton("GIF", callback_data="pformat:gif")
                    ]
                ])
                await processing_msg.edit_text(
                    "**Select output format:**",
                    reply_markup=keyboard
                )
                return
            
            # Convert format
            await self._update_progress(processing_msg, f"🔄 Converting to {target_format.upper()}...")
            
            random_id = self._generate_random_id()
            output_filename = f"converted_{random_id}.{target_format}"
            output_path = f"downloads/{output_filename}"
            
            with Image.open(image_path) as img:
                fmt = target_format.lower()
                
                if fmt == 'png':
                    if img.mode != 'RGBA':
                        img = img.convert('RGBA')
                    img.save(output_path, "PNG", optimize=True)
                elif fmt == 'webp':
                    img.save(output_path, "WEBP", quality=95, method=6)
                elif fmt == 'gif':
                    # Convert to GIF (single frame)
                    if img.mode != 'P':
                        img = img.convert('P', palette=Image.ADAPTIVE)
                    img.save(output_path, "GIF", optimize=True)
                elif fmt in ['jpg', 'jpeg']:
                    if img.mode != 'RGB':
                        img = img.convert('RGB')
                    img.save(output_path, "JPEG", quality=95, optimize=True)
                elif fmt == 'bmp':
                    img.save(output_path, "BMP")
                elif fmt == 'ico':
                    # ICO format requires specific sizes
                    img = img.resize((256, 256), Image.Resampling.LANCZOS)
                    img.save(output_path, "ICO")
                elif fmt == 'tiff':
                    img.save(output_path, "TIFF", compression='tiff_lzw')
            
            # Send converted image
            await self._update_progress(processing_msg, "📤 Sending converted image...")
            try:
                await self.bot.send_document(
                    message.chat.id,
                    output_path,
                    caption=f"**🖼 Converted to {target_format.upper()} format**",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Image format conversion error: {e}")
            await message.reply_text(f"**❌ Error converting format:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    
    async def remove_background(self, message: Message, user_id: int):
        """Remove background from image"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to remove background**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            processing_msg = await message.reply_text("**🧹 Removing background...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "bgremove")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Try to use rembg if available
            try:
                import rembg
                from rembg import remove
                
                await self._update_progress(processing_msg, "🧹 Removing background (using AI)...")
                
                with open(image_path, "rb") as input_file:
                    input_data = input_file.read()
                    output_data = remove(input_data)
                
                random_id = self._generate_random_id()
                output_filename = f"nobg_{random_id}.png"
                output_path = f"downloads/{output_filename}"
                
                with open(output_path, "wb") as output_file:
                    output_file.write(output_data)
                    
            except ImportError:
                # Fallback to basic background removal
                await self._update_progress(processing_msg, "🧹 Removing background (basic method)...")
                
                random_id = self._generate_random_id()
                output_filename = f"nobg_basic_{random_id}.png"
                output_path = f"downloads/{output_filename}"
                
                with Image.open(image_path) as img:
                    # Convert to RGBA if not already
                    if img.mode != 'RGBA':
                        img = img.convert('RGBA')
                    
                    # Simple background removal by detecting edges and filling with transparency
                    datas = img.getdata()
                    new_data = []
                    
                    # Threshold for background detection (adjust based on image)
                    threshold = 200
                    
                    for item in datas:
                        # Remove white/light backgrounds
                        if item[0] > threshold and item[1] > threshold and item[2] > threshold:
                            new_data.append((255, 255, 255, 0))
                        else:
                            new_data.append(item)
                    
                    img.putdata(new_data)
                    img.save(output_path, "PNG")
            
            # Send processed image
            await self._update_progress(processing_msg, "📤 Sending image with removed background...")
            try:
                await self.bot.send_document(
                    message.chat.id,
                    output_path,
                    caption="**🧹 Background removed**\n*Note: For best results, use images with clear contrast*",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Background removal error: {e}")
            await message.reply_text(f"**❌ Error removing background:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    
    async def crop_to_aspect_ratio(self, message: Message, user_id: int, ratio: str = None):
        """Crop image to specific aspect ratio"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to crop to aspect ratio**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if not ratio:
                return await message.reply_text(
                    "**📏 Crop to Aspect Ratio**\n\n"
                    "**Usage:** `/ratio ratio_name`\n"
                    "**Ratios:** 16:9, 1:1, 4:3, 9:16, 3:2, 2:3, 21:9, 5:4, custom\n"
                    "**Example:** `/ratio 1:1`\n\n"
                    "Reply to an image with ratio."
                )
            
            ratio_map = {
                '16:9': (16, 9),
                '1:1': (1, 1),
                '4:3': (4, 3),
                '9:16': (9, 16),
                '3:2': (3, 2),
                '2:3': (2, 3),
                '21:9': (21, 9),
                '5:4': (5, 4),
                'custom': 'custom'
            }
            
            if ratio not in ratio_map:
                return await message.reply_text(
                    f"**❌ Invalid aspect ratio!**\n"
                    f"**Supported ratios:** {', '.join(ratio_map.keys())}"
                )
            
            # If custom ratio, check for additional parameter
            if ratio == 'custom':
                # Custom ratio should be passed as a single parameter like "custom:16:9"
                if len(message.command) > 2:
                    custom_ratio = message.command[2]
                    try:
                        if ':' not in custom_ratio:
                            raise ValueError("Invalid format")
                        width_ratio, height_ratio = map(int, custom_ratio.split(':'))
                    except:
                        return await message.reply_text("**❌ Invalid custom ratio! Use format: width:height**")
                else:
                    return await message.reply_text("**❌ Custom ratio requires format! Use: `/ratio custom 16:9`**")
            else:
                width_ratio, height_ratio = ratio_map[ratio]
            
            processing_msg = await message.reply_text("**📏 Cropping to aspect ratio...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "ratio")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Crop to aspect ratio
            await self._update_progress(processing_msg, f"📏 Cropping to {width_ratio}:{height_ratio}...")
            
            with Image.open(image_path) as img:
                orig_width, orig_height = img.size
                
                # Calculate target dimensions
                target_ratio = width_ratio / height_ratio
                current_ratio = orig_width / orig_height
                
                if current_ratio > target_ratio:
                    # Image is wider than target - crop width
                    new_width = int(orig_height * target_ratio)
                    left = (orig_width - new_width) // 2
                    top = 0
                    right = left + new_width
                    bottom = orig_height
                else:
                    # Image is taller than target - crop height
                    new_height = int(orig_width / target_ratio)
                    left = 0
                    top = (orig_height - new_height) // 2
                    right = orig_width
                    bottom = top + new_height
                
                cropped_img = img.crop((left, top, right, bottom))
                
                random_id = self._generate_random_id()
                ratio_str = f"{width_ratio}_{height_ratio}" if ratio != 'custom' else f"custom_{random_id}"
                output_filename = f"ratio_{ratio_str}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                cropped_img.save(output_path, "JPEG", quality=95)
            
            # Send cropped image
            await self._update_progress(processing_msg, "📤 Sending cropped image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**📏 Cropped to {width_ratio}:{height_ratio} aspect ratio**",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Aspect ratio crop error: {e}")
            await message.reply_text(f"**❌ Error cropping to aspect ratio:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    async def generate_collage(self, message: Message, user_id: int, grid_size: str = None):
        """Generate collage grid from image"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to create collage**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if not grid_size:
                return await message.reply_text(
                    "**🖥 Generate Collage**\n\n"
                    "**Usage:** `/collage rowsxcols`\n"
                    "**Example:** `/collage 2x2` or `/collage 3x3`\n"
                    "**Max:** 5x5 (25 cells total)\n\n"
                    "Reply to an image."
                )
            
            # Parse grid size
            try:
                if 'x' in grid_size:
                    cols, rows = map(int, grid_size.split('x'))
                else:
                    # Assume square if single number
                    cols = rows = int(grid_size)
                
                if cols < 1 or rows < 1:
                    return await message.reply_text("**❌ Grid size must be at least 1x1!**")
                
                if cols * rows > 25:
                    return await message.reply_text("**❌ Maximum total cells is 25!**")
                
                if cols > 10 or rows > 10:
                    return await message.reply_text("**❌ Maximum rows/columns is 10!**")
                    
            except ValueError:
                return await message.reply_text(
                    "**❌ Invalid grid size! Use format:**\n"
                    "• `2x2` (2 columns, 2 rows)\n"
                    "• `3x3` (3 columns, 3 rows)\n"
                    "• `4x3` (4 columns, 3 rows)\n"
                    "**Max:** 5x5 (25 cells total)"
                )
            
            processing_msg = await message.reply_text(f"**🖥 Generating {grid_size} collage...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "collage")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Create collage
            await self._update_progress(processing_msg, "🖥 Creating collage grid...")
            
            with Image.open(image_path) as img:
                # Resize images for collage
                img_width, img_height = img.size
                
                # Adjust size for better collage appearance
                collage_width = 1000  # Fixed width for collage
                cell_width = collage_width // cols
                cell_height = int(cell_width * (img_height / img_width))
                collage_height = cell_height * rows
                
                # Create collage canvas
                collage = Image.new('RGB', (collage_width, collage_height), color='white')
                
                # Add border between cells
                border_size = 2
                
                for row in range(rows):
                    for col in range(cols):
                        # Resize image for this cell
                        cell_img = img.copy()
                        cell_img = cell_img.resize((cell_width, cell_height), Image.Resampling.LANCZOS)
                        
                        # Calculate position with borders
                        x_pos = col * cell_width + (border_size if col > 0 else 0)
                        y_pos = row * cell_height + (border_size if row > 0 else 0)
                        
                        collage.paste(cell_img, (x_pos, y_pos))
                
                random_id = self._generate_random_id()
                output_filename = f"collage_{grid_size}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                collage.save(output_path, "JPEG", quality=95)
            
            # Send collage
            await self._update_progress(processing_msg, "📤 Sending collage...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🖥 Collage Grid**\n**Layout:** {grid_size} ({cols}×{rows})\n**Total Cells:** {cols * rows}",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Collage generation error: {e}")
            await message.reply_text(f"**❌ Error generating collage:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    # ============= NEW PHOTO TOOLS =============
    
    async def adjust_brightness(self, message: Message, user_id: int, factor: str = None):
        """Adjust image brightness"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to adjust brightness**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if factor:
                try:
                    factor_value = float(factor)
                    if factor_value < 0.1 or factor_value > 3.0:
                        return await message.reply_text("**❌ Brightness factor must be between 0.1 and 3.0**")
                except:
                    return await message.reply_text("**❌ Invalid factor! Use format: /brightness 1.5**")
            else:
                factor_value = 1.5  # Default
            
            processing_msg = await message.reply_text("**🌞 Adjusting brightness...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "brightness")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Adjust brightness
            await self._update_progress(processing_msg, "🌞 Adjusting brightness...")
            
            with Image.open(image_path) as img:
                enhancer = ImageEnhance.Brightness(img)
                adjusted_img = enhancer.enhance(factor_value)
                
                random_id = self._generate_random_id()
                output_filename = f"brightness_{factor_value}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                adjusted_img.save(output_path, "JPEG", quality=95)
            
            # Send adjusted image
            await self._update_progress(processing_msg, "📤 Sending adjusted image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🌞 Brightness Adjusted**\n**Factor:** {factor_value}x",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Brightness adjustment error: {e}")
            await message.reply_text(f"**❌ Error adjusting brightness:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    
    async def adjust_contrast(self, message: Message, user_id: int, factor: str = None):
        """Adjust image contrast"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to adjust contrast**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if factor:
                try:
                    factor_value = float(factor)
                    if factor_value < 0.1 or factor_value > 3.0:
                        return await message.reply_text("**❌ Contrast factor must be between 0.1 and 3.0**")
                except:
                    return await message.reply_text("**❌ Invalid factor! Use format: /contrast 1.5**")
            else:
                factor_value = 1.5  # Default
            
            processing_msg = await message.reply_text("**🎨 Adjusting contrast...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "contrast")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Adjust contrast
            await self._update_progress(processing_msg, "🎨 Adjusting contrast...")
            
            with Image.open(image_path) as img:
                enhancer = ImageEnhance.Contrast(img)
                adjusted_img = enhancer.enhance(factor_value)
                
                random_id = self._generate_random_id()
                output_filename = f"contrast_{factor_value}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                adjusted_img.save(output_path, "JPEG", quality=95)
            
            # Send adjusted image
            await self._update_progress(processing_msg, "📤 Sending adjusted image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🎨 Contrast Adjusted**\n**Factor:** {factor_value}x",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Contrast adjustment error: {e}")
            await message.reply_text(f"**❌ Error adjusting contrast:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    
    async def apply_filter(self, message: Message, user_id: int, filter_type: str = None):
        """Apply filter to image"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to apply filter**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            filter_map = {
                'blur': 'BLUR',
                'sharpen': 'SHARPEN',
                'contour': 'CONTOUR',
                'detail': 'DETAIL',
                'edge': 'EDGE_ENHANCE',
                'emboss': 'EMBOSS',
                'smooth': 'SMOOTH',
                'grayscale': 'GRAYSCALE',
                'sepia': 'SEPIA',
                'invert': 'INVERT'
            }
            
            if filter_type:
                if filter_type not in filter_map:
                    return await message.reply_text(
                        f"**❌ Invalid filter! Available filters:**\n{', '.join(filter_map.keys())}"
                    )
            else:
                filter_type = "grayscale"  # Default
            
            processing_msg = await message.reply_text(f"**🎭 Applying {filter_type} filter...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "filter")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Apply filter
            await self._update_progress(processing_msg, f"🎭 Applying {filter_type} filter...")
            
            with Image.open(image_path) as img:
                if filter_type == 'grayscale':
                    filtered_img = img.convert('L').convert('RGB')
                elif filter_type == 'sepia':
                    # Sepia filter implementation
                    sepia_filter = (
                        0.393, 0.769, 0.189,
                        0.349, 0.686, 0.168,
                        0.272, 0.534, 0.131
                    )
                    filtered_img = img.convert('RGB')
                    filtered_img = filtered_img.convert('RGB', sepia_filter)
                elif filter_type == 'invert':
                    filtered_img = ImageOps.invert(img.convert('RGB'))
                else:
                    # Use PIL built-in filters
                    filter_class = getattr(ImageFilter, filter_map[filter_type])
                    filtered_img = img.filter(filter_class)
                
                random_id = self._generate_random_id()
                output_filename = f"filter_{filter_type}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                filtered_img.save(output_path, "JPEG", quality=95)
            
            # Send filtered image
            await self._update_progress(processing_msg, "📤 Sending filtered image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🎭 {filter_type.title()} Filter Applied**",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Filter application error: {e}")
            await message.reply_text(f"**❌ Error applying filter:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    
    async def add_watermark(self, message: Message, user_id: int, text: str = None):
        """Add watermark text to image"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to add watermark**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if not text:
                # Ask for watermark text
                ask_msg = await message.reply_text("**💧 Please send the watermark text**")
                
                try:
                    text_msg = await self.bot.listen(
                        chat_id=message.chat.id,
                        filters=filters.text,
                        timeout=60
                    )
                    text = text_msg.text
                    await ask_msg.delete()
                except asyncio.TimeoutError:
                    await ask_msg.edit_text("**❌ Timeout! No text received.**")
                    return
            
            processing_msg = await message.reply_text("**💧 Adding watermark...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "watermark")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Add watermark
            await self._update_progress(processing_msg, "💧 Adding watermark...")
            
            with Image.open(image_path) as img:
                # Create a copy for watermark
                watermarked = img.copy()
                
                # Prepare text
                draw = ImageDraw.Draw(watermarked)
                
                # Try to load a font
                try:
                    # Try different font paths
                    font_paths = [
                        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
                        "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
                        "arial.ttf"
                    ]
                    
                    font_size = min(img.size) // 20
                    font = None
                    
                    for font_path in font_paths:
                        try:
                            font = ImageFont.truetype(font_path, font_size)
                            break
                        except:
                            continue
                    
                    if font is None:
                        # Use default font
                        font = ImageFont.load_default()
                except:
                    font = ImageFont.load_default()
                
                # Calculate text size and position
                text_bbox = draw.textbbox((0, 0), text, font=font)
                text_width = text_bbox[2] - text_bbox[0]
                text_height = text_bbox[3] - text_bbox[1]
                
                # Position at bottom right with margin
                margin = 20
                x = img.width - text_width - margin
                y = img.height - text_height - margin
                
                # Draw text with shadow for better visibility
                shadow_offset = 2
                draw.text((x + shadow_offset, y + shadow_offset), text, font=font, fill=(0, 0, 0, 128))
                draw.text((x, y), text, font=font, fill=(255, 255, 255, 200))
                
                random_id = self._generate_random_id()
                output_filename = f"watermarked_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                watermarked.save(output_path, "JPEG", quality=95)
            
            # Send watermarked image
            await self._update_progress(processing_msg, "📤 Sending watermarked image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**💧 Watermarked Image**\n**Text:** {text}",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Watermark error: {e}")
            await message.reply_text(f"**❌ Error adding watermark:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    
    async def rotate_image(self, message: Message, user_id: int, angle: str = None):
        """Rotate image by specified angle"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to rotate**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if angle:
                try:
                    angle_value = float(angle)
                    if not -360 <= angle_value <= 360:
                        return await message.reply_text("**❌ Angle must be between -360 and 360 degrees**")
                except:
                    return await message.reply_text("**❌ Invalid angle! Use format: /rotate 90**")
            else:
                angle_value = 90  # Default
            
            processing_msg = await message.reply_text("**🔄 Rotating image...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "rotate")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Rotate image
            await self._update_progress(processing_msg, f"🔄 Rotating {angle_value} degrees...")
            
            with Image.open(image_path) as img:
                # Rotate with expansion to fit the rotated image
                rotated_img = img.rotate(angle_value, expand=True)
                
                random_id = self._generate_random_id()
                output_filename = f"rotated_{angle_value}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                rotated_img.save(output_path, "JPEG", quality=95)
            
            # Send rotated image
            await self._update_progress(processing_msg, "📤 Sending rotated image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🔄 Rotated Image**\n**Angle:** {angle_value}°",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Rotation error: {e}")
            await message.reply_text(f"**❌ Error rotating image:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    async def add_border(self, message: Message, user_id: int, border_size: str = None, color_choice: str = None):
        """Add border to image"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to add border**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if not border_size:
                return await message.reply_text(
                    "**🖼 Add Border**\n\n"
                    "**Usage:** `/border size color`\n"
                    "**Example:** `/border 10 white`\n\n"
                    "**Available Colors:**\n"
                    "white, black, red, green, blue, gray, yellow, pink\n\n"
                    "Reply to an image."
                )
            
            try:
                border = int(border_size)
                if border < 1 or border > 100:
                    return await message.reply_text("**❌ Border size must be between 1 and 100 pixels**")
            except:
                return await message.reply_text("**❌ Invalid border size! Use format: /border 10 white**")
            
            # Set default color if not provided
            if not color_choice:
                color_choice = "white"
            
            color_map = {
                'white': (255, 255, 255),
                'black': (0, 0, 0),
                'red': (255, 0, 0),
                'green': (0, 255, 0),
                'blue': (0, 0, 255),
                'gray': (128, 128, 128),
                'yellow': (255, 255, 0),
                'pink': (255, 192, 203)
            }
            
            if color_choice in color_map:
                border_color = color_map[color_choice]
            else:
                # Try to parse as hex color
                try:
                    hex_color = color_choice.lstrip('#')
                    border_color = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
                except:
                    border_color = (255, 255, 255)  # Default to white
            
            processing_msg = await message.reply_text("**🖼 Adding border...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "border")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Add border
            await self._update_progress(processing_msg, "🖼 Adding border...")
            
            with Image.open(image_path) as img:
                bordered_img = ImageOps.expand(img, border=border, fill=border_color)
                
                random_id = self._generate_random_id()
                output_filename = f"bordered_{border}px_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                bordered_img.save(output_path, "JPEG", quality=95)
            
            # Send bordered image
            await self._update_progress(processing_msg, "📤 Sending bordered image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🖼 Image with Border**\n**Size:** {border}px\n**Color:** {color_choice}",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Border error: {e}")
            await message.reply_text(f"**❌ Error adding border:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)
    async def compress_image(self, message: Message, user_id: int, quality: str = None):
        """Compress image size"""
        image_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an image to compress**")
            
            if not self._is_image_file(message):
                return await message.reply_text("**❌ Please reply to an image!**")
            
            if quality:
                try:
                    quality_value = int(quality)
                    if not 1 <= quality_value <= 100:
                        return await message.reply_text("**❌ Quality must be between 1 and 100**")
                except:
                    return await message.reply_text("**❌ Invalid quality! Use format: /compress 80**")
            else:
                quality_value = 50  # Default compression
            
            processing_msg = await message.reply_text(f"**🗜 Compressing image to {quality_value}% quality...**")
            
            # Download image
            image_path = await self._download_media(message, user_id, "compress")
            
            if not image_path:
                await processing_msg.edit_text("**❌ Failed to download image!**")
                return
            
            # Get original file size
            original_size = os.path.getsize(image_path)
            
            # Compress image
            await self._update_progress(processing_msg, "🗜 Compressing image...")
            
            with Image.open(image_path) as img:
                # Convert to RGB if needed for JPEG
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                random_id = self._generate_random_id()
                output_filename = f"compressed_{quality_value}_{random_id}.jpg"
                output_path = f"downloads/{output_filename}"
                img.save(output_path, "JPEG", quality=quality_value, optimize=True)
            
            # Get compressed file size
            compressed_size = os.path.getsize(output_path)
            reduction = ((original_size - compressed_size) / original_size) * 100
            
            # Send compressed image
            await self._update_progress(processing_msg, "📤 Sending compressed image...")
            try:
                await self.bot.send_photo(
                    message.chat.id,
                    output_path,
                    caption=f"**🗜 Compressed Image**\n"
                           f"**Quality:** {quality_value}%\n"
                           f"**Original:** {humanbytes(original_size)}\n"
                           f"**Compressed:** {humanbytes(compressed_size)}\n"
                           f"**Reduction:** {reduction:.1f}%",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Compression error: {e}")
            await message.reply_text(f"**❌ Error compressing image:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(image_path, output_path)

# ============= CALLBACK HANDLERS =============

@Client.on_callback_query(filters.regex("^ptool:"))
async def photo_tools_callback(client, callback_query):
    """Handle photo tools callback queries"""
    data = callback_query.data
    user_id = callback_query.from_user.id
    message = callback_query.message
    
    # Initialize PhotoTools
    ptools = PhotoTools(client)
    
    try:
        await callback_query.answer()
        
        if data == "ptool:crop":
            await message.reply_text(
                "**✂️ Crop Image**\n\n"
                "**Usage:** `/crop x1,y1,x2,y2`\n"
                "**Example:** `/crop 100,100,500,500`\n\n"
                "Reply to an image with coordinates."
            )
            
        elif data == "ptool:resize":
            await message.reply_text(
                "**🖌 Resize Image**\n\n"
                "**Usage:** `/resize widthxheight` or `/resize percentage`\n"
                "**Example:** `/resize 800x600` or `/resize 50%`\n\n"
                "Reply to an image with dimensions."
            )
            
        elif data == "ptool:convert":
            await ptools.convert_format(message, user_id)
            
        elif data == "ptool:remove_bg":
            await ptools.remove_background(message, user_id)
            
        elif data == "ptool:ratio":
            await message.reply_text(
                "**📏 Crop to Aspect Ratio**\n\n"
                "**Usage:** `/ratio ratio_name`\n"
                "**Ratios:** 16:9, 1:1, 4:3, 9:16, 3:2, 2:3\n"
                "**Example:** `/ratio 1:1`\n\n"
                "Reply to an image with ratio."
            )
            
        elif data == "ptool:collage":
            await message.reply_text(
                "**🖥 Generate Collage**\n\n"
                "**Usage:** `/collage rowsxcols`\n"
                "**Example:** `/collage 2x2`\n\n"
                "Reply to an image."
            )
            
        elif data == "ptool:brightness":
            await ptools.adjust_brightness(message, user_id)
            
        elif data == "ptool:contrast":
            await ptools.adjust_contrast(message, user_id)
            
        elif data == "ptool:filter":
            await message.reply_text(
                "**🎭 Apply Filter**\n\n"
                "**Usage:** `/filter filter_name`\n"
                "**Filters:** blur, sharpen, contour, detail, edge, emboss, smooth, grayscale, sepia, invert\n"
                "**Example:** `/filter grayscale`\n\n"
                "Reply to an image."
            )
            
        elif data == "ptool:watermark":
            await ptools.add_watermark(message, user_id)
            
        elif data == "ptool:rotate":
            await message.reply_text(
                "**🔄 Rotate Image**\n\n"
                "**Usage:** `/rotate angle`\n"
                "**Example:** `/rotate 90`\n\n"
                "Reply to an image."
            )
            
        elif data == "ptool:border":
            await message.reply_text(
                "**🖼 Add Border**\n\n"
                "**Usage:** `/border size`\n"
                "**Example:** `/border 10`\n\n"
                "Reply to an image. You'll be asked for color."
            )
            
        elif data == "ptool:compress":
            await message.reply_text(
                "**🗜 Compress Image**\n\n"
                "**Usage:** `/compress quality`\n"
                "**Quality:** 1-100 (lower = more compression)\n"
                "**Example:** `/compress 50`\n\n"
                "Reply to an image."
            )
            
    except Exception as e:
        logger.error(f"Photo callback error: {e}")
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_callback_query(filters.regex("^pformat:"))
async def photo_format_callback(client, callback_query):
    """Handle photo format selection"""
    data = callback_query.data
    user_id = callback_query.from_user.id
    message = callback_query.message
    
    ptools = PhotoTools(client)
    
    try:
        await callback_query.answer()
        target_format = data.split(":")[1]
        await ptools.convert_format(message, user_id, target_format)
    except Exception as e:
        logger.error(f"Format callback error: {e}")

# ============= PHOTO TOOLS MENU =============

@Client.on_message(filters.command(["phototools", "ptools"]) & filters.private)
async def photo_tools_menu(client, message: Message):
    """Photo tools main menu"""
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✂️ Crop", callback_data="ptool:crop"),
            InlineKeyboardButton("🖌 Resize", callback_data="ptool:resize"),
            InlineKeyboardButton("🖼 Convert", callback_data="ptool:convert")
        ],
        [
            InlineKeyboardButton("🧹 Remove BG", callback_data="ptool:remove_bg"),
            InlineKeyboardButton("📏 Aspect Ratio", callback_data="ptool:ratio"),
            InlineKeyboardButton("🖥 Collage", callback_data="ptool:collage")
        ],
        [
            InlineKeyboardButton("🌞 Brightness", callback_data="ptool:brightness"),
            InlineKeyboardButton("🎨 Contrast", callback_data="ptool:contrast"),
            InlineKeyboardButton("🎭 Filter", callback_data="ptool:filter")
        ],
        [
            InlineKeyboardButton("💧 Watermark", callback_data="ptool:watermark"),
            InlineKeyboardButton("🔄 Rotate", callback_data="ptool:rotate"),
            InlineKeyboardButton("🖼 Border", callback_data="ptool:border")
        ],
        [
            InlineKeyboardButton("🗜 Compress", callback_data="ptool:compress")
        ]
    ])
    
    await message.reply_text(
        "**📸 Photo & Image Tools**\n\n"
        "**Available Tools:**\n"
        "• **Crop** - Crop with coordinates\n"
        "• **Resize** - Change dimensions\n"
        "• **Convert** - Change format (PNG/JPG/WEBP/GIF)\n"
        "• **Remove BG** - Remove background\n"
        "• **Aspect Ratio** - Crop to standard ratios\n"
        "• **Collage** - Create image grid\n"
        "• **Brightness** - Adjust brightness\n"
        "• **Contrast** - Adjust contrast\n"
        "• **Filter** - Apply effects/filters\n"
        "• **Watermark** - Add text watermark\n"
        "• **Rotate** - Rotate image\n"
        "• **Border** - Add colored border\n"
        "• **Compress** - Reduce file size\n\n"
        "**Usage:** Reply to a photo and choose a tool",
        reply_markup=keyboard
    )

# ============= COMMAND HANDLERS =============
@Client.on_message(filters.command(["crop"]) & filters.private)
async def crop_image_cmd(client, message: Message):
    """Crop image command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            coordinates = message.command[1]
            await ptools.crop_image(message, message.from_user.id, coordinates)
        else:
            await message.reply_text(
                "**✂️ Crop Image**\n\n"
                "**Usage:** `/crop x1,y1,x2,y2`\n"
                "**Example:** `/crop 100,100,500,500`\n\n"
                "Reply to an image with coordinates."
            )
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
        
@Client.on_message(filters.command(["convertimage", "imgconvert"]) & filters.private)
async def convert_image_cmd(client, message: Message):
    """Convert image format command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            target_format = message.command[1]
            await ptools.convert_format(message, message.from_user.id, target_format)
        else:
            await ptools.convert_format(message, message.from_user.id)
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["removebg", "nobg"]) & filters.private)
async def remove_bg_cmd(client, message: Message):
    """Remove background command"""
    ptools = PhotoTools(client)
    await ptools.remove_background(message, message.from_user.id)

@Client.on_message(filters.command(["resize"]) & filters.private)
async def resize_image_cmd(client, message: Message):
    """Resize image command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            dimensions = message.command[1]
            await ptools.resize_image(message, message.from_user.id, dimensions)
        else:
            await message.reply_text(
                "**🖌 Resize Image**\n\n"
                "**Usage:** `/resize dimensions`\n"
                "**Formats:**\n"
                "• `widthxheight` (e.g., 800x600)\n"
                "• `percentage` (e.g., 50 or 50%)\n"
                "**Example:** `/resize 800x600` or `/resize 50%`"
            )
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["ratio", "aspect"]) & filters.private)
async def aspect_ratio_cmd(client, message: Message):
    """Aspect ratio crop command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            ratio = message.command[1]
            # Handle custom ratio with additional parameter
            if ratio == 'custom' and len(message.command) > 2:
                # Pass both parameters
                custom_ratio = message.command[2]
                await ptools.crop_to_aspect_ratio(message, message.from_user.id, f"{ratio}:{custom_ratio}")
            else:
                await ptools.crop_to_aspect_ratio(message, message.from_user.id, ratio)
        else:
            await message.reply_text(
                "**📏 Crop to Aspect Ratio**\n\n"
                "**Usage:** `/ratio ratio_name`\n"
                "**Ratios:** 16:9, 1:1, 4:3, 9:16, 3:2, 2:3, 21:9, 5:4, custom\n"
                "**Example:** `/ratio 1:1` or `/ratio custom 16:9`\n\n"
                "Reply to an image with ratio."
            )
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
@Client.on_message(filters.command(["collage", "grid"]) & filters.private)
async def collage_cmd(client, message: Message):
    """Collage generation command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            grid_size = message.command[1]
            await ptools.generate_collage(message, message.from_user.id, grid_size)
        else:
            await message.reply_text(
                "**🖥 Generate Collage**\n\n"
                "**Usage:** `/collage rowsxcols`\n"
                "**Examples:**\n"
                "• `/collage 2x2` (4 cells)\n"
                "• `/collage 3x3` (9 cells)\n"
                "• `/collage 4x3` (12 cells)\n\n"
                "**Max:** 5x5 (25 cells total)\n\n"
                "Reply to an image."
            )
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
# ============= NEW COMMAND HANDLERS =============

@Client.on_message(filters.command(["brightness"]) & filters.private)
async def brightness_cmd(client, message: Message):
    """Brightness adjustment command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            factor = message.command[1]
            await ptools.adjust_brightness(message, message.from_user.id, factor)
        else:
            await ptools.adjust_brightness(message, message.from_user.id)
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["contrast"]) & filters.private)
async def contrast_cmd(client, message: Message):
    """Contrast adjustment command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            factor = message.command[1]
            await ptools.adjust_contrast(message, message.from_user.id, factor)
        else:
            await ptools.adjust_contrast(message, message.from_user.id)
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["filter"]) & filters.private)
async def filter_cmd(client, message: Message):
    """Filter application command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            filter_type = message.command[1]
            await ptools.apply_filter(message, message.from_user.id, filter_type)
        else:
            await ptools.apply_filter(message, message.from_user.id)
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["watermark", "wm"]) & filters.private)
async def watermark_cmd(client, message: Message):
    """Watermark command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            text = ' '.join(message.command[1:])
            await ptools.add_watermark(message, message.from_user.id, text)
        else:
            await ptools.add_watermark(message, message.from_user.id)
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["rotate"]) & filters.private)
async def rotate_cmd(client, message: Message):
    """Rotate command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            angle = message.command[1]
            await ptools.rotate_image(message, message.from_user.id, angle)
        else:
            await ptools.rotate_image(message, message.from_user.id)
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["border"]) & filters.private)
async def border_cmd(client, message: Message):
    """Border command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            border_size = message.command[1]
            color_choice = message.command[2] if len(message.command) > 2 else "white"
            await ptools.add_border(message, message.from_user.id, border_size, color_choice)
        else:
            await message.reply_text(
                "**🖼 Add Border**\n\n"
                "**Usage:** `/border size color`\n"
                "**Example:** `/border 10 white`\n\n"
                "**Available Colors:**\n"
                "white, black, red, green, blue, gray, yellow, pink\n\n"
                "Reply to an image."
            )
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
@Client.on_message(filters.command(["compress", "compact"]) & filters.private)
async def compress_cmd(client, message: Message):
    """Compress command"""
    try:
        ptools = PhotoTools(client)
        
        if len(message.command) > 1:
            quality = message.command[1]
            await ptools.compress_image(message, message.from_user.id, quality)
        else:
            await ptools.compress_image(message, message.from_user.id)
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

# ============= HELP COMMAND =============

@Client.on_message(filters.command(["photohelp", "imgtools"]) & filters.private)
async def photo_help_cmd(client, message: Message):
    """Show all photo tools commands"""
    help_text = """
**📸 PHOTO TOOLS - ALL COMMANDS**

**📋 Basic Tools:**
• `/phototools` - Show interactive menu
• `/crop x1,y1,x2,y2` - Crop image with coordinates
• `/resize dimensions` - Resize image (800x600 or 50%)
• `/convertimage format` - Convert format (png/jpg/webp/gif)
• `/removebg` - Remove background
• `/ratio ratio` - Crop to aspect ratio (16:9, 1:1, etc.)
• `/collage grid` - Create collage (2x2, 3x3, etc.)

**🎨 Editing Tools:**
• `/brightness factor` - Adjust brightness (0.1-3.0)
• `/contrast factor` - Adjust contrast (0.1-3.0)
• `/filter type` - Apply filter (grayscale, blur, sepia, etc.)
• `/watermark text` - Add text watermark
• `/rotate angle` - Rotate image (-360 to 360)
• `/border size` - Add colored border
• `/compress quality` - Compress image (1-100)

**🎭 Available Filters:**
blur, sharpen, contour, detail, edge, emboss, smooth, grayscale, sepia, invert

**📏 Aspect Ratios:**
16:9, 1:1, 4:3, 9:16, 3:2, 2:3, 21:9, 5:4, custom

**📁 Supported Formats:**
PNG, JPG, JPEG, WEBP, GIF, BMP, ICO, TIFF

**📌 Usage:**
1. Reply to an image
2. Use any command
3. Wait for processing
4. Receive edited image

**⚡ Features:**
• Clean filenames (no user IDs)
• Progress bar during download
• Auto-cleanup of temp files
• High-quality processing
• Interactive menus
"""
    
    await message.reply_text(help_text)
