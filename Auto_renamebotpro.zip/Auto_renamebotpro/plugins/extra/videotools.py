import os
import asyncio
import logging
import json
import time
import random
import string
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
# Add this import at the top of videotools.py
from helper.utils import humanbytes, progress_for_pyrogram, convert, TimeFormatter
from config import Config

logger = logging.getLogger(__name__)

class VideoTools:
    def __init__(self, bot: Client):
        self.bot = bot
        
    def _generate_random_id(self, length=8):
        """Generate random ID for filenames"""
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    
    def _is_video_file(self, message: Message) -> bool:
        """Check if the replied message contains a video file"""
        if not message.reply_to_message:
            return False
            
        msg = message.reply_to_message
        
        # Check for video message
        if msg.video:
            return True
            
        # Check for document with video mime type
        if msg.document:
            mime_type = msg.document.mime_type or ""
            file_name = msg.document.file_name or ""
            
            # Check mime type
            if 'video' in mime_type.lower():
                return True
                
            # Check file extension
            video_extensions = ['.mp4', '.mkv', '.avi', '.mov', '.webm', '.flv', '.wmv', '.m4v', '.mpg', '.mpeg', '.3gp']
            if any(file_name.lower().endswith(ext) for ext in video_extensions):
                return True
                
        return False
    def _is_audio_file(self, message: Message) -> bool:
        """Check if the message contains an audio file"""
        if not message:
            return False
            
        # Check for audio message
        if hasattr(message, 'audio') and message.audio:
            return True
            
        # Check for voice message
        if hasattr(message, 'voice') and message.voice:
            return True
            
        # Check for video note (round video)
        if hasattr(message, 'video_note') and message.video_note:
            return True
            
        # Check for document with audio mime type
        if hasattr(message, 'document') and message.document:
            mime_type = message.document.mime_type or ""
            file_name = message.document.file_name or ""
            
            # Check mime type
            if mime_type and 'audio' in mime_type.lower():
                return True
                
            # Check file extension
            audio_extensions = ['.mp3', '.m4a', '.flac', '.opus', '.wav', '.aac', '.ogg', '.wma', '.mka']
            if file_name and any(file_name.lower().endswith(ext) for ext in audio_extensions):
                return True
                
            # Check for audio file by name pattern
            audio_patterns = ['audio', 'music', 'song', 'track', 'sound']
            if file_name and any(pattern in file_name.lower() for pattern in audio_patterns):
                return True
        
        return False
        
    def _is_media_file(self, message: Message) -> bool:
        """Check if the replied message contains any media file"""
        if not message.reply_to_message:
            return False
            
        msg = message.reply_to_message
        return bool(msg.video or msg.document or msg.audio or msg.voice or msg.video_note)
    async def _download_audio_message(self, audio_message, user_id: int, operation: str) -> str:
        """Download audio from message object (not wrapper)"""
        try:
            random_id = self._generate_random_id()
            
            # Determine file type and extension
            if audio_message.audio:
                media = audio_message.audio
                file_name = media.file_name or "audio"
                ext = os.path.splitext(file_name)[1] or ".mp3"
            elif audio_message.document:
                media = audio_message.document
                file_name = media.file_name or "document"
                ext = os.path.splitext(file_name)[1] or ".mp3"
            elif audio_message.voice:
                media = audio_message.voice
                ext = ".ogg"  # Telegram voice messages are OGG
            else:
                return None
            
            # Create downloads directory if not exists
            os.makedirs("downloads", exist_ok=True)
            
            # Generate clean filename
            clean_filename = f"{operation}_{random_id}{ext}"
            file_path = f"downloads/{clean_filename}"
            
            # Simple download without progress
            try:
                download_path = await self.bot.download_media(
                    message=audio_message,
                    file_name=file_path
                )
                
                if download_path and os.path.exists(download_path) and os.path.getsize(download_path) > 0:
                    return download_path
                return None
                
            except Exception as download_error:
                logger.error(f"Audio download failed: {download_error}")
                return None
            
        except Exception as e:
            logger.error(f"Audio download setup error: {e}")
            return None
    async def _download_media(self, message: Message, user_id: int, operation: str) -> str:
        """Download media from replied message WITH progress"""
        try:
            if not message.reply_to_message:
                return None
            
            msg = message.reply_to_message
            random_id = self._generate_random_id()
            
            # Determine file type and extension
            if msg.video:
                media = msg.video
                ext = os.path.splitext(media.file_name or "video.mp4")[1] or ".mp4"
            elif msg.document:
                media = msg.document
                file_name = media.file_name or "document"
                ext = os.path.splitext(file_name)[1]
                if not ext:
                    # Guess extension from mime type
                    if media.mime_type:
                        if 'video' in media.mime_type:
                            ext = '.mp4'
                        elif 'audio' in media.mime_type:
                            ext = '.mp3'
                        else:
                            ext = '.mkv'  # Default to MKV for documents
                    else:
                        ext = '.mkv'  # Default to MKV
            elif msg.audio:
                media = msg.audio
                file_name = media.file_name or "audio"
                ext = os.path.splitext(file_name)[1] or ".mp3"
            else:
                return None
            
            # Create downloads directory if not exists
            os.makedirs("downloads", exist_ok=True)
            
            # Generate clean filename
            clean_filename = f"{operation}_{random_id}{ext}"
            file_path = f"downloads/{clean_filename}"
            
            # Download with progress using YOUR progress function
            download_msg = await message.reply_text(f"**⬇️ Downloading file for {operation.replace('_', ' ')}...**")
            
            start_time = time.time()
            
            # Define progress callback wrapper
            async def progress_callback(current, total):
                try:
                    await progress_for_pyrogram(
                        current, total, 
                        f"Downloading for {operation.replace('_', ' ')}...", 
                        download_msg, 
                        start_time
                    )
                except Exception as prog_error:
                    logger.debug(f"Progress callback error (non-critical): {prog_error}")
            
            # Try to download with progress
            try:
                download_path = await self.bot.download_media(
                    message=msg,
                    file_name=file_path,
                    progress=progress_callback
                )
            except Exception as download_error:
                logger.error(f"Download failed: {download_error}")
                try:
                    await download_msg.delete()
                except:
                    pass
                return None
            
            # Delete progress message on success
            try:
                await download_msg.delete()
            except:
                pass
            
            if download_path and os.path.exists(download_path):
                return download_path
            return None
            
        except Exception as e:
            logger.error(f"Download error: {e}")
            return None

    async def _cleanup_files(self, *paths):
        """Clean up temporary files with error handling"""
        for path in paths:
            try:
                if path and os.path.exists(path):
                    os.remove(path)
                    logger.debug(f"Cleaned up: {path}")
            except Exception as e:
                logger.error(f"Cleanup error for {path}: {e}")
    
    async def _update_progress(self, message: Message, text: str):
        """Update progress message"""
        try:
            await message.edit_text(f"**{text}**")
        except:
            pass
    
    async def extract_subtitle(self, message: Message, user_id: int):
        """Extract subtitle from video file"""
        video_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file to extract subtitles**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            processing_msg = await message.reply_text("**📄 Extracting subtitles...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "sub_extract")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Check for subtitles
            await self._update_progress(processing_msg, "🔍 Checking for subtitles...")
            
            ffprobe_cmd = [
                'ffprobe', '-v', 'quiet', '-select_streams', 's',
                '-show_entries', 'stream=index,codec_name:stream_tags=language',
                '-of', 'json', video_path
            ]
            
            process = await asyncio.create_subprocess_exec(
                *ffprobe_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await process.communicate()
            
            subtitle_streams = []
            if process.returncode == 0:
                data = json.loads(stdout.decode())
                subtitle_streams = data.get('streams', [])
            
            if not subtitle_streams:
                await processing_msg.edit_text("**❌ No subtitle streams found in the video!**")
                await self._cleanup_files(video_path)
                return
            
            # Extract subtitles
            await self._update_progress(processing_msg, f"📥 Extracting {len(subtitle_streams)} subtitle stream(s)...")
            
            extracted_subs = []
            for stream in subtitle_streams:
                stream_index = stream['index']
                codec = stream.get('codec_name', 'unknown')
                language = stream.get('tags', {}).get('language', 'eng')
                
                sub_ext = {
                    'srt': '.srt',
                    'ass': '.ass', 
                    'webvtt': '.vtt',
                    'mov_text': '.srt'
                }.get(codec, '.txt')
                
                random_id = self._generate_random_id()
                sub_filename = f"subtitle_{language}_{random_id}{sub_ext}"
                sub_path = f"downloads/{sub_filename}"
                
                ffmpeg_cmd = [
                    'ffmpeg', '-i', video_path,
                    '-map', f'0:{stream_index}',
                    '-c', 'copy', '-y', sub_path
                ]
                
                process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
                await process.wait()
                
                if os.path.exists(sub_path) and os.path.getsize(sub_path) > 0:
                    extracted_subs.append((sub_path, language, codec, sub_filename))
            
            if not extracted_subs:
                await processing_msg.edit_text("**❌ Failed to extract subtitles!**")
                await self._cleanup_files(video_path)
                return
            
            # Send extracted subtitles
            await self._update_progress(processing_msg, f"📤 Sending {len(extracted_subs)} subtitle file(s)...")
            
            for sub_path, lang, codec, filename in extracted_subs:
                caption = f"**📄 Extracted Subtitle**\n**Language:** {lang.upper()}\n**Format:** {codec.upper()}"
                try:
                    await self.bot.send_document(
                        chat_id=message.chat.id,
                        document=sub_path,
                        caption=caption,
                        file_name=filename
                    )
                finally:
                    # Cleanup after sending each subtitle
                    await self._cleanup_files(sub_path)
            
            await processing_msg.delete()
            
        except Exception as e:
            logger.error(f"Subtitle extraction error: {e}")
            await message.reply_text(f"**❌ Error extracting subtitles:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            if video_path:
                await self._cleanup_files(video_path)
    
    async def extract_audio(self, message: Message, user_id: int):
        """Extract audio from video file"""
        video_path = None
        audio_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file to extract audio**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            processing_msg = await message.reply_text("**🎵 Extracting audio...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "audio_extract")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Extract audio
            await self._update_progress(processing_msg, "🎵 Extracting audio stream...")
            
            random_id = self._generate_random_id()
            audio_filename = f"extracted_audio_{random_id}.mp3"
            audio_path = f"downloads/{audio_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', video_path,
                '-q:a', '0', '-map', 'a',
                '-y', audio_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(audio_path) or os.path.getsize(audio_path) == 0:
                await processing_msg.edit_text("**❌ No audio stream found or extraction failed!**")
                return
            
            # Send extracted audio
            await self._update_progress(processing_msg, "📤 Sending extracted audio...")
            try:
                await self.bot.send_audio(
                    chat_id=message.chat.id,
                    audio=audio_path,
                    caption="**🎵 Audio extracted from video**",
                    file_name=audio_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Audio extraction error: {e}")
            await message.reply_text(f"**❌ Error extracting audio:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(video_path, audio_path)
    
    async def convert_format(self, message: Message, user_id: int, target_format: str):
        """Convert video to different format"""
        video_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file to convert**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            valid_formats = ['mp4', 'mkv', 'avi', 'mov', 'webm']
            if target_format not in valid_formats:
                return await message.reply_text(
                    f"**❌ Invalid format! Supported formats:** {', '.join(valid_formats)}"
                )
            
            processing_msg = await message.reply_text(f"**🎬 Converting to {target_format.upper()}...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "convert")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Convert format
            await self._update_progress(processing_msg, f"🔄 Converting to {target_format.upper()}...")
            
            random_id = self._generate_random_id()
            output_filename = f"converted_{random_id}.{target_format}"
            output_path = f"downloads/{output_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', video_path,
                '-c', 'copy',  # Copy streams without re-encoding when possible
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path):
                # Try with re-encoding if copy fails
                ffmpeg_cmd = [
                    'ffmpeg', '-i', video_path,
                    '-c:v', 'libx264', '-c:a', 'aac',
                    '-y', output_path
                ]
                process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
                await process.wait()
            
            if not os.path.exists(output_path):
                await processing_msg.edit_text("**❌ Conversion failed!**")
                return
            
            # Send converted video
            await self._update_progress(processing_msg, "📤 Sending converted video...")
            try:
                await self.bot.send_video(
                    chat_id=message.chat.id,
                    video=output_path,
                    caption=f"**🎬 Converted to {target_format.upper()} format**",
                    supports_streaming=True,
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Format conversion error: {e}")
            await message.reply_text(f"**❌ Error converting format:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(video_path, output_path)
    
    async def trim_video(self, message: Message, user_id: int, start_time: str, end_time: str):
        """Trim/cut video between specified times"""
        video_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file to trim**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            processing_msg = await message.reply_text("**✂️ Trimming video...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "trim")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Convert time format
            def parse_time(time_str):
                if ':' in time_str:
                    parts = time_str.split(':')
                    if len(parts) == 3:  # HH:MM:SS
                        return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
                    elif len(parts) == 2:  # MM:SS
                        return int(parts[0]) * 60 + int(parts[1])
                return int(time_str)  # Assume seconds
            
            try:
                start_seconds = parse_time(start_time)
                end_seconds = parse_time(end_time)
                duration = end_seconds - start_seconds
                
                if duration <= 0:
                    await processing_msg.edit_text("**❌ Invalid time range!**")
                    return
            except ValueError:
                await processing_msg.edit_text("**❌ Invalid time format! Use: seconds, MM:SS, or HH:MM:SS**")
                return
            
            # Trim video
            await self._update_progress(processing_msg, "✂️ Trimming video...")
            
            random_id = self._generate_random_id()
            output_filename = f"trimmed_{random_id}.mp4"
            output_path = f"downloads/{output_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-ss', str(start_seconds), '-i', video_path,
                '-t', str(duration), '-c', 'copy',
                '-avoid_negative_ts', 'make_zero',
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path):
                await processing_msg.edit_text("**❌ Trimming failed!**")
                return
            
            # Send trimmed video
            await self._update_progress(processing_msg, "📤 Sending trimmed video...")
            try:
                await self.bot.send_video(
                    chat_id=message.chat.id,
                    video=output_path,
                    caption=f"**✂️ Trimmed Video**\n**From:** {start_time}\n**To:** {end_time}\n**Duration:** {duration}s",
                    duration=int(duration),
                    supports_streaming=True,
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Video trim error: {e}")
            await message.reply_text(f"**❌ Error trimming video:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(video_path, output_path)
    
    async def remove_audio_or_sub(self, message: Message, user_id: int, remove_type: str):
        """Remove audio or subtitles from video"""
        video_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            processing_msg = await message.reply_text(f"**🚫 Removing {remove_type}...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, f"remove_{remove_type}")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Remove audio/subtitles
            await self._update_progress(processing_msg, f"🚫 Removing {remove_type}...")
            
            random_id = self._generate_random_id()
            operation = "muted" if remove_type == 'audio' else "no_subs"
            output_filename = f"{operation}_{random_id}.mp4"
            output_path = f"downloads/{output_filename}"
            
            if remove_type == 'audio':
                ffmpeg_cmd = [
                    'ffmpeg', '-i', video_path,
                    '-c', 'copy', '-an',  # Remove audio
                    '-y', output_path
                ]
            else:  # subtitles
                ffmpeg_cmd = [
                    'ffmpeg', '-i', video_path,
                    '-c', 'copy', '-sn',  # Remove subtitles
                    '-y', output_path
                ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path):
                await processing_msg.edit_text(f"**❌ Failed to remove {remove_type}!**")
                return
            
            # Send processed video
            await self._update_progress(processing_msg, "📤 Sending processed video...")
            try:
                await self.bot.send_video(
                    chat_id=message.chat.id,
                    video=output_path,
                    caption=f"**🚫 Video with {remove_type} removed**",
                    supports_streaming=True,
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Remove {remove_type} error: {e}")
            await message.reply_text(f"**❌ Error removing {remove_type}:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(video_path, output_path)
    # ============= NEW COMMANDS =============
    async def add_audio(self, message: Message, user_id: int):
        """Add/merge audio to video"""
        video_path = None
        audio_path = None
        output_path = None
        
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            # Store the message ID and wait for user to send audio
            ask_msg = await message.reply_text(
                "**🎵 Now please send/reply with the audio file to add**\n"
                "**Note:** You have 60 seconds to send the audio file.\n"
                "Send /cancel to cancel this operation."
            )
            
            # We'll use a different approach - just instruct user to use command with audio
            return  # We'll handle this differently
            
        except Exception as e:
            logger.error(f"Add audio error: {e}")
            await message.reply_text(f"**❌ Error adding audio:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(video_path, audio_path, output_path)
    async def merge_audio_video(self, video_message: Message, audio_message: Message, user_id: int):
        """Merge audio with video - FIXED VERSION"""
        video_path = None
        audio_path = None
        output_path = None
        
        try:
            processing_msg = await video_message.reply_text("**🔄 Merging audio with video...**")
            
            # Download video
            video_path = await self._download_media(video_message, user_id, "merge_video")
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Get original video duration
            video_duration = None
            if video_message.reply_to_message and video_message.reply_to_message.video:
                video_duration = video_message.reply_to_message.video.duration
            
            # Download audio
            audio_path = await self._download_audio_message(audio_message, user_id, "merge_audio")
            if not audio_path:
                await processing_msg.edit_text("**❌ Failed to download audio!**")
                await self._cleanup_files(video_path)
                return
            
            # Check if audio is valid
            await self._update_progress(processing_msg, "🔍 Validating audio file...")
            
            # Merge audio with video - ALWAYS USE MKV FOR BETTER COMPATIBILITY
            await self._update_progress(processing_msg, "🔄 Merging audio with video...")
            
            random_id = self._generate_random_id()
            output_filename = f"video_with_audio_{random_id}.mkv"  # MKV format
            output_path = f"downloads/{output_filename}"
            
            # Use ffmpeg to merge - preserve full video duration
            ffmpeg_cmd = [
                'ffmpeg',
                '-i', video_path,      # Input video
                '-i', audio_path,      # Input audio
                '-c:v', 'copy',        # Copy video codec (no re-encoding)
                '-c:a', 'aac',         # Convert audio to AAC
                '-map', '0:v:0',       # Use first video stream
                '-map', '1:a:0',       # Use first audio stream
                '-shortest',           # End with shortest stream (keeps video duration)
                '-y',                  # Overwrite output
                output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                await processing_msg.edit_text("**❌ Failed to merge audio!**")
                await self._cleanup_files(video_path, audio_path)
                return
            
            # Send merged video WITH PROGRESS BAR
            await self._update_progress(processing_msg, "📤 Sending video with new audio...")
            
            start_time = time.time()
            
            async def upload_progress(current, total):
                try:
                    await progress_for_pyrogram(
                        current, total,
                        "Uploading merged video...",
                        processing_msg,
                        start_time
                    )
                except:
                    pass
            
            # Check file size to determine if we should send as document
            file_size = os.path.getsize(output_path)
            max_video_size = 100 * 1024 * 1024  # 50MB Telegram limit
            
            if file_size > max_video_size:
                # Send as document for large files
                await self.bot.send_document(
                    chat_id=video_message.chat.id,
                    document=output_path,
                    caption="**🎵 Video with new audio added**\n**Format:** MKV (sent as document due to size)",
                    file_name=output_filename,
                    progress=upload_progress
                )
            else:
                # Send as video
                await self.bot.send_video(
                    chat_id=video_message.chat.id,
                    video=output_path,
                    caption="**🎵 Video with new audio added**\n**Format:** MKV",
                    supports_streaming=True,
                    duration=video_duration,
                    file_name=output_filename,
                    progress=upload_progress
                )
            
            await processing_msg.delete()
            
        except Exception as e:
            logger.error(f"Audio merge error: {e}")
            await video_message.reply_text(f"**❌ Error merging audio:** `{str(e)[:200]}`")
        finally:
            # Cleanup
            await self._cleanup_files(video_path, audio_path, output_path)
    async def change_audio_stream(self, message: Message, user_id: int, stream_index: str):
        """Change default audio stream in video"""
        video_path = None
        output_path = None
        
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            # Get available audio streams
            processing_msg = await message.reply_text("**🔍 Checking audio streams...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "audio_streams")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Check audio streams
            ffprobe_cmd = [
                'ffprobe', '-v', 'quiet',
                '-select_streams', 'a',
                '-show_entries', 'stream=index,codec_name,channels,sample_rate:stream_tags=language',
                '-of', 'json', video_path
            ]
            
            process = await asyncio.create_subprocess_exec(
                *ffprobe_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                await processing_msg.edit_text("**❌ Failed to analyze audio streams!**")
                return
            
            data = json.loads(stdout.decode())
            audio_streams = data.get('streams', [])
            
            if not audio_streams:
                await processing_msg.edit_text("**❌ No audio streams found in video!**")
                return
            
            # If stream_index is "list", show available streams
            if stream_index == "list":
                streams_info = []
                for i, stream in enumerate(audio_streams):
                    lang = stream.get('tags', {}).get('language', 'unknown')
                    codec = stream.get('codec_name', 'unknown')
                    channels = stream.get('channels', '?')
                    streams_info.append(
                        f"**{i+1}.** Language: `{lang.upper()}` | "
                        f"Codec: `{codec.upper()}` | "
                        f"Channels: `{channels}`"
                    )
                
                await processing_msg.edit_text(
                    f"**🎵 Available Audio Streams**\n\n" +
                    "\n".join(streams_info) +
                    f"\n\n**Usage:** `/audiostream <number>`\n"
                    f"**Example:** `/audiostream 2` to use second audio stream"
                )
                await self._cleanup_files(video_path)
                return
            
            # Convert stream number to index
            try:
                stream_num = int(stream_index)
                if stream_num < 1 or stream_num > len(audio_streams):
                    await processing_msg.edit_text(
                        f"**❌ Invalid stream number! Available: 1-{len(audio_streams)}**"
                    )
                    return
                
                selected_index = audio_streams[stream_num - 1]['index']
                lang = audio_streams[stream_num - 1].get('tags', {}).get('language', 'unknown')
                
            except ValueError:
                await processing_msg.edit_text("**❌ Invalid stream number! Use: `/audiostream list` to see available**")
                return
            
            # Change audio stream
            await self._update_progress(processing_msg, f"🔄 Changing to audio stream {stream_num}...")
            
            random_id = self._generate_random_id()
            output_filename = f"audio_stream_{stream_num}_{random_id}.mp4"
            output_path = f"downloads/{output_filename}"
            
            # Map only the selected audio stream
            ffmpeg_cmd = [
                'ffmpeg', '-i', video_path,
                '-map', '0:v',                    # All video streams
                '-map', f'0:a:{selected_index}',  # Selected audio stream
                '-c', 'copy',                     # Copy without re-encoding
                '-disposition:a', 'default',      # Make it default
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path):
                await processing_msg.edit_text("**❌ Failed to change audio stream!**")
                return
            
            # Send processed video
            await self._update_progress(processing_msg, "📤 Sending video...")
            
            await self.bot.send_video(
                chat_id=message.chat.id,
                video=output_path,
                caption=f"**🎵 Video with audio stream {stream_num}**\nLanguage: `{lang.upper()}`",
                supports_streaming=True,
                file_name=output_filename
            )
            
            await processing_msg.delete()
            
        except Exception as e:
            logger.error(f"Audio stream change error: {e}")
            await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
        finally:
            await self._cleanup_files(video_path, output_path)
    async def reverse_video(self, message: Message, user_id: int):
        """Create reversed video"""
        video_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            processing_msg = await message.reply_text("**↪️ Reversing video...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "reverse")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Reverse video
            await self._update_progress(processing_msg, "↪️ Reversing video...")
            
            random_id = self._generate_random_id()
            output_filename = f"reversed_{random_id}.mp4"
            output_path = f"downloads/{output_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-y',
                '-i', video_path,
                '-filter_complex', '[0:v]reverse[v];[0:a]areverse[a]',
                '-map', '[v]', '-map', '[a]',
                '-c:v', 'libx264', '-preset', 'fast', '-crf', '18',
                '-pix_fmt', 'yuv420p',
                '-movflags', '+faststart',
                '-tune', 'fastdecode',
                '-c:a', 'aac', '-b:a', '128k',
                output_path
            ]

            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path):
                await processing_msg.edit_text("**❌ Failed to reverse video!**")
                return
            
            # Send reversed video
            await self._update_progress(processing_msg, "📤 Sending reversed video...")
            try:
                await self.bot.send_video(
                    chat_id=message.chat.id,
                    video=output_path,
                    caption="**↪️ Reversed Video**",
                    supports_streaming=True,
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Reverse video error: {e}")
            await message.reply_text(f"**❌ Error reversing video:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(video_path, output_path)
    async def rotate_video(self, message: Message, user_id: int, angle: str):
        """Rotate video by specified angle"""
        video_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            valid_angles = ['90', '180', '270']
            if angle not in valid_angles:
                return await message.reply_text(
                    f"**❌ Invalid angle! Valid angles:** {', '.join(valid_angles)}"
                )
            
            processing_msg = await message.reply_text(f"**🔄 Rotating video {angle}°...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "rotate")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Rotate video
            await self._update_progress(processing_msg, f"🔄 Rotating video {angle}°...")
            
            random_id = self._generate_random_id()
            output_filename = f"rotated_{angle}_{random_id}.mp4"
            output_path = f"downloads/{output_filename}"
            
            # Determine rotation filter based on angle
            if angle == '90':
                rotate_filter = 'transpose=1'  # 90° clockwise
            elif angle == '180':
                rotate_filter = 'transpose=2,transpose=2'  # 180°
            elif angle == '270':
                rotate_filter = 'transpose=2'  # 90° counter-clockwise (270° clockwise)
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', video_path,
                '-vf', rotate_filter,
                '-c:a', 'copy',  # Copy audio without re-encoding
                '-metadata:s:v', f'rotate={angle}',
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path):
                # Try alternative method if first fails
                ffmpeg_cmd = [
                    'ffmpeg', '-i', video_path,
                    '-vf', f'rotate={angle}*PI/180',
                    '-c:a', 'copy',
                    '-y', output_path
                ]
                process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
                await process.wait()
            
            if not os.path.exists(output_path):
                await processing_msg.edit_text("**❌ Failed to rotate video!**")
                return
            
            # Send rotated video
            await self._update_progress(processing_msg, "📤 Sending rotated video...")
            try:
                await self.bot.send_video(
                    chat_id=message.chat.id,
                    video=output_path,
                    caption=f"**🔄 Video Rotated {angle}°**",
                    supports_streaming=True,
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Video rotate error: {e}")
            await message.reply_text(f"**❌ Error rotating video:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(video_path, output_path)

    async def split_video(self, message: Message, user_id: int, parts: str):
        """Split video into multiple equal parts"""
        video_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to a video file**")
            
            if not self._is_video_file(message):
                return await message.reply_text("**❌ Please reply to a video file!**")
            
            try:
                num_parts = int(parts)
                if num_parts < 2 or num_parts > 20:
                    return await message.reply_text("**❌ Number of parts must be between 2 and 20!**")
            except ValueError:
                return await message.reply_text("**❌ Invalid number! Use: `/split 2` or `/split 5`**")
            
            processing_msg = await message.reply_text(f"**✂️ Splitting video into {num_parts} equal parts...**")
            
            # Download video
            video_path = await self._download_media(message, user_id, "split")
            
            if not video_path:
                await processing_msg.edit_text("**❌ Failed to download video!**")
                return
            
            # Get video duration
            await self._update_progress(processing_msg, "⏱️ Calculating video duration...")
            
            ffprobe_cmd = [
                'ffprobe', '-v', 'error',
                '-show_entries', 'format=duration',
                '-of', 'default=noprint_wrappers=1:nokey=1',
                video_path
            ]
            
            process = await asyncio.create_subprocess_exec(
                *ffprobe_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                await processing_msg.edit_text("**❌ Failed to get video duration!**")
                return
            
            try:
                total_duration = float(stdout.decode().strip())
            except ValueError:
                await processing_msg.edit_text("**❌ Could not determine video duration!**")
                return
            
            if total_duration < num_parts:  # Video too short for splitting
                await processing_msg.edit_text(f"**❌ Video is too short ({total_duration:.1f}s) to split into {num_parts} parts!**")
                return
            
            # Calculate equal part duration
            part_duration = total_duration / num_parts
            
            await self._update_progress(processing_msg, f"✂️ Splitting into {num_parts} equal parts...")
            
            random_id = self._generate_random_id()
            output_files = []
            
            for i in range(num_parts):
                part_num = i + 1
                start_time = i * part_duration
                
                output_filename = f"part_{part_num}_{random_id}.mp4"
                output_path = f"downloads/{output_filename}"
                
                # Update progress
                await self._update_progress(
                    processing_msg, 
                    f"✂️ Processing part {part_num}/{num_parts}..."
                )
                
                # Split using ffmpeg
                ffmpeg_cmd = [
                    'ffmpeg', '-y',
                    '-ss', str(start_time),
                    '-i', video_path,
                    '-t', str(part_duration),
                    '-c', 'copy',  # Copy without re-encoding
                    '-avoid_negative_ts', 'make_zero',
                    output_path
                ]
                
                split_process = await asyncio.create_subprocess_exec(
                    *ffmpeg_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                await split_process.wait()
                
                if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                    # Get actual duration of this part
                    duration_cmd = [
                        'ffprobe', '-v', 'error',
                        '-show_entries', 'format=duration',
                        '-of', 'default=noprint_wrappers=1:nokey=1',
                        output_path
                    ]
                    duration_process = await asyncio.create_subprocess_exec(
                        *duration_cmd,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout2, _ = await duration_process.communicate()
                    part_actual_duration = float(stdout2.decode().strip()) if duration_process.returncode == 0 else part_duration
                    
                    output_files.append({
                        'path': output_path,
                        'part': part_num,
                        'filename': output_filename,
                        'duration': part_actual_duration,
                        'start': start_time
                    })
                else:
                    logger.error(f"Failed to create part {part_num}")
            
            if not output_files:
                await processing_msg.edit_text("**❌ Failed to split video!**")
                return
            
            # Send all parts
            await self._update_progress(processing_msg, f"📤 Sending {len(output_files)} video parts...")
            
            for part_info in output_files:
                try:
                    # Use convert function for proper time formatting
                    duration_formatted = convert(int(part_info['duration']))
                    start_formatted = convert(int(part_info['start']))
                    
                    await self.bot.send_video(
                        chat_id=message.chat.id,
                        video=part_info['path'],
                        caption=(
                            f"**✂️ Part {part_info['part']}/{num_parts}**\n"
                            f"**Duration:** {duration_formatted}\n"
                            f"**Start:** {start_formatted}"
                        ),
                        supports_streaming=True,
                        file_name=part_info['filename']
                    )
                except Exception as e:
                    logger.error(f"Failed to send part {part_info['part']}: {e}")
                finally:
                    # Cleanup after sending each part
                    await self._cleanup_files(part_info['path'])
            
            await processing_msg.edit_text(
                f"**✅ Successfully split video into {len(output_files)} equal parts!**\n"
                f"**Total Duration:** {total_duration:.1f}s\n"
                f"**Each Part:** ~{part_duration:.1f}s\n"
                f"**Parts Created:** {len(output_files)}/{num_parts}"
            )
            
        except Exception as e:
            logger.error(f"Video split error: {e}")
            await message.reply_text(f"**❌ Error splitting video:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            if video_path:
                await self._cleanup_files(video_path)
    async def create_tg_gif(self, message: Message, user_id: int, start_time=None, duration=None):
        """Create Telegram optimized GIF (MP4 h264 animation tuned)"""
        video_path = None
        output_path = None
        passlog = None

        try:
            if not message.reply_to_message:
                return await message.reply_text("❌ Reply to a video!")

            processing_msg = await message.reply("⚙️ Processing...")

            # Download media
            video_path = await self._download_media(message, user_id, "tg_gif")
            
            if not video_path:
                await processing_msg.edit_text("❌ Failed to download video!")
                return

            random_id = self._generate_random_id()
            output_path = f"downloads/tg_gif_{random_id}.mp4"
            passlog = f"downloads/passlog_{random_id}.log"

            # Set default values if not provided
            if not start_time:
                start_time = "0"
            if not duration:
                duration = "5"

            await self._update_progress(processing_msg, "🎬 Pass 1 encoding...")
            
            # Pass 1
            ffmpeg_pass1 = [
                'ffmpeg', '-ss', start_time, '-i', video_path, '-t', duration,
                '-vf', "scale=640:360:flags=lanczos",
                '-c:v', 'libx264', '-preset', 'medium', '-pix_fmt', 'yuv420p',
                '-b:v', '750k', '-maxrate', '900k', '-bufsize', '1800k',
                '-pass', '1', '-bf', '3', '-g', '30', '-keyint_min', '1',
                '-an', '-f', 'mp4', '-y', '/dev/null'  # Use /dev/null for output
            ]
            
            process1 = await asyncio.create_subprocess_exec(
                *ffmpeg_pass1,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await process1.wait()

            await self._update_progress(processing_msg, "🎞️ Final encoding (Pass 2)...")
            
            # Pass 2
            ffmpeg_pass2 = [
                'ffmpeg', '-ss', start_time, '-i', video_path, '-t', duration,
                '-vf', "scale=640:360:flags=lanczos",
                '-c:v', 'libx264', '-preset', 'medium', '-pix_fmt', 'yuv420p',
                '-b:v', '750k', '-maxrate', '900k', '-bufsize', '1800k',
                '-pass', '2', '-bf', '3', '-g', '30', '-keyint_min', '1',
                '-an', '-movflags', '+faststart', '-tune', 'animation',
                '-y', output_path
            ]
            
            process2 = await asyncio.create_subprocess_exec(
                *ffmpeg_pass2,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await process2.wait()

            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                await processing_msg.edit_text("❌ Failed to create animation GIF!")
                return

            await self._update_progress(processing_msg, "📤 Uploading GIF...")
            
            await self.bot.send_video(
                chat_id=message.chat.id,
                video=output_path,
                supports_streaming=True,
                caption=f"🎞️ **Telegram GIF Created!**\n⏱ Duration: `{duration}s`\n📍 Start: `{start_time}s`"
            )

            await processing_msg.delete()

        except Exception as e:
            logger.error(f"TG GIF Error: {e}")
            await message.reply_text(f"❌ Error: `{str(e)[:200]}`")

        finally:
            # Cleanup files
            await self._cleanup_files(video_path, output_path)
            if passlog and os.path.exists(passlog):
                try:
                    os.remove(passlog)
                except:
                    pass

    async def create_gif(self, message: Message, user_id: int, start_time: str = None, duration: str = None):
        """Convert part of video into high-quality GIF (palette mode, 2-pass equivalent)"""
        video_path = None
        output_path = None
        palette_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("❌ **Please reply to a video file.**")

            if not self._is_video_file(message):
                return await message.reply_text("❌ **That is not a video file!**")

            # Parse time input
            def parse_t(t):
                if ":" in t:
                    p = t.split(":")
                    return sum(int(p[-(i+1)]) * (60**i) for i in range(len(p)))
                return int(t)

            start_seconds = parse_t(start_time) if start_time else 0
            duration_seconds = parse_t(duration) if duration else 5

            if duration_seconds <= 0 or duration_seconds > 10:
                duration_seconds = 7

            status = await message.reply_text("🎞 **Processing GIF...**")

            # Download video
            video_path = await self._download_media(message, user_id, "gif")
            if not video_path:
                return await status.edit_text("❌ **Failed to download video!**")

            await self._update_progress(status, "🎨 Generating color palette...")

            random_id = self._generate_random_id()
            output_filename = f"gif_{random_id}.gif"
            output_path = f"downloads/{output_filename}"
            palette_path = f"downloads/palette_{random_id}.png"

            # ---- PASS 1: Generate palette ----
            palette_cmd = [
                "ffmpeg", "-hide_banner", "-loglevel", "error",
                "-ss", str(start_seconds), "-t", str(duration_seconds),
                "-i", video_path,
                "-vf", "fps=24,scale=720:-1:flags=lanczos,palettegen=max_colors=256:stats_mode=diff",
                "-y", palette_path
            ]

            process = await asyncio.create_subprocess_exec(*palette_cmd)
            await process.wait()

            if not os.path.exists(palette_path):
                return await status.edit_text("❌ **Failed to build GIF palette!**")

            await self._update_progress(status, "🎬 Rendering final GIF...")

            # ---- PASS 2: Build GIF using palette ----
            ffmpeg_cmd = [
                "ffmpeg", "-hide_banner", "-loglevel", "error",
                "-ss", str(start_seconds), "-t", str(duration_seconds),
                "-i", video_path, "-i", palette_path,
                "-filter_complex",
                "fps=24,scale=720:-1:flags=lanczos[x];[x][1:v]paletteuse=dither=bayer:bayer_scale=5",
                "-y", output_path
            ]

            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()

            if not os.path.exists(output_path):
                return await status.edit_text("❌ **GIF build failed!**")

            await self._update_progress(status, "📤 Uploading GIF...")

            await self.bot.send_animation(
                chat_id=message.chat.id,
                animation=output_path,
                caption=f"**🎞 GIF Created**\n⏱ Duration: `{duration_seconds}s`\n📍 Start: `{start_seconds}s`",
                file_name=output_filename
            )

            await status.delete()

        except Exception as e:
            logger.error(f"GIF Error: {e}")
            await message.reply_text(f"❌ **Error:** `{str(e)[:200]}`")

        finally:
            # Cleanup files
            await self._cleanup_files(video_path, output_path)
            if palette_path and os.path.exists(palette_path):
                os.remove(palette_path)

    async def convert_audio(self, message: Message, user_id: int, target_format: str):
        """Convert audio to desired format"""
        audio_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an audio file**")
            
            if not self._is_audio_file(message):
                return await message.reply_text("**❌ Please reply to an audio file!**")
            
            valid_formats = ['mp3', 'flac', 'opus', 'wav', 'm4a', 'aac', 'ogg']
            if target_format not in valid_formats:
                return await message.reply_text(
                    f"**❌ Invalid format! Supported formats:** {', '.join(valid_formats)}"
                )
            
            processing_msg = await message.reply_text(f"**🎵 Converting to {target_format.upper()}...**")
            
            # Download audio
            audio_path = await self._download_media(message, user_id, "audioconvert")
            
            if not audio_path:
                await processing_msg.edit_text("**❌ Failed to download audio!**")
                return
            
            # Convert audio format
            await self._update_progress(processing_msg, f"🔄 Converting to {target_format.upper()}...")
            
            random_id = self._generate_random_id()
            output_filename = f"converted_{random_id}.{target_format}"
            output_path = f"downloads/{output_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', audio_path,
                '-c:a', 'copy',  # Copy audio codec when possible
                '-y', output_path
            ]
            
            # Special handling for different formats
            if target_format == 'mp3':
                ffmpeg_cmd = ['ffmpeg', '-i', audio_path, '-c:a', 'libmp3lame', '-q:a', '2', '-y', output_path]
            elif target_format == 'flac':
                ffmpeg_cmd = ['ffmpeg', '-i', audio_path, '-c:a', 'flac', '-compression_level', '8', '-y', output_path]
            elif target_format == 'opus':
                ffmpeg_cmd = ['ffmpeg', '-i', audio_path, '-c:a', 'libopus', '-b:a', '128k', '-y', output_path]
            elif target_format == 'wav':
                ffmpeg_cmd = ['ffmpeg', '-i', audio_path, '-c:a', 'pcm_s16le', '-y', output_path]
            elif target_format == 'm4a':
                ffmpeg_cmd = ['ffmpeg', '-i', audio_path, '-c:a', 'aac', '-b:a', '192k', '-y', output_path]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                await processing_msg.edit_text("**❌ Audio conversion failed!**")
                return
            
            # Send converted audio
            await self._update_progress(processing_msg, "📤 Sending converted audio...")
            try:
                await self.bot.send_audio(
                    chat_id=message.chat.id,
                    audio=output_path,
                    caption=f"**🎵 Converted to {target_format.upper()} format**",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Audio conversion error: {e}")
            await message.reply_text(f"**❌ Error converting audio:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(audio_path, output_path)
    
    async def change_bitrate(self, message: Message, user_id: int, bitrate: str):
        """Change audio bitrate quality"""
        audio_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an audio file**")
            
            if not self._is_audio_file(message):
                return await message.reply_text("**❌ Please reply to an audio file!**")
            
            # Validate bitrate
            if not bitrate.endswith('k'):
                bitrate = f"{bitrate}k"
            
            valid_bitrates = ['64k', '96k', '128k', '192k', '256k', '320k']
            if bitrate not in valid_bitrates:
                return await message.reply_text(
                    f"**❌ Invalid bitrate! Valid bitrates:** {', '.join(valid_bitrates)}"
                )
            
            processing_msg = await message.reply_text(f"**🎵 Changing bitrate to {bitrate}...**")
            
            # Download audio
            audio_path = await self._download_media(message, user_id, "bitrate")
            
            if not audio_path:
                await processing_msg.edit_text("**❌ Failed to download audio!**")
                return
            
            # Change bitrate
            await self._update_progress(processing_msg, f"🔄 Changing bitrate to {bitrate}...")
            
            random_id = self._generate_random_id()
            output_filename = f"bitrate_{bitrate}_{random_id}.mp3"
            output_path = f"downloads/{output_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', audio_path,
                '-c:a', 'libmp3lame', '-b:a', bitrate,
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                await processing_msg.edit_text("**❌ Failed to change bitrate!**")
                return
            
            # Send processed audio
            await self._update_progress(processing_msg, "📤 Sending audio...")
            try:
                await self.bot.send_audio(
                    chat_id=message.chat.id,
                    audio=output_path,
                    caption=f"**🎵 Audio with {bitrate} bitrate**",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Bitrate change error: {e}")
            await message.reply_text(f"**❌ Error changing bitrate:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(audio_path, output_path)
    
    async def normalize_audio(self, message: Message, user_id: int):
        """Normalize audio volume"""
        audio_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an audio file**")
            
            if not self._is_audio_file(message):
                return await message.reply_text("**❌ Please reply to an audio file!**")
            
            processing_msg = await message.reply_text("**🎵 Normalizing audio...**")
            
            # Download audio
            audio_path = await self._download_media(message, user_id, "normalize")
            
            if not audio_path:
                await processing_msg.edit_text("**❌ Failed to download audio!**")
                return
            
            # Normalize audio
            await self._update_progress(processing_msg, "🔊 Normalizing audio volume...")
            
            random_id = self._generate_random_id()
            output_filename = f"normalized_{random_id}.mp3"
            output_path = f"downloads/{output_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', audio_path,
                '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11',
                '-c:a', 'libmp3lame', '-q:a', '2',
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                await processing_msg.edit_text("**❌ Failed to normalize audio!**")
                return
            
            # Send normalized audio
            await self._update_progress(processing_msg, "📤 Sending normalized audio...")
            try:
                await self.bot.send_audio(
                    chat_id=message.chat.id,
                    audio=output_path,
                    caption="**🎵 Normalized Audio**\nVolume adjusted for consistent loudness",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Audio normalization error: {e}")
            await message.reply_text(f"**❌ Error normalizing audio:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(audio_path, output_path)
    
    async def bassboost_audio(self, message: Message, user_id: int):
        """Boost bass frequencies"""
        audio_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an audio file**")
            
            if not self._is_audio_file(message):
                return await message.reply_text("**❌ Please reply to an audio file!**")
            
            processing_msg = await message.reply_text("**🎵 Boosting bass...**")
            
            # Download audio
            audio_path = await self._download_media(message, user_id, "bassboost")
            
            if not audio_path:
                await processing_msg.edit_text("**❌ Failed to download audio!**")
                return
            
            # Boost bass
            await self._update_progress(processing_msg, "🔊 Boosting bass frequencies...")
            
            random_id = self._generate_random_id()
            output_filename = f"bassboosted_{random_id}.mp3"
            output_path = f"downloads/{output_filename}"
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', audio_path,
                '-af', 'bass=g=15',
                '-c:a', 'libmp3lame', '-q:a', '2',
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                await processing_msg.edit_text("**❌ Failed to boost bass!**")
                return
            
            # Send bass boosted audio
            await self._update_progress(processing_msg, "📤 Sending bass boosted audio...")
            try:
                await self.bot.send_audio(
                    chat_id=message.chat.id,
                    audio=output_path,
                    caption="**🎵 Bass Boosted Audio**\nEnhanced bass frequencies for better sound",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Bass boost error: {e}")
            await message.reply_text(f"**❌ Error boosting bass:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(audio_path, output_path)
    
    async def change_volume(self, message: Message, user_id: int, volume_percent: str):
        """Change audio volume"""
        audio_path = None
        output_path = None
        try:
            if not message.reply_to_message:
                return await message.reply_text("**❌ Please reply to an audio file**")
            
            if not self._is_audio_file(message):
                return await message.reply_text("**❌ Please reply to an audio file!**")
            
            try:
                volume = float(volume_percent.rstrip('%'))
                if volume <= 0:
                    return await message.reply_text("**❌ Volume must be greater than 0%**")
                if volume > 500:
                    return await message.reply_text("**❌ Volume cannot exceed 500%**")
            except ValueError:
                return await message.reply_text("**❌ Invalid volume! Use format: `/vol 150` or `/vol 50%`**")
            
            processing_msg = await message.reply_text(f"**🎵 Changing volume to {volume}%...**")
            
            # Download audio
            audio_path = await self._download_media(message, user_id, "volume")
            
            if not audio_path:
                await processing_msg.edit_text("**❌ Failed to download audio!**")
                return
            
            # Change volume
            await self._update_progress(processing_msg, f"🔊 Changing volume to {volume}%...")
            
            random_id = self._generate_random_id()
            operation = "louder" if volume > 100 else "quieter"
            output_filename = f"{operation}_{random_id}.mp3"
            output_path = f"downloads/{output_filename}"
            
            # Convert percentage to multiplier
            multiplier = volume / 100.0
            
            ffmpeg_cmd = [
                'ffmpeg', '-i', audio_path,
                '-af', f'volume={multiplier}',
                '-c:a', 'libmp3lame', '-q:a', '2',
                '-y', output_path
            ]
            
            process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
            await process.wait()
            
            if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
                await processing_msg.edit_text("**❌ Failed to change volume!**")
                return
            
            # Send volume changed audio
            await self._update_progress(processing_msg, "📤 Sending audio...")
            try:
                await self.bot.send_audio(
                    chat_id=message.chat.id,
                    audio=output_path,
                    caption=f"**🎵 Volume Adjusted**\nVolume changed to {volume}%",
                    file_name=output_filename
                )
            finally:
                await processing_msg.delete()
                
        except Exception as e:
            logger.error(f"Volume change error: {e}")
            await message.reply_text(f"**❌ Error changing volume:** `{str(e)[:200]}`")
        finally:
            # GUARANTEED CLEANUP
            await self._cleanup_files(audio_path, output_path)

# Callback query handler
@Client.on_callback_query(filters.regex("^vtool:"))
async def video_tools_callback(client, callback_query):
    """Handle video tools callback queries"""
    data = callback_query.data
    user_id = callback_query.from_user.id
    message = callback_query.message
    
    # Initialize VideoTools
    vtools = VideoTools(client)
    
    try:
        await callback_query.answer()
        
        if data == "vtool:subtitle":
            await vtools.extract_subtitle(message, user_id)
            
        elif data == "vtool:audio":
            await vtools.extract_audio(message, user_id)
            
        elif data == "vtool:convert":
            await message.reply_text(
                "**🎬 Convert Video Format**\n\n"
                "**Usage:** `/convert <format>`\n"
                "**Formats:** mp4, mkv, avi, mov, webm\n"
                "**Example:** `/convert mp4`\n\n"
                "Reply to a video file with this command."
            )
            
        elif data == "vtool:trim":
            await message.reply_text(
                "**✂️ Trim/Cut Video**\n\n"
                "**Usage:** `/trim <start_time> <end_time>`\n"
                "**Time Formats:**\n"
                "- Seconds: `10`\n"
                "- MM:SS: `1:30`\n"
                "- HH:MM:SS: `0:01:30`\n"
                "**Example:** `/trim 0:30 1:30`\n\n"
                "Reply to a video file with this command."
            )
            
        elif data == "vtool:remove_audio":
            await vtools.remove_audio_or_sub(message, user_id, "audio")
            
        elif data == "vtool:remove_subs":
            await vtools.remove_audio_or_sub(message, user_id, "subtitle")
            
        elif data == "vtool:info":
            await vtools.media_info(message, user_id)
            
        elif data == "vtool:addaudio":
            await vtools.add_audio(message, user_id)
            
        elif data == "vtool:reverse":
            await vtools.reverse_video(message, user_id)
            
        elif data == "vtool:gif":
            await message.reply_text(
                "**🎞️ Create GIF from Video**\n\n"
                "**Usage:** `/gif` or `/gif <start_time> <duration>`\n"
                "**Example:** `/gif 0:30 5` (start at 30s, 5s duration)\n\n"
                "Reply to a video file with this command."
            )
            
    except Exception as e:
        logger.error(f"Callback error: {e}")
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

# Video tools command handler
@Client.on_message(filters.command(["videotools", "vtools"]) & filters.private)
async def video_tools_menu(client, message: Message):
    """Video tools main menu"""
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📄 Extract Subtitle", callback_data="vtool:subtitle"),
            InlineKeyboardButton("🎵 Extract Audio", callback_data="vtool:audio")
        ],
        [
            InlineKeyboardButton("🎬 Convert Format", callback_data="vtool:convert"),
            InlineKeyboardButton("✂️ Trim/Cut", callback_data="vtool:trim")
        ],
        [
            InlineKeyboardButton("🚫 Remove Audio", callback_data="vtool:remove_audio"),
            InlineKeyboardButton("🚫 Remove Subs", callback_data="vtool:remove_subs")
        ],
        [
            InlineKeyboardButton("🎵 Add Audio", callback_data="vtool:addaudio"),
            InlineKeyboardButton("↪️ Reverse", callback_data="vtool:reverse")
        ],
        [
            InlineKeyboardButton("🎞️ Create GIF", callback_data="vtool:gif"),
            InlineKeyboardButton("📌 Media Info", callback_data="vtool:info")
        ]
    ])
    
    await message.reply_text(
        "**🧰 Video & Audio Tools**\n\n"
        "**Available Tools:**\n"
        "• **Extract Subtitle** - Extract subtitle streams\n"
        "• **Extract Audio** - Extract audio from video\n" 
        "• **Convert Format** - Convert video formats\n"
        "• **Trim/Cut** - Cut specific parts of video\n"
        "• **Remove Audio** - Create video without audio\n"
        "• **Remove Subs** - Create video without subtitles\n"
        "• **Add Audio** - Merge audio with video\n"
        "• **Reverse** - Create reversed video\n"
        "• **Create GIF** - Convert video part to GIF\n"
        "• **Media Info** - Get detailed media information\n\n"
        "**Usage:** Reply to a file and choose a tool",
        reply_markup=keyboard
    )

# ============= COMMAND HANDLERS =============

@Client.on_message(filters.command(["extractsub", "extsub"]) & filters.private)
async def extract_subtitle_cmd(client, message: Message):
    """Extract subtitle command"""
    vtools = VideoTools(client)
    await vtools.extract_subtitle(message, message.from_user.id)

@Client.on_message(filters.command(["extractaudio", "extaudio"]) & filters.private)
async def extract_audio_cmd(client, message: Message):
    """Extract audio command"""
    vtools = VideoTools(client)
    await vtools.extract_audio(message, message.from_user.id)

@Client.on_message(filters.command(["convert"]) & filters.private)
async def convert_format_cmd(client, message: Message):
    """Convert video format command"""
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "**Usage:** `/convert <format>`\n"
                "**Formats:** mp4, mkv, avi, mov, webm\n"
                "**Example:** `/convert mp4`"
            )
            return
        
        target_format = message.command[1].lower()
        vtools = VideoTools(client)
        await vtools.convert_format(message, message.from_user.id, target_format)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["trim", "cut"]) & filters.private)
async def trim_video_cmd(client, message: Message):
    """Trim video command"""
    try:
        if len(message.command) < 3:
            await message.reply_text(
                "**Usage:** `/trim <start_time> <end_time>`\n"
                "**Time Formats:**\n"
                "- Seconds: `10`\n"
                "- MM:SS: `1:30`\n"
                "- HH:MM:SS: `0:01:30`\n"
                "**Example:** `/trim 0:30 1:30`"
            )
            return
        
        start_time = message.command[1]
        end_time = message.command[2]
        vtools = VideoTools(client)
        await vtools.trim_video(message, message.from_user.id, start_time, end_time)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["removeaudio", "mute"]) & filters.private)
async def remove_audio_cmd(client, message: Message):
    """Remove audio command"""
    vtools = VideoTools(client)
    await vtools.remove_audio_or_sub(message, message.from_user.id, "audio")

@Client.on_message(filters.command(["removesubs", "nosubs"]) & filters.private)
async def remove_subs_cmd(client, message: Message):
    """Remove subtitles command"""
    vtools = VideoTools(client)
    await vtools.remove_audio_or_sub(message, message.from_user.id, "subtitle")

# ============= NEW COMMAND HANDLERS =============
@Client.on_message(filters.command(["addaudio2", "mergeaudio"]) & filters.private)
async def add_audio_cmd_v2(client, message: Message):
    """Add audio to video - UPDATED VERSION"""
    try:
        if not message.reply_to_message:
            await message.reply_text(
                "**Usage:** Reply to a video file and use:\n"
                "`/addaudio2 <audio_message_id>`\n\n"
                "**How to get audio message ID:**\n"
                "1. Send the audio file first\n"
                "2. Reply to it with `/id` to get its ID\n"
                "3. Reply to video with `/addaudio2 ID`"
            )
            return
        
        if len(message.command) < 2:
            await message.reply_text(
                "**Missing audio message ID!**\n"
                "**Usage:** `/addaudio2 <audio_message_id>`"
            )
            return
        
        audio_message_id = int(message.command[1])
        vtools = VideoTools(client)
        
        # Get original video duration
        original_duration = None
        if message.reply_to_message.video:
            original_duration = message.reply_to_message.video.duration
        
        # Get the audio message
        try:
            audio_message = await client.get_messages(
                chat_id=message.chat.id,
                message_ids=audio_message_id
            )
            
            if not audio_message:
                await message.reply_text("**❌ Audio message not found!**")
                return
            
            if not vtools._is_audio_file(audio_message):
                await message.reply_text("**❌ That message doesn't contain an audio file!**")
                return
            
            # Process merging
            await vtools.merge_audio_video(message, audio_message, message.from_user.id)
            
        except ValueError:
            await message.reply_text("**❌ Invalid message ID! Must be a number.**")
        except Exception as e:
            logger.error(f"Add audio v2 error: {e}", exc_info=True)
            await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
            
    except Exception as e:
        logger.error(f"Add audio v2 outer error: {e}", exc_info=True)
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
@Client.on_message(filters.command(["reverse"]) & filters.private)
async def reverse_video_cmd(client, message: Message):
    """Reverse video command"""
    vtools = VideoTools(client)
    await vtools.reverse_video(message, message.from_user.id)
@Client.on_message(filters.command(["rotatev"]) & filters.private)
async def rotate_video_cmd(client, message: Message):
    """Rotate video command"""
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "**Usage:** `/rotate <angle>`\n"
                "**Angles:** 90, 180, 270\n"
                "**Example:** `/rotate 90`"
            )
            return
        
        angle = message.command[1]
        vtools = VideoTools(client)
        await vtools.rotate_video(message, message.from_user.id, angle)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["split"]) & filters.private)
async def split_video_cmd(client, message: Message):
    """Split video command"""
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "**Usage:** `/split <number_of_parts>`\n"
                "**Range:** 2 to 20 parts\n"
                "**Example:** `/split 3` (splits into 3 equal parts)\n"
                "**Example:** `/split 5` (splits into 5 equal parts)"
            )
            return
        
        parts = message.command[1]
        vtools = VideoTools(client)
        await vtools.split_video(message, message.from_user.id, parts)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
@Client.on_message(filters.command(["gif"]) & filters.private)
async def create_gif_cmd(client, message: Message):
    """Create GIF command"""
    try:
        vtools = VideoTools(client)
        
        if len(message.command) == 1:
            # No parameters, use defaults
            await vtools.create_gif(message, message.from_user.id)
        elif len(message.command) == 3:
            # With start time and duration
            start_time = message.command[1]
            duration = message.command[2]
            await vtools.create_gif(message, message.from_user.id, start_time, duration)
        else:
            await message.reply_text(
                "**Usage:** `/gif` or `/gif <start_time> <duration>`\n"
                "**Example:** `/gif 0:30 5` (start at 30s, 5s duration)"
            )
            
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
@Client.on_message(filters.command(["tg_gif", "hq_gif"]) & filters.private)
async def tg_gif_cmd(client: Client, message: Message):
    """Create Telegram optimized animated mp4 GIF (H.264)"""
    try:
        vtools = VideoTools(client)

        cmd = message.command

        start_time = None
        duration = None

        if len(cmd) == 1:
            # No args → default
            start_time = "0"
            duration = "5"

        elif len(cmd) == 2:
            # Only duration
            start_time = "0"
            duration = cmd[1]

        elif len(cmd) == 3:
            # start + duration
            start_time = cmd[1]
            duration = cmd[2]

        else:
            return await message.reply_text(
                "**❌ Incorrect usage!**\n\n"
                "**Use:**\n"
                "`/tg_gif`\n"
                "`/tg_gif <duration>`\n"
                "`/tg_gif <start_time> <duration>`\n\n"
                "**Example:**\n`/tg_gif 00:20 8`"
            )

        # Validate duration
        try:
            duration_s = int(duration) if duration.isdigit() else sum(
                int(x) * 60 ** i for i, x in enumerate(reversed(duration.split(":")))
            )
        except:
            return await message.reply_text("❌ Invalid duration format!")

        if duration_s > 30:
            duration_s = 30

        await vtools.create_tg_gif(message, message.from_user.id, start_time, str(duration_s))

    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["convertaudio", "audioformat"]) & filters.private)
async def convert_audio_cmd(client, message: Message):
    """Convert audio format command"""
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "**Usage:** `/convertaudio <format>`\n"
                "**Formats:** mp3, flac, opus, wav, m4a\n"
                "**Example:** `/convertaudio mp3`"
            )
            return
        
        target_format = message.command[1].lower()
        vtools = VideoTools(client)
        await vtools.convert_audio(message, message.from_user.id, target_format)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["bitrate"]) & filters.private)
async def change_bitrate_cmd(client, message: Message):
    """Change bitrate command"""
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "**Usage:** `/bitrate <bitrate>`\n"
                "**Bitrates:** 64k, 96k, 128k, 192k, 256k, 320k\n"
                "**Example:** `/bitrate 320k`"
            )
            return
        
        bitrate = message.command[1].lower()
        vtools = VideoTools(client)
        await vtools.change_bitrate(message, message.from_user.id, bitrate)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")

@Client.on_message(filters.command(["normalize"]) & filters.private)
async def normalize_audio_cmd(client, message: Message):
    """Normalize audio command"""
    vtools = VideoTools(client)
    await vtools.normalize_audio(message, message.from_user.id)

@Client.on_message(filters.command(["bassboost"]) & filters.private)
async def bassboost_audio_cmd(client, message: Message):
    """Bass boost command"""
    vtools = VideoTools(client)
    await vtools.bassboost_audio(message, message.from_user.id)

@Client.on_message(filters.command(["vol", "volume"]) & filters.private)
async def change_volume_cmd(client, message: Message):
    """Change volume command"""
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "**Usage:** `/vol <percentage>`\n"
                "**Example:** `/vol 150` (increase to 150%)\n"
                "**Example:** `/vol 50` (decrease to 50%)"
            )
            return
        
        volume = message.command[1]
        vtools = VideoTools(client)
        await vtools.change_volume(message, message.from_user.id, volume)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
@Client.on_message(filters.command(["audiostream", "changeaudio"]) & filters.private)
async def change_audio_stream_cmd(client, message: Message):
    """Change audio stream command"""
    try:
        if len(message.command) < 2:
            await message.reply_text(
                "**Usage:** `/audiostream <stream_number>`\n"
                "**Example:** `/audiostream 2`\n\n"
                "To see available streams:\n"
                "`/audiostream list`\n\n"
                "Reply to a video with multiple audio tracks."
            )
            return
        
        stream_index = message.command[1].lower()
        vtools = VideoTools(client)
        await vtools.change_audio_stream(message, message.from_user.id, stream_index)
        
    except Exception as e:
        await message.reply_text(f"**❌ Error:** `{str(e)[:200]}`")
@Client.on_message(filters.command(["id", "msgid"]) & filters.private)
async def get_message_id(client, message: Message):
    """Get message ID"""
    if message.reply_to_message:
        msg_id = message.reply_to_message.id
        await message.reply_text(
            f"**📌 Message ID:** `{msg_id}`\n\n"
            f"**To use with addaudio:**\n"
            f"`/addaudio2 {msg_id}`"
        )
    else:
        await message.reply_text(
            "**Reply to any message to get its ID.**\n\n"
            "**Usage for audio merging:**\n"
            "1. Send audio file\n"
            "2. Reply to it with `/id`\n"
            "3. Note the ID\n"
            "4. Reply to video with `/addaudio2 ID`"
        )
# ============= HELP COMMAND =============
@Client.on_message(filters.command(["videohelp", "vtoolshelp"]) & filters.private)
async def video_help_cmd(client, message: Message):
    """Show all video tools commands"""
    help_text = """
**🎬 VIDEO TOOLS - ALL COMMANDS**

**📋 Basic Tools:**
• `/extractsub` - Extract subtitles from video
• `/extractaudio` - Extract audio from video
• `/trim <start> <end>` - Trim/cut video
• `/convert <format>` - Convert video format (mp4/mkv/avi/mov/webm)
• `/removeaudio` - Remove audio from video
• `/removesubs` - Remove subtitles from video
• `/mediainfo` - Get detailed media information

**🎵 Audio Manipulation:**
• `/convertaudio <format>` - Convert audio (mp3/flac/opus/wav/m4a)
• `/bitrate <rate>` - Change audio bitrate (64k-320k)
• `/normalize` - Normalize audio volume
• `/bassboost` - Boost bass frequencies
• `/vol <percent>` - Change audio volume (50-500%)

**🎵 Audio Stream Control:**
• `/audiostream list` - Show available audio streams
• `/audiostream <number>` - Change default audio stream
**🔧 Advanced Audio:**
• `/addaudio2 <message_id>` - Merge audio using message ID
• `/id` - Get message ID for audio files
**📌 Audio Merging Guide:**
1. Send audio file first
2. Reply to it with `/id` to get ID
3. Reply to video with `/addaudio2 <id>`

**🎞️ Special Effects:**
• `/reverse` - Create reversed video
• `/rotatev <angle>` - Rotate video (90/180/270 degrees)
• `/split <parts>` - Split video into equal parts (2-20)
• `/gif` - Convert video part to GIF
• `/hq_gif` - Convert video part to HIGH GIF
• `/gif <start> <duration>` - Create GIF with custom timing

**📌 Usage:**
1. Reply to a video/audio file
2. Use any command
3. Wait for processing
4. Receive processed file

**📁 Supported Files:**
• Videos: MP4, MKV, AVI, MOV, WEBM, 3GP
• Audio: MP3, M4A, FLAC, OPUS, WAV, AAC
• Documents with video/audio mime types
"""
    await message.reply_text(help_text)
