import logging
import asyncio
import os
import re
from os import path as ospath, getcwd

from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.enums import ParseMode

from aiohttp import ClientSession
from aiofiles import open as aiopen
from aiofiles.os import remove as aioremove, path as aiopath, mkdir

from humanize import naturalsize
from telegraph import Telegraph

# -------------------------------------
# GLOBAL SETUP
# -------------------------------------
logger = logging.getLogger(__name__)

telegraph = Telegraph()
telegraph.create_account(short_name="MediaInfoBot")

section_dict = {
    "General": "🗒",
    "Video": "🎞",
    "Audio": "🔊",
    "Text": "🔠",
    "Menu": "🗃",
}


# -------------------------------------
# FORMAT OUTPUT
# -------------------------------------
def parseinfo(raw: str, file_name: str = None, file_size: str = None, username: str = None):
    """
    Formats mediainfo text output into clean Telegram-friendly readable text.
    """

    section_icons = {
        "General": "🗒",
        "Video": "🎞",
        "Audio": "🔊",
        "Text": "🔠",
        "Menu": "🗃",
        "Other": "📁",
    }

    lines = raw.split("\n")
    result = []

    # ---- Header Block ----
    result.append(f"📌 {file_name or 'Unknown File'}")
    if file_size:
        result.append(f"📦 File Size: {file_size}")
    if username:
        result.append(f"@{username}")
    result.append("")  # blank line

    current_section = None
    block = []

    def flush():
        """Flush a collected block into result formatted with indent."""
        nonlocal block, current_section
        if block:
            result.append("\n".join(block))
            block = []

    for line in lines:
        stripped = line.strip()

        if not stripped:
            continue

        # Detect section headers
        section_name = next((name for name in section_icons if stripped.startswith(name)), None)

        if section_name:
            flush()  # end previous section

            current_section = section_name
            icon = section_icons.get(section_name, "📁")

            # Number dynamic e.g., Video #1, Audio #2
            if "#" in stripped:
                result.append(f"{icon} {stripped}")
            else:
                result.append(f"{icon} {section_name}")

            result.append("")  # gap
            continue

        # Filter unnecessary long entries
        if stripped.startswith("Encoding settings") or stripped.startswith("Unique ID"):
            continue

        # Normal formatted line
        block.append(stripped)

    flush()  # Add final block

    return "\n".join(result)
async def cmd_exec(cmd):
    """Run shell command."""
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    return stdout.decode(), stderr.decode(), process.returncode


# -------------------------------------
# MAIN FUNCTION
# -------------------------------------
async def gen_mediainfo(client: Client, message: Message, link=None, media=None):
    temp = await message.reply("<i>🛠 Generating MediaInfo...</i>")

    try:
        path = "mediainfo_temp/"
        if not await aiopath.isdir(path):
            await mkdir(path)

        # ---------------- File Download ----------------
        if link:
            filename = link.split("/")[-1]
            file_path = ospath.join(path, filename)

            async with ClientSession() as session:
                async with session.get(link) as r:
                    if r.status != 200:
                        return await temp.edit("❌ Failed to download URL file.")

                    async with aiopen(file_path, "wb") as f:
                        await f.write(await r.read())

        elif media:
            file_path = ospath.join(path, media.file_name)
            await message.reply_to_message.download(file_path)

        else:
            return await temp.edit("❌ No media or link detected.")

        # ---------------- Mediainfo Execution ----------------
        stdout, stderr, code = await cmd_exec(["mediainfo", file_path])

        if code != 0:
            return await temp.edit(f"❌ mediainfo error:\n\n<code>{stderr}</code>")

        size_txt = naturalsize(os.path.getsize(file_path), binary=True)

        stdout = re.sub(
            r"File size\s*:\s*.+",
            f"File size                                : {size_txt}",
            stdout,
        )

        # ---------------- Telegraph Output ----------------
        html = (
            f"<h4>📌 {ospath.basename(file_path)}</h4>"
            f"<b>📦 Size:</b> {size_txt}<br><br>"
            f"{parseinfo(stdout)}"
        )

        page = telegraph.create_page(
            f"MediaInfo - {ospath.basename(file_path)}",
            html_content=html,
        )

        await temp.edit(
            f"✅ <b>MediaInfo Extracted Successfully</b>\n\n"
            f"📄 <b>File:</b> {ospath.basename(file_path)}\n"
            f"📦 <b>Size:</b> {size_txt}\n\n"
            f"🔗 <a href='https://graph.org/{page['path']}'>View Full Info</a>",
            parse_mode=ParseMode.HTML,
        )

    except Exception as e:
        logger.error(e)
        await temp.edit(f"❌ Error: {e}")

    finally:
        if 'file_path' in locals() and await aiopath.exists(file_path):
            await aioremove(file_path)


# -------------------------------------
# COMMAND HANDLER
# -------------------------------------
@Client.on_message(filters.command(["mediainfo", "info"]) & filters.private)
async def mediainfo_handler(client: Client, message: Message):
    reply = message.reply_to_message

    if not reply:
        return await message.reply(
            "📊 <b>MediaInfo Usage</b>\n\n"
            "Reply to any file and send:\n\n"
            "<code>/mediainfo</code>",
            parse_mode=ParseMode.HTML,
        )

    media = (
        reply.document
        or reply.video
        or reply.audio
        or reply.animation
        or reply.voice
        or reply.video_note
    )

    if not media:
        return await message.reply("❌ No supported media found.")

    await gen_mediainfo(client, message, media=media)

