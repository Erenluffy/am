# Remove duplicate imports
import os, re, time, shutil, asyncio, logging, unicodedata
import uuid
# Add this with other imports at the top
from urllib.parse import urlparse
from datetime import datetime, timedelta  # Only this datetime import
from PIL import Image, ImageDraw, ImageFont
from pyrogram import Client, filters
from PyPDF2 import PdfReader, PdfWriter
from PIL import Image
import asyncio
import time
import re
import subprocess
import json
import shlex
from pyrogram.errors import FloodWait
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, InputMediaDocument, Message, CallbackQuery
from pyrogram.types import InputMediaDocument, Message
from hachoir.metadata import extractMetadata
from hachoir.parser import createParser
from pyrogram.enums import ParseMode, ChatAction
from plugins.antinsfw import check_anti_nsfw
from helper.utils import progress_for_pyrogram, humanbytes, convert
from helper.database import DARKXSIDE78
from config import Config
import random, string, aiohttp, pytz
from asyncio import Semaphore
import subprocess, json
import aiofiles, aiofiles.os
from typing import Dict, List, Optional, Set, Tuple, Deque
from collections import deque
from functools import wraps
from PyPDF2 import PdfReader, PdfWriter
from PyPDF2.generic import RectangleObject
from pdf2image import convert_from_path
import tempfile
from playwright.async_api import async_playwright
import psutil
from platform import python_version, system, release
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram import Client, filters
from pyrogram.errors import FloodWait, InputUserDeactivated, UserIsBlocked, PeerIdInvalid
# Fixed screenshot generation function
import math
DOCUMENT_TYPES = {
    '.pdf': 'PDF Document',
    '.epub': 'E-Book', 
    '.mobi': 'E-Book',
    '.cbz': 'Comic Archive', 
    '.cbr': 'Comic Archive',
    '.doc': 'Word Document',
    '.docx': 'Word Document',
    '.txt': 'Text File',
    '.rtf': 'Rich Text',
    '.odt': 'OpenDocument Text',
    '.xls': 'Excel Spreadsheet',
    '.xlsx': 'Excel Spreadsheet',
    '.ppt': 'PowerPoint',
    '.pptx': 'PowerPoint'
}
# Add this function definition AFTER DOCUMENT_TYPES but BEFORE it's used
def get_file_type_description(filename):
    """Get human-readable file type description"""
    if not filename:
        return "Unknown File"
    
    ext = os.path.splitext(filename)[1].lower()
    return DOCUMENT_TYPES.get(ext, "Document")

# Remove the problematic line 1525 that's causing the error
# DELETE this line: file_type = get_file_type_description(file_info['file_name'])
# Fix: Use consistent database class name throughout
db = DARKXSIDE78

def check_ban_status(func):
    @wraps(func)
    async def wrapper(client, message, *args, **kwargs):
        user_id = message.from_user.id
        is_banned, ban_reason = await db.is_user_banned(user_id)
        if is_banned:
            await message.reply_text(
                f"**Yᴏᴜ ᴀʀᴇ ʙᴀɴɴᴇᴅ ғʀᴏᴍ ᴜsɪɴɢ ᴛʜɪs ʙᴏᴛ.**\n\n**Rᴇᴀsᴏɴ:** {ban_reason}"
            )
            return
        return await func(client, message, *args, **kwargs)
    return wrapper

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Global variables initialization
renaming_operations = {}
active_sequences = {}
message_ids = {}
#flood_control = {}
file_queues = {}
actual_audio_label = "Sub"  # Initialize with default
USER_SEMAPHORES = {}
USER_LIMITS = {}
tasks = []
pending_pdf_replace = {}
pending_pdf_insert = {}
last_sequence_update = {}      # user_id -> timestamp
sequence_status_msg = {}       # user_id -> Message object
ADMINS = set(Config.ADMIN) if hasattr(Config, 'ADMIN') else set()

# Initialize global mode variables with safe defaults
PREMIUM_MODE = getattr(Config, 'GLOBAL_TOKEN_MODE', True)
PREMIUM_MODE_EXPIRY = getattr(Config, 'GLOBAL_TOKEN_MODE_EXPIRY', None)
ADMIN_MODE = getattr(Config, 'ADMIN_USAGE_MODE', False)
CON_LIMIT_ADMIN = getattr(Config, 'ADMIN_OR_PREMIUM_TASK_LIMIT', 5)
CON_LIMIT_NORMAL = getattr(Config, 'NORMAL_TASK_LIMIT', 2)
class ManualRenameQueue:
    def __init__(self):
        self.pending_manual_files = {}  # {user_id: {file_id: file_info}}
        self.waiting_for_input = {}  # {user_id: file_info}
        self.user_prompts = {}  # {user_id: prompt_message} - FIXED: renamed from pending_prompts
        self.current_processing = {}  # {user_id: file_info} - Track currently processing files
    
    async def add_manual_file(self, user_id: int, file_info: dict):
        """Add file to manual processing queue"""
        if user_id not in self.pending_manual_files:
            self.pending_manual_files[user_id] = {}
        
        file_id = file_info['file_id']
        self.pending_manual_files[user_id][file_id] = file_info
        logger.info(f"Added manual file for user {user_id}. Total: {len(self.pending_manual_files[user_id])}")
    
    async def get_next_manual_file(self, user_id: int) -> Optional[dict]:
        """Get next manual file waiting for input"""
        if user_id in self.pending_manual_files and self.pending_manual_files[user_id]:
            file_id = next(iter(self.pending_manual_files[user_id]))
            return self.pending_manual_files[user_id][file_id]
        return None
    
    async def start_manual_processing(self, user_id: int):
        """Start processing manual files for user"""
        if user_id in self.waiting_for_input:
            return  # Already processing
        
        next_file = await self.get_next_manual_file(user_id)
        if next_file:
            self.waiting_for_input[user_id] = next_file
            self.current_processing[user_id] = next_file
            await self.show_manual_prompt(user_id, next_file)
            return True
        return False
    
    async def show_manual_prompt(self, user_id: int, file_info: dict):
        """Show manual rename prompt with FIXED callback data"""
        try:
            # FIXED: Use shorter callback data to avoid "BUTTON_DATA_INVALID"
            file_id_short = file_info['file_id'][:10]  # Use first 10 chars of file_id
            
            keyboard = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("📹 Sample", callback_data=f"sample_{user_id}_{file_id_short}"),
                    InlineKeyboardButton("🖼️ Screenshots", callback_data=f"ss_{user_id}_{file_id_short}")
                ],
                [
                    InlineKeyboardButton("✏️ Rename Now", callback_data=f"ren_{user_id}_{file_id_short}"),
                    InlineKeyboardButton("❌ Skip", callback_data=f"skip_{user_id}_{file_id_short}")
                ]
            ])
            
            prompt_msg = await file_info['original_message'].reply_text(
                f"**🎬 Manual Rename Request**\n\n"
                f"**File:** `{file_info['file_name']}`\n"
                f"**Size:** `{humanbytes(file_info['file_size'])}`\n"
                f"**Type:** `{file_info['media_type'].upper()}`\n\n"
                f"**Choose an action:**",
                reply_markup=keyboard,
                parse_mode=ParseMode.MARKDOWN
            )
            
            self.user_prompts[user_id] = prompt_msg
            file_info['prompt_message'] = prompt_msg
            file_info['short_file_id'] = file_id_short  # Store short ID for matching
            
        except Exception as e:
            logger.error(f"Error showing manual prompt: {e}")
            raise
    
    async def complete_manual_file(self, user_id: int, file_id: str):
        """Complete manual file processing"""
        # Find file by short ID if needed
        actual_file_id = self._find_file_id_by_short(user_id, file_id)
        if not actual_file_id:
            actual_file_id = file_id
        
        if user_id in self.waiting_for_input:
            del self.waiting_for_input[user_id]
        
        if user_id in self.current_processing:
            del self.current_processing[user_id]
        
        if user_id in self.pending_manual_files and actual_file_id in self.pending_manual_files[user_id]:
            del self.pending_manual_files[user_id][actual_file_id]
            
            # Cleanup if no more files
            if not self.pending_manual_files[user_id]:
                del self.pending_manual_files[user_id]
        
        # Cleanup prompt
        if user_id in self.user_prompts:
            try:
                await self.user_prompts[user_id].delete()
            except:
                pass
            del self.user_prompts[user_id]
    
    def _find_file_id_by_short(self, user_id: int, short_file_id: str) -> Optional[str]:
        """Find actual file_id by short file_id"""
        if user_id in self.pending_manual_files:
            for file_id, file_info in self.pending_manual_files[user_id].items():
                if file_info.get('short_file_id') == short_file_id:
                    return file_id
        return None
    
    async def get_file_by_short_id(self, user_id: int, short_file_id: str) -> Optional[dict]:
        """Get file info by short file_id"""
        actual_file_id = self._find_file_id_by_short(user_id, short_file_id)
        if actual_file_id and user_id in self.pending_manual_files:
            return self.pending_manual_files[user_id].get(actual_file_id)
        return None
    
    async def skip_manual_file(self, user_id: int, file_id: str):
        """Skip a manual file"""
        await self.complete_manual_file(user_id, file_id)
        # Process next file
        await self.start_manual_processing(user_id)
    
    def cleanup_user(self, user_id: int):
        """Cleanup user data"""
        for key in [self.pending_manual_files, self.waiting_for_input, self.user_prompts, self.current_processing]:
            if user_id in key:
                del key[user_id]
    
    async def is_user_processing(self, user_id: int) -> bool:
        """Check if user is currently processing a file"""
        return user_id in self.current_processing
    
    async def get_queue_size(self, user_id: int) -> int:
        """Get manual queue size for user"""
        if user_id in self.pending_manual_files:
            return len(self.pending_manual_files[user_id])
        return 0

manual_rename_queue = ManualRenameQueue()

def parse_duration(arg):
    if not arg:
        return None
    arg = arg.lower().strip()
    if arg.endswith("d") or arg.endswith("day"):
        return int(re.match(r"(\d+)", arg).group(1))
    elif arg.endswith("m") or arg.endswith("month"):
        num = int(re.match(r"(\d+)", arg).group(1))
        return num * 30
    elif arg.endswith("y") or arg.endswith("year"):
        num = int(re.match(r"(\d+)", arg).group(1))
        return num * 365
    elif arg.isdigit():
        return int(arg)
    return None

# ==================== FIXED FLOOD CONTROL ====================
class FloodControl:
    def __init__(self):
        self.last_processed = {}
        self.cooldown = 2  # seconds between operations
    
    async def safe_reply_text(self, message, text, **kwargs):
        """Safely reply to a message with flood control"""
        user_id = message.from_user.id
        current_time = time.time()
        
        # Check cooldown
        if user_id in self.last_processed:
            time_since_last = current_time - self.last_processed[user_id]
            if time_since_last < self.cooldown:
                await asyncio.sleep(self.cooldown - time_since_last)
        
        self.last_processed[user_id] = time.time()
        return await message.reply_text(text, **kwargs)
    
    async def safe_edit_message(self, message, text, **kwargs):
        """Safely edit a message with flood control"""
        try:
            return await message.edit_text(text, **kwargs)
        except Exception as e:
            logger.warning(f"Edit message failed: {e}")
            return message
    
    async def safe_delete_message(self, message):
        """Safely delete a message"""
        try:
            await message.delete()
        except Exception as e:
            logger.warning(f"Delete message failed: {e}")

# Initialize flood_control as an instance, not a dict
flood_control = FloodControl()

# Add this near the top of your file with other constants
SORTING_MODES = {
    "Quality": "quality",
    "Title": "title", 
    "Both": "both",
    "Episode": "episode",
    "Season": "season"
}
@Client.on_callback_query(filters.regex(r"^set_sorting_mode:"))
async def set_sorting_mode_callback(client, callback_query):
    user_id = callback_query.from_user.id
    mode = callback_query.data.split(":")[1]
    
    await db.set_sorting_mode(user_id, mode)
    
    # Show what the mode does
    mode_descriptions = {
        "Quality": "Quality → Season → Episode/Chapter → Title",
        "Title": "Title → Season → Episode/Chapter → Quality", 
        "Both": "Title → Quality → Season → Episode/Chapter",
        "Episode": "Episode/Chapter → Quality → Title",
        "Season": "Season → Episode/Chapter → Quality → Title"
    }
    
    await callback_query.answer(f"Sorting mode set to: {mode}")
    await callback_query.message.edit_text(
        f"**✅ Sorting mode updated to: {mode}**\n\n"
        f"**Sorting order:**\n`{mode_descriptions.get(mode, 'Default sorting')}`\n\n"
        "Your files will now be sorted in this order when using /ssequence.\n"
        "**Manga files:** Sorted by chapter number\n"
        "**Anime files:** Sorted by episode number"
    )
@Client.on_message(filters.command("sorting_mode") & filters.private)
@check_ban_status
async def show_sorting_mode_options(client, message):
    user_id = message.from_user.id
    current_mode = await db.get_sorting_mode(user_id) or "Season"
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                f"✅ Quality" if current_mode == "Quality" else "Quality",
                callback_data="set_sorting_mode:Quality"
            ),
            InlineKeyboardButton(
                f"✅ Title" if current_mode == "Title" else "Title", 
                callback_data="set_sorting_mode:Title"
            )
        ],
        [
            InlineKeyboardButton(
                f"✅ Both" if current_mode == "Both" else "Both",
                callback_data="set_sorting_mode:Both"
            ),
            InlineKeyboardButton(
                f"✅ Episode" if current_mode == "Episode" else "Episode",
                callback_data="set_sorting_mode:Episode"
            )
        ],
        [
            InlineKeyboardButton(
                f"✅ Season" if current_mode == "Season" else "Season",
                callback_data="set_sorting_mode:Season"
            )
        ]
    ])
    
    await message.reply_text(
        f"**Current Sorting Mode: {current_mode}**\n\n"
        "**Select a new sorting mode:**\n"
        "• **Quality**: Sort by quality then episode/chapter\n"
        "• **Title**: Sort by title then episode/chapter\n" 
        "• **Both**: Sort by title, quality, then episode/chapter\n"
        "• **Episode**: Default sorting by episode/chapter only\n"
        "• **Season**: Sort by season, then episode/chapter, then quality\n\n"
        "**Note:** Manga files are sorted by chapter, anime files by episode",
        reply_markup=keyboard
    )
@Client.on_message(filters.command("pdf_replace") & filters.reply)
@check_ban_status
async def pdf_replace_banner(client, message: Message):
    replied = message.reply_to_message
    user_id = message.from_user.id
    if not replied or not replied.document or not replied.document.file_name.lower().endswith(".pdf"):
        return await message.reply("**Rᴇᴘʟʏ ᴛᴏ ᴀ PDF ᴡɪᴛʜ `/pdf_replace first`, `/pdf_replace last`, ᴏʀ `/pdf_replace first,last`**")
    args = message.text.split(maxsplit=1)
    if len(args) < 2 or not args[1].strip():
        return await message.reply("**Sᴘᴇᴄɪꜰʏ ᴡʜɪᴄʜ ᴘᴀɢᴇ⁽s⁾ ᴛᴏ ʀᴇᴘʟᴀᴄᴇ﹕ `/pdf_replace first`, `/pdf_replace last`, ᴏʀ `/pdf_replace first,last`**")
    page_args = [x.strip().lower() for x in args[1].split(",") if x.strip() in ("first", "last")]
    if not page_args:
        return await message.reply("**Oɴʟʏ `first`, `last`, ᴏʀ ʙᴏᴛʜ ᴀʀᴇ sᴜᴘᴘᴏʀᴛᴇᴅ.**")
    banner_file_id = await db.get_pdf_banner(user_id)
    if not banner_file_id:
        return await message.reply("**Yᴏᴜ ʜᴀᴠᴇ ɴᴏᴛ sᴇᴛ ᴀ PDF ʙᴀɴɴᴇʀ. Rᴇᴘʟʏ ᴛᴏ ᴀ ᴘʜᴏᴛᴏ ᴡɪᴛʜ `/set_pdf_banner` ꜰɪʀsᴛ.**")
    processing_msg = await message.reply("**Pʀᴏᴄᴇssɪɴɢ, ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ᴍᴏᴍᴇɴᴛs...**")
    input_path = await replied.download()
    output_path = input_path
    temp_banner_path = input_path + "_banner.jpg"
    try:
        await client.download_media(banner_file_id, file_name=temp_banner_path)
        reader = PdfReader(input_path)
        writer = PdfWriter()
        num_pages = len(reader.pages)
        img = Image.open(temp_banner_path).convert("RGB")
        img = img.resize((800, 1131))
        img_pdf_path = temp_banner_path + ".pdf"
        img.save(img_pdf_path, "PDF")
        img_reader = PdfReader(img_pdf_path)
        img_page = img_reader.pages[0]
        indices = set()
        if "first" in page_args:
            indices.add(0)
        if "last" in page_args:
            indices.add(num_pages - 1)
        for i, page in enumerate(reader.pages):
            if i in indices:
                writer.add_page(img_page)
            else:
                writer.add_page(page)
        with open(output_path, "wb") as f:
            writer.write(f)
        thumb = await db.get_thumbnail(message.chat.id)
        thumb_path = None
        if thumb:
            thumb_path = await client.download_media(thumb)
        await client.send_document(
            message.chat.id,
            output_path,
            caption=f"**Rᴇᴘʟᴀᴄᴇᴅ ᴘᴀɢᴇs﹕ {', '.join(page_args)} ᴡɪᴛʜ ʏᴏᴜʀ ʙᴀɴɴᴇʀ.**",
            thumb=thumb_path if thumb_path else None
        )
        if thumb_path:
            os.remove(thumb_path)
        await processing_msg.delete()
    except Exception as e:
        await processing_msg.delete()
        await message.reply(f"**Fᴀɪʟᴇᴅ ᴛᴏ ʀᴇᴘʟᴀᴄᴇ ᴘᴀɢᴇs﹕** `{e}`")
    finally:
        for path in [input_path, output_path, temp_banner_path, temp_banner_path + ".pdf"]:
            if os.path.exists(path):
                os.remove(path)

@Client.on_message(filters.command("pdf_extractor") & filters.reply)
@check_ban_status
async def pdf_extractor_first_last(client, message: Message):
    replied = message.reply_to_message
    if not replied or not replied.document or not replied.document.file_name.lower().endswith(".pdf"):
        return await message.reply("**Rᴇᴘʟʏ ᴛᴏ ᴀ PDF ꜰɪʟᴇ ᴡɪᴛʜ `/pdf_extractor`**")
    processing_msg = await message.reply("**Pʀᴏᴄᴇssɪɴɢ, ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ᴍᴏᴍᴇɴᴛs...**")
    input_path = await replied.download()
    first_img_path = None
    last_img_path = None
    try:
        reader = PdfReader(input_path)
        num_pages = len(reader.pages)
        first_img = convert_from_path(input_path, first_page=1, last_page=1)[0]
        last_img = convert_from_path(input_path, first_page=num_pages, last_page=num_pages)[0]
        first_img_path = input_path.replace(".pdf", "_first.jpg")
        last_img_path = input_path.replace(".pdf", "_last.jpg")
        first_img.save(first_img_path, "JPEG")
        last_img.save(last_img_path, "JPEG")
        await client.send_photo(message.chat.id, first_img_path, caption="**Fɪʀsᴛ ᴘᴀɢᴇ ᴀs ɪᴍᴀɢᴇ**")
        await client.send_photo(message.chat.id, last_img_path, caption="**Lᴀsᴛ ᴘᴀɢᴇ ᴀs ɪᴍᴀɢᴇ**")
        await processing_msg.delete()
    except Exception as e:
        await processing_msg.delete()
        await message.reply(f"**Fᴀɪʟᴇᴅ ᴛᴏ ᴇxᴛʀᴀᴄᴛ ᴘᴀɢᴇs﹕** `{e}`")
    finally:
        if os.path.exists(input_path):
            os.remove(input_path)
        if first_img_path and os.path.exists(first_img_path):
            os.remove(first_img_path)
        if last_img_path and os.path.exists(last_img_path):
            os.remove(last_img_path)

@Client.on_message(filters.command("pdf_add") & filters.reply)
@check_ban_status
async def pdf_add_banner(client, message: Message):
    replied = message.reply_to_message
    user_id = message.from_user.id
    if not replied or not replied.document or not replied.document.file_name.lower().endswith(".pdf"):
        return await message.reply("**Rᴇᴘʟʏ ᴛᴏ ᴀ PDF ᴡɪᴛʜ `/pdf_add first`, `/pdf_add last`, ᴏʀ `/pdf_add first,last`**")
    args = message.text.split(maxsplit=1)
    if len(args) < 2 or not args[1].strip():
        return await message.reply("**Sᴘᴇᴄɪꜰʏ ᴡʜᴇʀᴇ ᴛᴏ ᴀᴅᴅ﹕ `/pdf_add first`, `/pdf_add last`, ᴏʀ `/pdf_add first,last`**")
    page_args = [x.strip().lower() for x in args[1].split(",") if x.strip() in ("first", "last")]
    if not page_args:
        return await message.reply("**Oɴʟʏ `first`, `last`, ᴏʀ ʙᴏᴛʜ ᴀʀᴇ sᴜᴘᴘᴏʀᴛᴇᴅ.**")
    banner_file_id = await db.get_pdf_banner(user_id)
    if not banner_file_id:
        return await message.reply("**Yᴏᴜ ʜᴀᴠᴇ ɴᴏᴛ sᴇᴛ ᴀ PDF ʙᴀɴɴᴇʀ. Rᴇᴘʟʏ ᴛᴏ ᴀ ᴘʜᴏᴛᴏ ᴡɪᴛʜ `/set_pdf_banner` ꜰɪʀsᴛ.**")
    processing_msg = await message.reply("**Pʀᴏᴄᴇssɪɴɢ, ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ᴍᴏᴍᴇɴᴛs...**")
    input_path = await replied.download()
    output_path = input_path
    temp_banner_path = input_path + "_banner.jpg"
    try:
        await client.download_media(banner_file_id, file_name=temp_banner_path)
        reader = PdfReader(input_path)
        writer = PdfWriter()
        num_pages = len(reader.pages)
        img = Image.open(temp_banner_path).convert("RGB")
        img_pdf_path = temp_banner_path + ".pdf"
        img.save(img_pdf_path, "PDF")
        img_reader = PdfReader(img_pdf_path)
        img_page = img_reader.pages[0]
        if "first" in page_args:
            writer.add_page(img_page)
        for page in reader.pages:
            writer.add_page(page)
        if "last" in page_args:
            writer.add_page(img_page)
        with open(output_path, "wb") as f:
            writer.write(f)
        thumb = await db.get_thumbnail(message.chat.id)
        thumb_path = None
        if thumb:
            thumb_path = await client.download_media(thumb)
        await client.send_document(
            message.chat.id,
            output_path,
            caption=f"**Aᴅᴅᴇᴅ ʙᴀɴɴᴇʀ ᴘᴀɢᴇ(s): {', '.join(page_args)}**",
            thumb=thumb_path if thumb_path else None
        )
        if thumb_path:
            os.remove(thumb_path)
        await processing_msg.delete()
    except Exception as e:
        await processing_msg.delete()
        await message.reply(f"**Fᴀɪʟᴇᴅ ᴛᴏ ᴀᴅᴅ ʙᴀɴɴᴇʀ ᴘᴀɢᴇ⁽s⁾﹕** `{e}`")
    finally:
        for path in [input_path, output_path, temp_banner_path, temp_banner_path + ".pdf"]:
            if os.path.exists(path):
                os.remove(path)

@Client.on_message(filters.command("set_pdf_lock"))
@check_ban_status
async def set_pdf_lock_cmd(client, message: Message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2 or not args[1].strip():
        return await message.reply("** Usᴀɢᴇ﹕** `/set_pdf_lock yourpassword`")
    password = args[1].strip()
    await db.set_pdf_lock_password(message.from_user.id, password)
    await message.reply("**Dᴇꜰᴀᴜʟᴛ PDF ʟᴏᴄᴋ ᴘᴀssᴡᴏʀᴅ sᴇᴛ﹗ Nᴏᴡ ʏᴏᴜ ᴄᴀɴ ᴜsᴇ `/pdf_lock` ᴡɪᴛʜᴏᴜᴛ sᴘᴇᴄɪꜰʏɪɴɢ ᴀ ᴘᴀssᴡᴏʀᴅ.**")

@Client.on_message(filters.command("pdf_lock") & filters.reply)
@check_ban_status
async def pdf_lock_password(client, message: Message):
    replied = message.reply_to_message
    if not replied or not replied.document or not replied.document.file_name.lower().endswith(".pdf"):
        return await message.reply("**Rᴇᴘʟʏ ᴛᴏ ᴀ PDF ꜰɪʟᴇ ᴡɪᴛʜ `/pdf_lock yourpassword`**")
    args = message.text.split(maxsplit=1)
    if len(args) < 2 or not args[1].strip():
        password = await db.get_pdf_lock_password(message.from_user.id)
        if not password:
            return await message.reply("**Nᴏ ᴘᴀssᴡᴏʀᴅ sᴇᴛ﹗ Usᴇ `/set_pdf_lock yourpassword` ꜰɪʀsᴛ ᴏʀ `/pdf_lock yourpassword`**")
    else:
        password = args[1].strip()
    input_path = await replied.download()
    output_path = input_path.replace(".pdf", "_locked.pdf")
    processing_msg = await message.reply("**Pʀᴏᴄᴇssɪɴɢ, ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ᴍᴏᴍᴇɴᴛs...**")
    try:
        reader = PdfReader(input_path)
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        writer.encrypt(password)
        with open(output_path, "wb") as f:
            writer.write(f)
        thumb = await db.get_thumbnail(message.chat.id)
        thumb_path = None
        if thumb:
            thumb_path = await client.download_media(thumb)
        await client.send_document(
            message.chat.id,
            output_path,
            caption="**Tʜᴇ PDF ʜᴀs ʙᴇᴇɴ ʟᴏᴄᴋᴇᴆ ᴡɪᴛʜ ʏᴏᴜʀ ᴘᴀssᴡᴏʀᴅ.**",
            thumb=thumb_path if thumb_path else None
        )
        if thumb_path:
            os.remove(thumb_path)
        await processing_msg.delete()
    except Exception as e:
        await processing_msg.delete()
        await message.reply(f"**Fᴀɪʟᴇᴅ ᴛᴏ ʟᴏᴄᴋ PDF﹕** `{e}`")
    finally:
        if os.path.exists(input_path):
            os.remove(input_path)
        if os.path.exists(output_path):
            os.remove(output_path)

@Client.on_message(filters.command("pdf_remove") & filters.reply)
@check_ban_status
async def pdf_remove_pages(client, message: Message):
    replied = message.reply_to_message
    if not replied or not replied.document or not replied.document.file_name.lower().endswith(".pdf"):
        return await message.reply("**Rᴇᴘʟʏ ᴛᴏ ᴀ PDF ғɪʟᴇ ᴡɪᴛʜ /pdf_remove 1,2,3**")
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("**Sᴘᴇᴄɪғʏ ᴘᴀɢᴇs ᴛᴏ ʀᴇᴍᴏᴠᴇ, ᴇ.ɢ. /pdf_remove 1,3,5**")
    remove_pages = [int(x.strip())-1 for x in args[1].split(",") if x.strip().isdigit()]
    input_path = await replied.download()
    output_path = input_path.replace(".pdf", "_removed.pdf")
    processing_msg = await message.reply("**Pʀᴏᴄᴇssɪɴɢ, ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ᴀ ꜰᴇᴡ ᴍᴏᴍᴇɴᴛs...**")
    try:
        reader = PdfReader(input_path)
        writer = PdfWriter()
        for i, page in enumerate(reader.pages):
            if i not in remove_pages:
                writer.add_page(page)
        with open(output_path, "wb") as f:
            writer.write(f)
        # Fetch user thumbnail if set
        thumb = await db.get_thumbnail(message.chat.id)
        thumb_path = None
        if thumb:
            thumb_path = await client.download_media(thumb)
        await client.send_document(
            message.chat.id,
            output_path,
            caption=f"**Rᴇᴍᴏᴠᴇᴅ ᴘᴀɢᴇs: {args[1]}**",
            thumb=thumb_path if thumb_path else None
        )
        if thumb_path:
            os.remove(thumb_path)
        await processing_msg.delete()
    except Exception as e:
        await processing_msg.delete()
        await message.reply(f"**Fᴀɪʟᴇᴅ ᴛᴏ ʀᴇᴍᴏᴠᴇ ᴘᴀɢᴇs﹕** `{e}`")
    finally:
        if os.path.exists(input_path):
            os.remove(input_path)
        if os.path.exists(output_path):
            os.remove(output_path)

@Client.on_message(filters.command("upscale_ffmpeg") & filters.reply)
@check_ban_status
async def ffmpeg_upscale_photo(client, message):
    replied = message.reply_to_message
    if not replied or not replied.photo:
        return await message.reply("**Rᴇᴘʟʏ ᴛᴏ ᴀ ᴘʜᴏᴛᴏ ᴡɪᴛʜ /upscale_ffmpeg ᴛᴏ ᴜᴘsᴄᴀʟᴇ ɪᴛ (ʟᴏᴄᴀʟʟʏ, ɴᴏ API ɴᴇᴇᴅᴇᴅ)﹗**")
    status = await message.reply("**Uᴘsᴄᴀʟɪɴɢ ɪᴍᴀɢᴇ ᴡɪᴛʜ FFᴍᴘᴇɢ... Pʟᴇᴀsᴇ ᴡᴀɪᴛ.**")
    input_path = await replied.download()
    output_path = "upscale_img.jpg"

    try:
        ffmpeg = shutil.which('ffmpeg')
        if not ffmpeg:
            await status.edit("**Uᴘsᴄᴀʟɪɴɢ ꜰᴀɪʟᴇᴅ﹕ FFᴍᴘᴇɢ ɴᴏᴛ ꜰᴏᴜɴᴅ ᴏɴ sᴇʀᴠᴇʀ.**")
            return

        # Get original dimensions
        process = await asyncio.create_subprocess_exec(
            ffmpeg, "-v", "error", "-select_streams", "v:0", "-show_entries",
            "stream=width,height", "-of", "csv=s=x:p=0", "-i", input_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await process.communicate()
        width, height = 0, 0
        try:
            dims = stdout.decode().strip().split("x")
            width, height = int(dims[0]), int(dims[1])
        except Exception:
            pass

        target_width = width * 2 if width else 0
        target_height = height * 2 if height else 0

        vf = (
            f"scale={target_width}:{target_height}:flags=lanczos,"
            "hqdn3d=3.0:3.0:8:8,"
            "smartblur=lr=1.0:ls=-1.0:lt=0.8,"
            "unsharp=7:7:1.0:7:7:0.0,"
            "deband"
        )

        cmd = [
            ffmpeg,
            "-y",
            "-i", input_path,
            "-vf", vf,
            output_path
        ]
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        _, stderr = await process.communicate()
        if process.returncode != 0 or not os.path.exists(output_path):
            await status.edit(f"**Uᴘsᴄᴀʟɪɴɢ ꜰᴀɪʟᴇᴅ﹕** {stderr.decode().strip()}")
            return

        await client.send_photo(message.chat.id, output_path, caption="**Uᴘsᴄᴀʟᴇᴅ ɪᴍᴀɢᴇ ⁽FFmpeg AI-Like 2x, Sᴍᴏᴏᴛʜ & Dᴇɴᴏɪsᴇᴅ⁾**")
        await status.delete()
    except Exception as e:
        await status.edit(f"**Uᴘsᴄᴀʟɪɴɢ ꜰᴀɪʟᴇᴅ﹕** `{e}`")
    finally:
        for path in [input_path, output_path]:
            if path and os.path.exists(path):
                os.remove(path)
                
@Client.on_message(filters.command("add_admin"))
async def add_admin(client, message):
    if message.from_user.id not in ADMINS:
        return
    
    try:
        target = message.text.split()[1]
        if target.startswith("@"):
            user = await client.get_users(target)
            ADMINS.add(user.id)
        else:
            ADMINS.add(int(target))
        await message.reply(f"Aᴅᴅᴇᴅ ᴀᴅᴍɪɴ: {target}")
    except Exception as e:
        await message.reply(f"Eʀʀᴏʀ: {str(e)}")

@Client.on_message(filters.command("admin_mode"))
async def admin_mode(client, message):
    global ADMIN_MODE
    user_id = message.from_user.id
    if user_id not in ADMINS:
        return await message.reply("Aᴅᴍɪɴ ᴏɴʟʏ ᴄᴏᴍᴍᴀɴᴅ!")
    
    args = message.text.split()
    if len(args) < 2:
        mode = "on" if ADMIN_MODE else "off"
        return await message.reply(f"Aᴅᴍɪɴ Mᴏᴅᴇ ɪs ᴄᴜʀʀᴇɴᴛʟʏ {mode}")
    
    if args[1].lower() in ("on", "yes", "true"):
        ADMIN_MODE = True
        await message.reply("Aᴅᴍɪɴ Mᴏᴅᴇ ᴇɴᴀʙʟᴇᴅ - Oɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ᴜsᴇ ᴛʜᴇ ʙᴏᴛ")
    else:
        ADMIN_MODE = False
        await message.reply("Aᴅᴍɪɴ Mᴏᴅᴇ ᴅɪsᴀʙʟᴇᴅ - Aʟʟ ᴜsᴇʀs ᴄᴀɴ ᴀᴄᴄᴇss")

# ==================== FIXED TASK QUEUE CLASS ====================
class TaskQueue:
    def __init__(self):
        self.queues: Dict[int, Deque[Tuple[str, Message, callable, str, int]]] = {}
        self.processing: Dict[int, Dict[str, str]] = {}
        self.tasks: Dict[str, asyncio.Task] = {}
        self.max_retries = 3
        self.locks: Dict[int, asyncio.Lock] = {}
        self.active_processors: Dict[int, List[asyncio.Task]] = {}
        self.shutdown = False
        self.last_processed: Dict[int, float] = {}  # ADD THIS MISSING ATTRIBUTE
        
    async def add_task(self, user_id: int, file_id: str, message: Message, coro, file_size: int = 0):
        """Add a task to the user's queue with file size"""
        if ADMIN_MODE and user_id not in ADMINS:
            await message.reply_text("Aᴅᴍɪɴ ᴍᴏᴅᴇ ᴀᴄᴛɪᴠᴇ - Oɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ǫᴜᴇᴜᴇ ғɪʟᴇs!")
            return False

        # Extract file name from message
        file_name = self._extract_file_name(message)

        async with self.locks.setdefault(user_id, asyncio.Lock()):
            if user_id not in self.queues:
                self.queues[user_id] = deque()
                self.processing[user_id] = {}

            # Store file_id, message, coro, file_name, AND file_size
            self.queues[user_id].append((file_id, message, coro, file_name, file_size))
            logger.info(f"Task queued for user {user_id}, file: {file_name}, size: {file_size}. Queue size: {len(self.queues[user_id])}")

        # Initialize user semaphore if not exists
        if user_id not in USER_SEMAPHORES:
            concurrency_limit = CON_LIMIT_ADMIN if user_id in ADMINS else CON_LIMIT_NORMAL
            USER_SEMAPHORES[user_id] = asyncio.Semaphore(concurrency_limit)
            USER_LIMITS[user_id] = concurrency_limit

        # Start processor if not already running
        if user_id not in self.active_processors:
            self.active_processors[user_id] = []
            for i in range(USER_LIMITS[user_id]):
                processor_task = asyncio.create_task(
                    self._process_user_queue(user_id, f"processor_{user_id}_{i}")
                )
                self.active_processors[user_id].append(processor_task)

        return True

    def _extract_file_name(self, message: Message) -> str:
        """Extract file name from message"""
        if message.document:
            return message.document.file_name or "Unknown Document"
        elif message.video:
            return message.video.file_name or "Unknown Video"
        elif message.audio:
            return message.audio.file_name or "Unknown Audio"
        else:
            return "Unknown File"

    async def _process_user_queue(self, user_id: int, processor_name: str):
        """Process tasks for a specific user"""
        logger.info(f"Started queue processor {processor_name} for user {user_id}")
        
        while not self.shutdown:
            try:
                current_time = time.time()
                last_processed = self.last_processed.get(user_id, 0)  # FIXED: Now using self.last_processed
                if current_time - last_processed < 5.0:  # 2 seconds between files
                    await asyncio.sleep(5.0 - (current_time - last_processed))
                
                # Get next task
                async with self.locks[user_id]:
                    if not self.queues.get(user_id):
                        await asyncio.sleep(1)
                        continue
                    
                    file_id, message, coro, file_name, file_size = self.queues[user_id].popleft()
                    
                    # Check if file is already being processed
                    if file_id in self.processing[user_id]:
                        logger.warning(f"File {file_id} already processing, skipping")
                        continue
                    
                    # Store file name in processing dict
                    self.processing[user_id][file_id] = file_name

                # Acquire semaphore and process task
                semaphore = USER_SEMAPHORES.get(user_id)
                if not semaphore:
                    logger.error(f"No semaphore for user {user_id}")
                    continue

                async with semaphore:
                    task_id = f"{user_id}:{file_id}"
                    try:
                        success = False
                        for attempt in range(self.max_retries):
                            try:
                                logger.info(f"Processing task {task_id}, file: {file_name}, size: {file_size}, attempt {attempt + 1}")
                                await coro(file_size)  # Pass file_size to coroutine
                                success = True
                                logger.info(f"Task {task_id} completed successfully: {file_name}")
                                break
                                
                            except FloodWait as e:
                                wait_time = e.value + 1
                                logger.warning(f"FloodWait for {user_id}: Waiting {wait_time}s, attempt {attempt+1}/{self.max_retries}")
                                await asyncio.sleep(wait_time)
                                
                            except Exception as e:
                                logger.error(f"Task error for {file_name} (attempt {attempt+1}): {e}")
                                if attempt == self.max_retries - 1:
                                    await self._handle_failure(message, file_id, file_name, e)
                                else:
                                    await asyncio.sleep(2)  # Wait before retry

                    except Exception as e:
                        logger.error(f"Unexpected error in task processor for {file_name}: {e}")
                        await self._handle_failure(message, file_id, file_name, e)
                        
                    finally:
                        # Cleanup
                        async with self.locks[user_id]:
                            if file_id in self.processing[user_id]:
                                del self.processing[user_id][file_id]
                            self.tasks.pop(task_id, None)
                        # Update last_processed timestamp
                        self.last_processed[user_id] = time.time()  # FIXED: Update the timestamp

            except Exception as e:
                logger.error(f"Queue processor error: {e}")
                await asyncio.sleep(5)  # Prevent tight loop on errors

        logger.info(f"Queue processor {processor_name} stopped")

    async def _handle_failure(self, message: Message, file_id: str, file_name: str, error: Exception):
        """Handle task failure"""
        try:
            error_msg = await message.reply_text(
                f"**❌ Fᴀɪʟᴇᴅ ᴛᴏ ᴘʀᴏᴄᴇss ғɪʟᴇ:** `{file_name}`\n"
                f"**Aғᴛᴇʀ:** `{self.max_retries}` ᴀᴛᴛᴇᴍᴘᴛs\n"
                f"**Eʀʀᴏʀ:** `{str(error)[:200]}`"
            )
            # Auto-delete error message after 30 seconds
            await asyncio.sleep(30)
            await error_msg.delete()
        except Exception as e:
            logger.error(f"Failed to send error message: {e}")

    async def get_queue_status(self, user_id: int) -> dict:
        """Get detailed queue status for a user"""
        async with self.locks.get(user_id, asyncio.Lock()):
            # Get queued files
            queued_files = []
            if user_id in self.queues:
                for _, _, _, file_name, file_size in list(self.queues[user_id]):
                    queued_files.append((file_name, file_size))
            
            # Get processing files  
            processing_files = []
            if user_id in self.processing:
                processing_files = list(self.processing[user_id].values())
            
            queue_size = len(queued_files)
            processing_size = len(processing_files)
            
            return {
                "queued": queue_size,
                "processing": processing_size,
                "total": queue_size + processing_size,
                "concurrency_limit": USER_LIMITS.get(user_id, CON_LIMIT_NORMAL),
                "queued_files": queued_files,
                "processing_files": processing_files
            }

    async def cancel_all(self, user_id: int) -> int:
        """Cancel all tasks for a user"""
        async with self.locks.get(user_id, asyncio.Lock()):
            canceled = len(self.queues.get(user_id, []))
            
            # Clear queued tasks
            if user_id in self.queues:
                self.queues[user_id].clear()
            
            # Cancel processing tasks
            canceled_processing = 0
            for file_id in list(self.processing.get(user_id, {}).keys()):
                task_id = f"{user_id}:{file_id}"
                task = self.tasks.get(task_id)
                if task and not task.done():
                    task.cancel()
                    canceled_processing += 1
                    if file_id in self.processing[user_id]:
                        del self.processing[user_id][file_id]
                    self.tasks.pop(task_id, None)
            
            logger.info(f"Canceled {canceled} queued and {canceled_processing} processing tasks for user {user_id}")
            return canceled + canceled_processing

    async def shutdown_user_queues(self, user_id: int):
        """Shutdown all processors for a user"""
        if user_id in self.active_processors:
            for task in self.active_processors[user_id]:
                if not task.done():
                    task.cancel()
            del self.active_processors[user_id]

    async def global_shutdown(self):
        """Shutdown the entire queue system"""
        self.shutdown = True
        for user_id in list(self.active_processors.keys()):
            await self.shutdown_user_queues(user_id)

    async def get_global_queue_status(self) -> dict:
        """Get global queue statistics"""
        total_queued = sum(len(q) for q in self.queues.values())
        total_processing = sum(len(p) for p in self.processing.values())
        active_users = len(self.active_processors)
        
        return {
            "total_queued": total_queued,
            "total_processing": total_processing,
            "active_users": active_users,
            "user_queues": {
                user_id: len(queue) for user_id, queue in self.queues.items()
            }
        }

    async def pause_user_queue(self, user_id: int) -> bool:
        """Pause a user's queue"""
        if user_id in self.active_processors:
            for task in self.active_processors[user_id]:
                if not task.done():
                    task.cancel()
            return True
        return False

    async def resume_user_queue(self, user_id: int) -> bool:
        """Resume a user's queue"""
        if user_id not in self.active_processors and user_id in self.queues:
            concurrency_limit = CON_LIMIT_ADMIN if user_id in ADMINS else CON_LIMIT_NORMAL
            USER_SEMAPHORES[user_id] = asyncio.Semaphore(concurrency_limit)
            
            self.active_processors[user_id] = []
            for i in range(concurrency_limit):
                processor_task = asyncio.create_task(
                    self._process_user_queue(user_id, f"processor_{user_id}_{i}")
                )
                self.active_processors[user_id].append(processor_task)
            return True
        return False

# Global task queue instance
task_queue = TaskQueue()

@Client.on_message((filters.group | filters.private) & filters.command("queue"))
@check_ban_status
async def queue_status(client, message: Message):
    user_id = message.from_user.id
    
    # Get detailed queue status
    status = await task_queue.get_queue_status(user_id)
    
    # Build detailed queue message
    queue_info = []
    queue_info.append("**📊 Fɪʟᴇ Qᴜᴇᴜᴇ Sᴛᴀᴛᴜs:**")
    queue_info.append(f"**➠ Pʀᴏᴄᴇssɪɴɢ:** `{status['processing']}` files")
    queue_info.append(f"**➠ Wᴀɪᴛɪɴɢ:** `{status['queued']}` files") 
    queue_info.append(f"**➠ Tᴏᴛᴀʟ:** `{status['total']}` files")
    queue_info.append(f"**➠ Cᴏɴᴄᴜʀʀᴇɴᴄʏ Lɪᴍɪᴛ:** `{status['concurrency_limit']}` files")
    
    # Show file names if available
    if status['processing_files']:
        queue_info.append("\n**🔄 Cᴜʀʀᴇɴᴛʟʏ Pʀᴏᴄᴇssɪɴɢ:**")
        for i, file_name in enumerate(status['processing_files'][:3], 1):
            queue_info.append(f"`{i}. {file_name}`")
        if len(status['processing_files']) > 3:
            queue_info.append(f"`... and {len(status['processing_files']) - 3} more`")
    
    if status['queued_files']:
        queue_info.append("\n**⏳ Wᴀɪᴛɪɴɢ ɪɴ Qᴜᴇᴜᴇ:**")
        for i, file_name in enumerate(status['queued_files'][:5], 1):
            queue_info.append(f"`{i}. {file_name}`")
        if len(status['queued_files']) > 5:
            queue_info.append(f"`... and {len(status['queued_files']) - 5} more`")
    
    queue_info.append("\n**Usᴇ /cancel ᴛᴏ ᴄᴀɴᴄᴇʟ ᴀʟʟ ǫᴜᴇᴜᴇᴅ ᴛᴀsᴋs**")
    
    await message.reply_text("\n".join(queue_info))


async def send_queue_update(client, user_id, file_name, action="added"):
    """Send queue update message"""
    try:
        status = await task_queue.get_queue_status(user_id)
        
        if action == "added":
            message_text = (
                f"**📥 Fɪʟᴇ Aᴅᴅᴇᴅ ᴛᴏ Qᴜᴇᴜᴇ:** `{file_name}`\n\n"
                f"**📊 Qᴜᴇᴜᴇ Sᴛᴀᴛᴜs:**\n"
                f"• **Pʀᴏᴄᴇssɪɴɢ:** `{status['processing']}` files\n"
                f"• **Wᴀɪᴛɪɴɢ:** `{status['queued']}` files\n"
                f"• **Yᴏᴜʀ Pᴏsɪᴛɪᴏɴ:** `#{status['queued']}` in queue\n\n"
                f"*Usᴇ /queue ᴛᴏ sᴇᴇ ғᴜʟʟ ᴅᴇᴛᴀɪʟs*"
            )
        
        # Send update (this will auto-delete after 20 seconds)
        update_msg = await client.send_message(user_id, message_text)
        
        # Auto-delete after 20 seconds
        await asyncio.sleep(20)
        await update_msg.delete()
        
    except Exception as e:
        logger.error(f"Queue update error: {e}")
@Client.on_message((filters.group | filters.private) & filters.command("cancel"))
@check_ban_status
async def cancel_queue(client, message: Message):
    user_id = message.from_user.id
    
    # Get status before canceling
    status_before = await task_queue.get_queue_status(user_id)
    
    canceled = await task_queue.cancel_all(user_id)
    
    if canceled > 0:
        cancel_msg = (
            f"**✅ Cᴀɴᴄᴇʟᴇᴅ {canceled} ᴛᴀsᴋs!**\n\n"
            f"**Dᴇᴛᴀɪʟs:**\n"
            f"• **Pʀᴏᴄᴇssɪɴɢ:** `{status_before['processing']}` files\n"  
            f"• **Qᴜᴇᴜᴇᴅ:** `{status_before['queued']}` files\n"
            f"• **Tᴏᴛᴀʟ:** `{canceled}` files canceled"
        )
        await message.reply_text(cancel_msg)
    else:
        await message.reply_text("**ℹ️ Nᴏ ᴛᴀsᴋs ɪɴ ǫᴜᴇᴜᴇ ᴛᴏ ᴄᴀɴᴄᴇʟ.**")
        
def detect_quality(file_name):
    quality_order = {
        "144p": 1,
        "240p": 2,
        "360p": 3,
        "480p": 4,
        "720p": 5, 
        "1080p": 6,
        "1440p": 7,
        "2160p": 8
        }
    match = re.search(r"(144p|240p|360p|480p|720p|1080p|1440p|2160p)", file_name)
    return quality_order.get(match.group(1), 8) if match else 9

@Client.on_message(filters.command("ssequence") & filters.private)
@check_ban_status
async def start_sequence(client, message: Message):
    user_id = message.from_user.id
    if ADMIN_MODE and user_id not in ADMINS:
        return await message.reply_text("**Aᴅᴍɪɴ ᴍᴏᴅᴇ ɪs ᴀᴄᴛɪᴠᴇ - Oɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ᴜsᴇ sᴇǫᴜᴇɴᴄᴇs!**")
        
    if user_id in active_sequences:
        await message.reply_text("**A sᴇǫᴜᴇɴᴄᴇ ɪs ᴀʟʀᴇᴀᴅʏ ᴀᴄᴛɪᴠᴇ! Usᴇ /esequence ᴛᴏ ᴇɴᴅ ɪᴛ.**")
    else:
        active_sequences[user_id] = []
        message_ids[user_id] = []
        msg = await message.reply_text("**Sᴇǫᴜᴇɴᴄᴇ ʜᴀs ʙᴇᴇɴ sᴛᴀʀᴛᴇᴅ! Sᴇɴᴅ ʏᴏᴜʀ ғɪʟᴇs...**")
        message_ids[user_id].append(msg.id)


@Client.on_message(filters.command("esequence") & filters.private)
@check_ban_status
async def end_sequence(client, message: Message):
    user_id = message.from_user.id
    if ADMIN_MODE and user_id not in ADMINS:
        return await message.reply_text("**Aᴅᴍɪɴ ᴍᴏᴅᴇ ɪs ᴀᴄᴛɪᴠᴇ - Oɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ᴜsᴇ sᴇǫᴜᴇɴᴄᴇs!**")
    
    if user_id not in active_sequences:
        return await message.reply_text("**Nᴏ ᴀᴄᴛɪᴠᴇ sᴇǫᴜᴇɴᴄᴇ ғᴏᴜɴᴅ!**\n**Usᴇ /ssequence ᴛᴏ sᴛᴀʀᴛ ᴏɴᴇ.**")

    file_list = active_sequences.pop(user_id, [])
    delete_messages = message_ids.pop(user_id, [])

    if not file_list:
        return await message.reply_text("**Nᴏ ғɪʟᴇs ʀᴇᴄᴇɪᴠᴇᴅ ɪɴ ᴛʜɪs sᴇǫᴜᴇɴᴄᴇ!**")

    # Track sorted files count for leaderboard
    await db.add_sorted_history(user_id, len(file_list))
    
    # Log this sequence for time-filtered leaderboard
    # In the end_sequence function, fix the logging:
    await db.sequence_logs.insert_one({
        "user_id": user_id,
        "file_count": len(file_list),
        "timestamp": datetime.now()  # Use datetime.datetime.now()
    })
    # get sorting pref (normalize to lowercase)
    sorting_mode = (await db.get_sorting_mode(user_id) or "season").strip().lower()

    # ---------- helpers ----------
    def _get_filename(item):
        """Extract a filename string from different item shapes (dicts, objects, raw strings)."""
        if isinstance(item, dict):
            for k in ("file_name", "file", "name", "file_path", "filename"):
                if k in item and item[k]:
                    return str(item[k])
            # fallback to str
            return str(item)
        # object with attribute
        if hasattr(item, "file_name"):
            return str(getattr(item, "file_name"))
        if hasattr(item, "name"):
            return str(getattr(item, "name"))
        return str(item)

    QUALITY_RANK = {
        "2160p": 8, "4k": 8,
        "1440p": 7, "2k": 7,
        "1080p": 6, "fhd": 6,
        "720p": 5, "hd": 5,
        "480p": 4, "sd": 4,
        "360p": 3, "240p": 2, "144p": 1
    }

    def _normalize_text(s: str) -> str:
        s = unicodedata.normalize("NFKD", s)
        s = re.sub(r'\s+', ' ', s).strip()
        return s.lower()

    def detect_quality_from_token(token: str):
        """Enhanced quality detection for anime/manga"""
        t = token.lower()
        
        # Anime-specific quality patterns
        quality_patterns = [
            (r'2160p|\b4k\b', '2160p'),
            (r'1440p|\b2k\b', '1440p'), 
            (r'1080p|\bfhd\b', '1080p'),
            (r'720p|\bhd\b', '720p'),
            (r'480p|\bsd\b', '480p'),
            (r'360p', '360p'),
            (r'240p', '240p'),
            (r'144p', '144p'),
            (r'(\d{3,4})p', None),
            
            # Manga quality indicators
            (r'\b(?:high|good|excellent)\s*quality\b', 'High Quality'),
            (r'\b(?:web|digital)\s*(?:dl|download)\b', 'Digital'),
            (r'\bscanlation\b', 'Scanlation'),
            (r'\bvolume\b', 'Volume'),
            (r'\b(colored|color|colour)\b', 'Colored'),
            (r'\b(bw|black.white|monochrome)\b', 'B&W'),
        ]
        
        for pat, lab in quality_patterns:
            m = re.search(pat, t)
            if m:
                return lab if lab else f"{m.group(1)}p"
        
        return None

    # Update the parse_filename function to use this new method
    def parse_filename(filename: str):
        """
        Enhanced parser using clean title extraction
        """
        raw = filename or ""
        
        # Extract all components first
        season, episode = extract_season_episode(raw)
        chapter = extract_chapter(raw)
        volume = extract_volume(raw)
        quality = extract_quality(raw)
        
        
        # Quality ranking
        QUALITY_RANK = {
            "2160p": 8, "4k": 8,
            "1440p": 7, "2k": 7,
            "1080p": 6, "fhd": 6,
            "720p": 5, "hd": 5,
            "480p": 4, "sd": 4,
            "360p": 3, "240p": 2, "144p": 1
        }
        q_rank = QUALITY_RANK.get((quality or "").lower(), 0)
        
        # Determine if it's manga or anime
        is_manga = chapter is not None
        is_anime = episode is not None and chapter is None
        
        return {
            "raw": raw,
            "title": title,
            "title_norm": title_norm,
            "season": int(season) if season is not None else 0,
            "episode": int(episode) if episode is not None else 0,
            "chapter": float(chapter) if chapter is not None else 0.0,
            "volume": int(volume) if volume is not None else 0,
            "quality": quality or "",
            "quality_rank": q_rank,
            "group": "",  # Group extraction can be added separately
            "is_manga": is_manga,
            "is_anime": is_anime
        }
        # ==================== ENHANCED PATTERNS FOR ANIME/MANGA ====================
        
        # Anime/Manga specific patterns - EXPANDED
        anime_manga_patterns = [
            # Episode patterns (anime)
            r'(?i)\b(?:EP|Ep|ep|Episode|episode)\s*(\d{1,3})\b',
            r'(?i)\bE\s*(\d{1,3})\b',
            r'(?i)\b-\s*(\d{1,3})(?:\s|v|\]|$)',
            
            # Chapter patterns (manga) - EXPANDED
            # Chapter patterns (manga) - UPDATED FOR DECIMALS
            r'(?i)\b(?:CH|Ch|ch|Chapter|chapter)\s*[\.\-_\s]?(\d{1,4}(?:\.\d+)?)\b',
            r'(?i)\bC\s*(\d{1,4}(?:\.\d+)?)\b',
            r'(?i)\bCh\.\s*(\d{1,4}(?:\.\d+)?)\b',
            r'(?i)\bCh\s*[\.\-_\s]?\s*(\d{1,4}(?:\.\d+)?)\b',
            r'(?i)\[Ch[\.\-_\s]?(\d{1,4}(?:\.\d+)?)\]',
            # Combined season+episode
            r'(?i)\bS(\d{1,2})\s*[\.\-_\s]?\s*E(\d{1,3})\b',
            r'(?i)\bSeason\s*(\d{1,2})\s*[\.\-_\s]?\s*Episode\s*(\d{1,3})\b',
            r'(?i)\b(\d{1,2})x(\d{1,3})\b',
            
            # Volume patterns
            r'(?i)\b(?:Vol|Volume|VOL)\s*[\.\-_]?\s*(\d{1,2})\b',
            r'(?i)\bV\s*[\.\-_]?\s*(\d{1,2})\b',
            
            # Standalone numbers (will be classified later)
            # Standalone numbers (will be classified later) - UPDATED FOR DECIMALS
            r'(?i)(?:^|\s|\]|\[)(\d{1,4}(?:\.\d+)?)(?:\s|$|\[|\]|v)',
        ]

        # Check tokens first (higher confidence)
        for t in tokens:
            # Season+Episode
            if not season and not episode:
                season_ep_match = re.search(r'(?i)S(\d{1,2})[\.\-_\s]?E?(\d{1,3})', t)
                if season_ep_match:
                    try:
                        season = int(season_ep_match.group(1))
                        episode = int(season_ep_match.group(2))
                        continue
                    except:
                        pass

            # Chapter patterns in brackets (like [Ch-57])
            if not chapter:
                # Handle "Ch-57" pattern
                ch_hyphen_match = re.search(r'(?i)ch[\.\-_\s]?(\d{1,4})', t)
                if ch_hyphen_match:
                    try:
                        chapter = float(ch_hyphen_match.group(1))
                        continue
                    except:
                        pass
                
                # Handle other chapter patterns
                ch_match = re.search(r'(?i)(?:CH|Chapter)\s*(\d{1,4}(?:\.\d+)?)', t)
                if ch_match:
                    try:
                        chapter = float(ch_match.group(1))
                        continue
                    except:
                        pass

            # Episode only in brackets
            if not episode:
                ep_match = re.search(r'(?i)(?:EP|Episode)\s*(\d{1,3})', t)
                if ep_match:
                    try:
                        episode = int(ep_match.group(1))
                        if not season:
                            season = 1
                        continue
                    except:
                        pass

            # Volume
            if not volume:
                vol_match = re.search(r'(?i)(?:Vol|Volume)\s*(\d{1,2})', t)
                if vol_match:
                    try:
                        volume = int(vol_match.group(1))
                        continue
                    except:
                        pass

            # Standalone numbers in brackets (common in manga)
          #  if not chapter and not episode:
            # Standalone numbers in brackets (common in manga) - UPDATED FOR DECIMALS
            if not chapter and not episode:
                standalone_match = re.search(r'^\s*(\d{1,4}(?:\.\d+)?)\s*$', t)
                if standalone_match:
                    try:
                        num_val = standalone_match.group(1)
                        # This will now properly handle decimal values like "2.4"
                        chapter = float(num_val)
                        continue
                    except:
                        pass

        # If not found in tokens, search in base filename
        if not episode and not chapter:
            for pattern in anime_manga_patterns:
                match = re.search(pattern, base)
                if match:
                    try:
                        groups = match.groups()
                        
                        # Episode patterns
                        if 'ep' in pattern.lower() or 'e\s*\d' in pattern.lower():
                            episode = int(groups[0])
                            if not season:
                                season = 1
                            break
                        # Chapter patterns  
                        elif 'ch' in pattern.lower():
                            chapter = float(groups[0])
                            break
                        # Volume patterns
                        elif 'vol' in pattern.lower():
                            volume = int(groups[0])
                            break
                        # Standalone numbers - need classification
                        elif len(groups) == 1 and groups[0].isdigit():
                            num_val = groups[0]
                            num_int = int(num_val)
                            
                            # Classification logic for standalone numbers
                            if _is_likely_manga(base, num_int):
                                chapter = float(num_int)
                            else:
                                episode = num_int
                                if not season:
                                    season = 1
                            break
                    except:
                        continue

        # Special handling for pure number filenames
        if not episode and not chapter:
            # Pattern for filenames that are just numbers
            pure_number_match = re.search(r'^\s*(\d{1,4}(?:\.\d+)?)\s*$', base)
            if pure_number_match:
                try:
                    num_val = pure_number_match.group(1)
                    num_int = int(float(num_val)) if '.' in num_val else int(num_val)
                    
                    if _is_likely_manga(base, num_int):
                        chapter = float(num_val)
                    else:
                        episode = num_int
                        if not season:
                            season = 1
                except:
                    pass

        # Final fallback - extract any number from filename
        if not episode and not chapter:
            any_number_match = re.search(r'(\d{1,4}(?:\.\d+)?)', base)
            if any_number_match:
                try:
                    num_val = any_number_match.group(1)
                    num_int = int(float(num_val)) if '.' in num_val else int(num_val)
                    
                    if _is_likely_manga(base, num_int):
                        chapter = float(num_val)
                    else:
                        episode = num_int
                        if not season:
                            season = 1
                except:
                    pass

        # Quality detection
        for t in tokens:
            q = detect_quality_from_token(t)
            if q:
                quality = q
                break
        if not quality:
            q = detect_quality_from_token(base)
            if q:
                quality = q

        # Group detection - improved
        for t in bracket_tokens:
            # Look for group indicators
            if re.search(r'@|team|group|fansub|subs|scanlation|manga2u', t, flags=re.I):
                group = t
                break
        
        # If no group found but we have tokens, use the first non-metadata token
        if not group and bracket_tokens:
            for t in bracket_tokens:
                # Skip if it's clearly metadata
                if re.search(r'\b(?:s\d+e\d+|\d{3,4}p|4k|x264|x265|hevc|multi|dub|sub|bdrip|bluray|web[- ]?rip|ch[\.\-]?\d+|ep?\d+)\b', t, flags=re.I):
                    continue
                # Skip if it's just a number
                if re.search(r'^\s*\d+\s*$', t):
                    continue
                group = t
                break

        # Title extraction with anime/manga awareness
        title_candidate = None
        
        # Remove common anime/manga tags for title extraction
        cleaned_base = base
        
        # First, try to extract title from brackets (common in anime/manga)
        title_bracket_match = re.search(r'\[([^\]\d]+)\]', base)
        if title_bracket_match:
            potential_title = title_bracket_match.group(1).strip()
            # Check if it looks like a title (not a group, not metadata)
            if (len(potential_title) > 2 and 
                not re.search(r'@|team|group|fansub', potential_title, re.I) and
                not re.search(r'\d{3,4}p|4k|x264', potential_title, re.I)):
                title_candidate = potential_title
        
        if not title_candidate:
            clean_patterns = [
                r'\[.*?\]', r'\(.*?\)',  # Remove brackets/parens
                r'\b(?:S\d+\s*E\d+|\d+x\d+)\b',  # Remove S01E01 patterns
                r'\b(?:EP?\s*\d+|Episode\s*\d+)\b',  # Remove Episode patterns
                r'\b(?:CH?[\.\-]?\s*\d+|Chapter\s*\d+)\b',  # Remove Chapter patterns (including Ch-57)
                r'\b(?:Vol\.?\s*\d+|Volume\s*\d+)\b',  # Remove Volume patterns
                r'\b\d{3,4}p\b', r'\b4k\b', r'\b1080p\b', r'\b720p\b',  # Remove quality
                r'\b(?:x264|x265|hevc|avc)\b',  # Remove codecs
                r'\b(?:sub|dub|dual)\b',  # Remove audio tags
            ]
            
            for pattern in clean_patterns:
                cleaned_base = re.sub(pattern, '', cleaned_base, flags=re.IGNORECASE)
            
            # Clean up extra spaces and separators
            cleaned_base = re.sub(r'[._\-]+', ' ', cleaned_base)
            cleaned_base = re.sub(r'\s+', ' ', cleaned_base).strip()
            
            # Find title in remaining text
            if cleaned_base:
                title_candidate = cleaned_base
        
        # Final fallback
        if not title_candidate:
            title_candidate = os.path.splitext(os.path.basename(raw))[0]

        title = title_candidate.strip(" -._")
        title_norm = _normalize_text(title)

        q_rank = QUALITY_RANK.get((quality or "").lower(), 0)

        return {
            "raw": raw,
            "title": title,
            "title_norm": title_norm,
            "season": int(season) if season is not None else 0,
            "episode": int(episode) if episode is not None else 0,
            "chapter": float(chapter) if chapter is not None else 0.0,
            "volume": int(volume) if volume is not None else 0,
            "quality": quality or "",
            "quality_rank": q_rank,
            "group": group or "",
            "is_manga": chapter is not None,  # Flag to identify manga
            "is_anime": episode is not None and chapter is None  # Flag to identify anime
        }


    def _is_likely_manga(filename: str, number: int) -> bool:
        """
        Helper function to determine if a standalone number is likely a chapter or episode
        """
        filename_lower = filename.lower()
        
        # Manga indicators
        manga_indicators = [
            'chapter', 'ch.', 'ch', 'ch-', 'vol', 'volume', 
            'manga', 'comic', 'oneshot', 'one-shot', 'scanlation',
            'gb', 'graphic novel', 'panel', 'page'
        ]
        
        # Anime indicators  
        anime_indicators = [
            'episode', 'ep.', 'ep', 'season', 's01', 's02',
            'anime', 'batch', 'cour', 'ova', 'movie', 'special',
            'opening', 'ending', 'preview', 'trailer'
        ]
        
        manga_score = sum(1 for indicator in manga_indicators if indicator in filename_lower)
        anime_score = sum(1 for indicator in anime_indicators if indicator in filename_lower)
        
        # File extension hints
        file_ext = os.path.splitext(filename)[1].lower()
        if file_ext in ['.pdf', '.cbz', '.cbr', '.epub', '.mobi']:
            manga_score += 2
        elif file_ext in ['.mp4', '.mkv', '.avi', '.mov', '.wmv']:
            anime_score += 2
        
        # Number range hints (chapters are often higher numbers)
        if number > 100:
            manga_score += 1
        elif number < 50:
            anime_score += 1
        
        return manga_score > anime_score
    # ---------- parse all files ----------
    parsed = []
    for item in file_list:
        fname = _get_filename(item)
        meta = parse_filename(fname)
        meta["orig_item"] = item
        parsed.append(meta)


    mode = sorting_mode.lower()

    if mode == "quality":
        # Highest quality first, then season, episode/chapter
        keyfunc = lambda m: (
            -m["quality_rank"], 
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            m["title_norm"]
        )
    elif mode == "title":
        # Title first, then season, episode/chapter, quality
        keyfunc = lambda m: (
            m["title_norm"], 
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"]
        )
    elif mode == "both":
        # Title, quality, then episode/chapter
        keyfunc = lambda m: (
            m["title_norm"], 
            -m["quality_rank"],
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"]
        )
    elif mode == "episode":
        # Episode/chapter ascending (season ignored)
        keyfunc = lambda m: (
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"], 
            m["title_norm"]
        )
    elif mode == "season":
        # Season -> episode/chapter -> best quality
        keyfunc = lambda m: (
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"], 
            m["title_norm"]
        )
    else:
        # Default: season -> episode/chapter -> best quality
        keyfunc = lambda m: (
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"], 
            m["title_norm"]
        )
    sorted_parsed = sorted(parsed, key=keyfunc)

    # Build sorted list of original items to send
    # Build sorted list of original items to send
    # Build sorted list of original items to send
    sorted_files = [m["orig_item"] for m in sorted_parsed]
    sort_count = len(sorted_files)
    
    # Update the sorting operation counts
    await db.increment_sort_count(user_id)
    await db.increment_files_processed_count(user_id, sort_count)
    await db.add_sort_log_entry(user_id, sort_count)
    
    # Update individual file counts for each file in the sequence
    for file_info in sorted_files:
        if "file_id" in file_info and "file_name" in file_info:
            await db.increment_rename_count(user_id)
            await db.add_rename_log_entry(
                user_id,
                original_name=file_info["file_name"],
                renamed_name=file_info["file_name"],  # Files in sequence keep original names
                file_size=0  # File size not available in sequence context
            )
            await db.add_rename_history(user_id, file_info["file_name"], file_info["file_name"])
    
    # Optional: debug log parsed results
    try:
        logging.debug("Sequence sorted for user %s in mode %s", user_id, sorting_mode)
        for m in sorted_parsed:
            logging.debug("Parsed: %s", m)
    except Exception:
        pass
    
    # Inform user and proceed with sending
    await message.reply_text(
        f"**Sᴇǫᴜᴇɴᴄᴇ ᴄᴏᴍᴘʟᴇᴛᴇᴅ!**\n**Sᴇɴᴅɪɴɢ {len(sorted_files)} ғɪʟᴇs ɪɴ {sorting_mode.capitalize()} ᴏʀᴅᴇʀ...**"
    )
    # Continue with your existing sending logic using sorted_files...
    # (Make sure the rest of your pipeline reads from `sorted_files` instead of old `file_list`.)

    sent_files = set()
    try:
        for index, file in enumerate(sorted_files):
            try:
                if file["file_id"] in sent_files:
                    continue  # Skip if already sent

                sent_msg = await client.send_document(
                    message.chat.id,
                    file["file_id"],
                    caption=f"**{file['file_name']}**",
                    parse_mode=ParseMode.MARKDOWN
                )
                sent_files.add(file["file_id"])

                if hasattr(Config, 'DUMP') and Config.DUMP and hasattr(Config, 'DUMP_CHANNEL'):
                    try:
                        user = message.from_user
                        ist = pytz.timezone('Asia/Kolkata')
                        current_time = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S IST")

                        full_name = user.first_name
                        if user.last_name:
                            full_name += f" {user.last_name}"
                        username = f"@{user.username}" if user.username else "N/A"

                        user_data = await db.col.find_one({"_id": user_id})
                        is_premium = user_data.get("is_premium", False) if user_data else False
                        premium_status = '🗸' if is_premium else '✘'

                        dump_caption = (
                            f"**» Usᴇʀ Dᴇᴛᴀɪʟs «\n**"
                            f"**ID: {user_id}\n**"
                            f"**Nᴀᴍᴇ: {full_name}\n**"
                            f"**Usᴇʀɴᴀᴍᴇ: {username}\n**"
                            f"**Pʀᴇᴍɪᴜᴍ: {premium_status}\n**"
                            f"**Tɪᴍᴇ: {current_time}\n**"
                            f"**Fɪʟᴇɴᴀᴍᴇ: {file['file_name']}**"
                        )

                        await client.send_document(
                            Config.DUMP_CHANNEL,
                            file["file_id"],
                            caption=dump_caption
                        )
                    except Exception as e:
                        logger.error(f"Dump failed for sequence file: {e}")

                if index < len(sorted_files) - 1:
                    await asyncio.sleep(0.5)

            except FloodWait as e:
                await asyncio.sleep(e.value + 1)
            except Exception as e:
                logger.error(f"Error sending file {file['file_name']}: {e}")

        if delete_messages:
            await client.delete_messages(message.chat.id, delete_messages)

    except Exception as e:
        logger.error(f"Sequence processing failed: {e}")
        await message.reply_text(
            "**Fᴀɪʟᴇᴅ ᴛᴏ ᴘʀᴏᴄᴇss sᴇǫᴜᴇɴᴄᴇ! Cʜᴇᴄᴋ ʟᴏɢs ғᴏʀ ᴅᴇᴛᴀɪʟs.**"
        )

@Client.on_message(filters.command("token_usage") & filters.private)
@check_ban_status
async def global_premium_control(client, message: Message):
    global PREMIUM_MODE, PREMIUM_MODE_EXPIRY

    user_id = message.from_user.id
    if user_id not in ADMINS:
        return await message.reply_text("**Tʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ʀᴇsᴛʀɪᴄᴛᴇᴅ ᴛᴏ ᴀᴅᴍɪɴs ᴏɴʟʏ!!!**")

    args = message.command[1:]
    if not args:
        status = "ON" if PREMIUM_MODE else "OFF"
        expiry = f" (expires {PREMIUM_MODE_EXPIRY:%Y-%m-%d %H:%M})" if PREMIUM_MODE_EXPIRY else ""
        return await message.reply_text(
            f"**➠ Cᴜʀʀᴇɴᴛ Tᴏᴋᴇɴ Usᴀɢᴇ: {status}{expiry}**\n\n"
            "**Usᴀɢᴇ:**\n"
            "`/token_usage on [days|12m|1y]`  — Eɴᴀʙʟᴇ ᴛᴏᴋᴇɴ ᴜsᴀɢᴇ\n"
            "`/token_usage off [days|12m|1y]` — Dɪsᴀʙʟᴇ ᴛᴏᴋᴇɴ ᴜsᴀɢᴇ"
        )

    action = args[0].lower()
    if action not in ("on", "off"):
        return await message.reply_text("**Iɴᴠᴀʟɪᴅ ᴀᴄᴛɪᴏɴ! Usᴇ `on` ᴏʀ `off`**")

    days = None
    if len(args) > 1:
        days = parse_duration(args[1])
        if days is None:
            return await message.reply_text("**Iɴᴠᴀʟɪᴅ ᴅᴜʟᴀᴛɪᴏɴ! Usᴇ 12m, 1y, 30d, 7day, etc.**")

    if action == "on":
        PREMIUM_MODE = True
        PREMIUM_MODE_EXPIRY = datetime.now() + timedelta(days=days) if days else None
        msg = f"**Tᴏᴋᴇɴ ᴜsᴀɢᴇ ʜᴀs ʙᴇᴇɴ ᴇɴᴀʙʟᴇᴅ{f' ғᴏʀ {days} ᴅᴀʏs' if days else ''}**"
    else:
        PREMIUM_MODE = False
        PREMIUM_MODE_EXPIRY = datetime.now() + timedelta(days=days) if days else None
        msg = f"**Tᴏᴋᴇɴ ᴜsᴀɢᴇ ʜᴀs ʙᴇᴇɴ ᴅɪsᴀʙʟᴇᴅ{f' ғᴏʀ {days} ᴅᴀʏs' if days else ''}**"

    await db.global_settings.update_one(
        {"_id": "premium_mode"},
        {"$set": {"status": PREMIUM_MODE, "expiry": PREMIUM_MODE_EXPIRY}},
        upsert=True
    )
    await message.reply_text(msg)

async def check_premium_mode():
    global PREMIUM_MODE, PREMIUM_MODE_EXPIRY

    settings = await db.global_settings.find_one({"_id": "premium_mode"})
    if not settings:
        return

    PREMIUM_MODE        = settings.get("status", True)
    PREMIUM_MODE_EXPIRY = settings.get("expiry", None)

    if PREMIUM_MODE_EXPIRY and datetime.now() > PREMIUM_MODE_EXPIRY:
        PREMIUM_MODE = True
        await db.global_settings.update_one(
            {"_id": "premium_mode"},
            {"$set": {"status": PREMIUM_MODE}}
        )

SEASON_EPISODE_PATTERNS = [
    (re.compile(r'\[S(\d{1,2})[\s\-]+E(\d{1,3})\]', re.IGNORECASE), ('season', 'episode')),   # [S01-E06]
    (re.compile(r'\[S(\d{1,2})[\s\-]+(\d{1,3})\]', re.IGNORECASE), ('season', 'episode')),     # [S01-06]
    (re.compile(r'\[S(\d{1,2})\s+E(\d{1,3})\]', re.IGNORECASE), ('season', 'episode')),        # [S01 E06]
    (re.compile(r'\[S\s*(\d{1,2})\s*E\s*(\d{1,3})\]', re.IGNORECASE), ('season', 'episode')), # [S 1 E 1]
    (re.compile(r'S(\d{1,2})[\s\-]+E(\d{1,3})', re.IGNORECASE), ('season', 'episode')),        # S01-E06, S01 E06
    (re.compile(r'S(\d{1,2})[\s\-]+(\d{1,3})', re.IGNORECASE), ('season', 'episode')),         # S01-06, S01 06
    (re.compile(r'S(\d+)(?:E|EP)(\d+)'), ('season', 'episode')),
    (re.compile(r'S(\d+)[\s-]*(?:E|EP)(\d+)'), ('season', 'episode')),
    (re.compile(r'Season\s*(\d+)\s*Episode\s*(\d+)', re.IGNORECASE), ('season', 'episode')),
    (re.compile(r'\[S(\d+)\]\[E(\d+)\]'), ('season', 'episode')),
    (re.compile(r'S(\d+)[^\d]+(\d{1,3})\b'), ('season', 'episode')),
    (re.compile(r'(?:E|EP|Episode)\s*(\d+)', re.IGNORECASE), (None, 'episode')),
    (re.compile(r'\b(\d{1,3})\b'), (None, 'episode'))
]


QUALITY_PATTERNS = [
    (re.compile(r'\[(\d{3,4}p)\](?:\s*\[\1\])*', re.IGNORECASE), lambda m: m.group(1)),
    (re.compile(r'\b(\d{3,4})p?\b'), lambda m: f"{m.group(1)}p"),
    (re.compile(r'\b(4k|2160p)\b', re.IGNORECASE), lambda m: "2160p"),
    (re.compile(r'\b(2k|1440p)\b', re.IGNORECASE), lambda m: "1440p"),
    (re.compile(r'\b(\d{3,4}[pi])\b', re.IGNORECASE), lambda m: m.group(1)),
    (re.compile(r'\b(HDRip|HDTV)\b', re.IGNORECASE), lambda m: m.group(1)),
    (re.compile(r'\[(\d{3,4}[pi])\]', re.IGNORECASE), lambda m: m.group(1)),
    (re.compile(r'\b(4kX264|4kx265)\b', re.IGNORECASE), lambda m: m.group(1)),
    (re.compile(r'\b(?:.*?(\d{3,4}[^\dp]*p).*?|.*?(\d{3,4}p))\b', re.IGNORECASE), lambda m: m.group(1) or m.group(2)),
    (re.compile(r'[([<{]?\s*4k\s*[)\]>}]?', re.IGNORECASE), lambda _: "4k"),
    (re.compile(r'[([<{]?\s*2k\s*[)\]>}]?', re.IGNORECASE), lambda _: "2k"),
    (re.compile(r'[([<{]?\s*HdRip\s*[)\]>}]?|\bHdRip\b', re.IGNORECASE), lambda _: "HdRip"),
    (re.compile(r'[([<{]?\s*4kX264\s*[)\]>}]?', re.IGNORECASE), lambda _: "4kX264"),
    (re.compile(r'[([<{]?\s*4kx265\s*[)\]>}]?', re.IGNORECASE), lambda _: "4kx265"),
    (re.compile(r'[([<{]?\s*UHD\s*[)\]>}]?', re.IGNORECASE), lambda _: "UHD"),
    (re.compile(r'[([<{]?\s*HD\s*[)\]>}]?', re.IGNORECASE), lambda _: "HD"),
    (re.compile(r'[([<{]?\s*SD\s*[)\]>}]?', re.IGNORECASE), lambda _: "SD"),
    (re.compile(r'[([<{]?\s*converted\s*[)\]>}]?', re.IGNORECASE), lambda _: "converted"),
    (re.compile(r'\b(bdrip|brrip|dvdrip|webrip|webdl|hdtv|pdtv)\b', re.IGNORECASE), lambda m: m.group(1)),
    (re.compile(r'\b(264|265|avc|hevc|x264|x265)\b', re.IGNORECASE), lambda m: m.group(1)),
    (re.compile(r'\b(multi|dual|dub|sub)\b', re.IGNORECASE), lambda m: m.group(1)),
]
AUDIO_PATTERNS = [
    (re.compile(r'\bmulti(\s*audio)?\b', re.IGNORECASE), "Multi"),
    (re.compile(r'\bdual(\s*audio)?\b', re.IGNORECASE), "Dual"),
    (re.compile(r'\beng\s*[,/|]\s*jap\b', re.IGNORECASE), "Dual"),
    (re.compile(r'\bjap\s*[,/|]\s*eng\b', re.IGNORECASE), "Dual"),

    (re.compile(r'\bdub(bed)?\b', re.IGNORECASE), "Dub"),
    (re.compile(r'\beng(lish)?\b', re.IGNORECASE), "Dub"),
    (re.compile(r'\b(hin|ind|tel|tam|mal|kan)\b', re.IGNORECASE), "Dub"),  # Indian languages → Dub

    (re.compile(r'\bsub(bed)?\b', re.IGNORECASE), "Sub"),
    (re.compile(r'\bjap(anese)?\b', re.IGNORECASE), "Sub"),
    (re.compile(r'\bjp\b', re.IGNORECASE), "Sub"),

    # Bracket variations
    (re.compile(r'\[(multi|dual|dub|sub)\]', re.IGNORECASE), lambda m: m.group(1).title()),
    (re.compile(r'\((multi|dual|dub|sub)\)', re.IGNORECASE), lambda m: m.group(1).title()),
]
def extract_audio(filename):
    """Extract audio type using AUDIO_PATTERNS (simple + reliable)."""
    if not filename:
        return "Sub"
    
    for pattern, label in AUDIO_PATTERNS:
        match = pattern.search(filename)
        if match:
            return label(match) if callable(label) else label
    
    return "Sub"

def extract_season_episode(filename):
    if not filename:
        return "01", None
        
    # Remove only (parentheses), not [brackets]
    filename = re.sub(r'\(.*?\)', ' ', filename)
    
    for pattern, (season_group, episode_group) in SEASON_EPISODE_PATTERNS:
        match = pattern.search(filename)
        if match:
            season = episode = None
            if season_group:
                season = match.group(1).zfill(2) if match.group(1) else "01"
            if episode_group:
                episode = match.group(2 if season_group else 1).zfill(2)
            
            logger.info(f"Extracted season: {season}, episode: {episode} from {filename}")
            return season or "01", episode
    
    logger.warning(f"No season/episode pattern matched for {filename}")
    return "01", None

def extract_quality(filename):
    """
    Extract only resolution/quality indicators, ignore codec/container labels like 264, bdrip, webrip.
    """
    if not filename:
        return "Unknown"
    
    seen = set()
    quality_parts = []

    for pattern, extractor in QUALITY_PATTERNS:
        match = pattern.search(filename)
        if match:
            quality = extractor(match).lower()

            # Ignore unwanted codec/container info
            if quality in {"264", "265", "x264", "x265", "avc", "hevc", "bdrip", "brrip", "dvdrip", "webrip", "webdl", "hdtv", "pdtv"}:
                continue

            if quality not in seen:
                quality_parts.append(quality)
                seen.add(quality)
                # Remove only matched part once
                filename = filename.replace(match.group(0), '', 1)

    return " ".join(quality_parts) if quality_parts else "Unknown"
# Also update the remove_duplicate_tags_from_filename to handle format tags

def remove_duplicate_tags_from_filename(filename):
    """Remove duplicate audio/quality/format tags from original filename before processing"""
    if not filename:
        return filename
    
    print(f"🧹 Cleaning original filename: '{filename}'")
    
    # Remove duplicate audio tags in brackets
    audio_patterns = [
        # Sub
        (r'\[480p\s*(?:264\s*)?(?:bdrip\s*)?sub\]', '[480p] [Sub]'),
        (r'\[720p\s*(?:264\s*)?(?:bdrip\s*)?sub\]', '[720p] [Sub]'),
        (r'\[1080p\s*(?:264\s*)?(?:bdrip\s*)?sub\]', '[1080p] [Sub]'),
        (r'\[sub\]', '[Sub]'),

        # Multi
        (r'\[480p\s*(?:264\s*)?(?:bdrip\s*)?multi\]', '[480p] [Multi]'),
        (r'\[720p\s*(?:264\s*)?(?:bdrip\s*)?multi\]', '[720p] [Multi]'),
        (r'\[1080p\s*(?:264\s*)?(?:bdrip\s*)?multi\]', '[1080p] [Multi]'),
        (r'\[multi\]', '[Multi]'),

        # Dual
        (r'\[480p\s*(?:264\s*)?(?:bdrip\s*)?dual\]', '[480p] [Dual]'),
        (r'\[720p\s*(?:264\s*)?(?:bdrip\s*)?dual\]', '[720p] [Dual]'),
        (r'\[1080p\s*(?:264\s*)?(?:bdrip\s*)?dual\]', '[1080p] [Dual]'),
        (r'\[dual\]', '[Dual]'),
    ]

    
    clean_name = filename
    for pattern, replacement in audio_patterns:
        clean_name = re.sub(pattern, replacement, clean_name, flags=re.IGNORECASE)
    
    # Remove standalone format tags
    format_tags = [
        r'\bBDRip\b', r'\bBDrip\b', r'\bBluRay\b', r'\bWEBRip\b', 
        r'\bWebRip\b', r'\bWEB-DL\b', r'\bHDTV\b', r'\bDVDRip\b'
    ]
    
    for pattern in format_tags:
        clean_name = re.sub(pattern, '', clean_name, flags=re.IGNORECASE)
    
    # Remove duplicate quality tags
    quality_duplicates = [
        (r'\[480p\]\s*\[480p\]', '[480p]'),
        (r'\[720p\]\s*\[720p\]', '[720p]'),
        (r'\[1080p\]\s*\[1080p\]', '[1080p]'),
    ]
    
    for pattern, replacement in quality_duplicates:
        clean_name = re.sub(pattern, replacement, clean_name, flags=re.IGNORECASE)
    
    # Clean up extra spaces
    clean_name = re.sub(r'\s+', ' ', clean_name).strip()
    
    if clean_name != filename:
        print(f"🧹 Cleaned to: '{clean_name}'")
    
    return clean_name
def extract_clean_title(filename, max_length=30):
    """
    Smart title extraction that preserves the actual anime/manga title
    """
    if not filename:
        return "Unknown Title"
    
    print(f"🔄 ORIGINAL: {filename}")
    
    # Remove file extension FIRST
    base_name = os.path.splitext(filename)[0]
    
    # Common patterns to remove (in order of priority)
    patterns_to_remove = [
        # 1. Remove uploader tags first
        r'@\w+',

        r'S\d{1,2}[\s\-_]?E\d{1,3}',  # S01E17, S01-E17, S01_E17
        r'S\d{1,2}[\s\-_]?\d{1,3}',   # S0117, S01-17, S01_17
        r'Season[\s\-_]?\d{1,2}[\s\-_]?Episode[\s\-_]?\d{1,3}',  # Season 1 Episode 17
        r'Season[\s\-_]?\d{1,2}',     # Season 1, Season 01
        r'Episode[\s\-_]?\d{1,3}',    # Episode 17, Episode 017
        r'S\d{1,2}',                  # S01, S1
        r'E\d{1,3}',                  # E17, E017
        r'EP\d{1,3}',                 # EP17, EP017
        r'\b\d{1,2}x\d{1,3}\b',       # 1x17, 01x17
        r'\[\s*S\d{1,2}\s*[\-\s]?\s*E\d{1,3}\s*\]',  # [S01-E17], [S01 E17]
        r'\[\s*S\d{1,2}\s*\]',        # [S01]
        r'\[\s*E\d{1,3}\s*\]',        # [E17]
        # 2. Remove quality/resolution
        r'\b\d{3,4}p\b',
        r'\b4k\b',
        r'\b480p\b',
        r'\b720p\b', 
        r'\b1080p\b',
        r'\b2160p\b',
        
        # 3. Remove audio tags
        r'\bsub(bed)?\b',
        r'\bdub(bed)?\b',
        r'\bmulti\b',
        r'\bdual\b',
        r'\besub\b',
        r'\baudio\b',
        
        # 4. Remove season/episode patterns
        r'S\d+[Ee]\d+',
        r'S\d+\s*[\.\-_]\s*E\d+',
        r'Season\s*\d+',
        r'Episode\s*\d+',
        r'\b\d+x\d+\b',
        
        # 5. Remove standalone numbers (but keep them if part of title)
        r'\b\d{1,2}\b(?!\w)',  # Only remove if not followed by letter
        
        # 6. Remove codec info
        r'\b10bit\b',
        r'\b8bit\b',
        r'\bx264\b',
        r'\bx265\b',
        r'\bh264\b',
        r'\bh265\b',
        r'\bhevc\b',
        r'\bavc\b',
        r'\b264\b',
        r'\b265\b',
        
        # 7. Remove format tags
        r'\bbdrip\b',
        r'\bbluray\b',
        r'\bwebrip\b',
        r'\bwebdl\b',
        r'\bweb\-dl\b',
        r'\bhdtv\b',
        r'\bdvdrip\b',
        r'\bbrrip\b',
        r'\bhdrip\b',
        r'\bAv1\b',
    ]
    
    clean_title = base_name
    
    # Apply all removal patterns
    for pattern in patterns_to_remove:
        clean_title = re.sub(pattern, '', clean_title, flags=re.IGNORECASE)
    
    # Clean up separators and whitespace
    clean_title = re.sub(r'[._\-]+', ' ', clean_title)
    clean_title = re.sub(r'\s+', ' ', clean_title).strip()
    clean_title = re.sub(r'^\s*\d{1,2}[_\s-]+', '', clean_title)
    # Remove small trailing numbers at the end of the title, before brackets
    clean_title = re.sub(r'\s+\d{1,2}(?=\s*\[)', '', clean_title)
    # Remove small trailing numbers (like 01) that are not part of title
    clean_title = re.sub(r'\s+\d{1,2}(?=\s*\[)', '', clean_title)
    clean_title = re.sub(r'\b\d{1,3}\b', '', clean_title)

    print(f"📝 After basic cleaning: '{clean_title}'")
    
    # Remove bracket contents but be more careful
    clean_title = re.sub(r'\[.*?\]', '', clean_title)
    clean_title = re.sub(r'\(.*?\)', '', clean_title)
    clean_title = re.sub(r'\s+', ' ', clean_title).strip()
    
    print(f"📝 After bracket removal: '{clean_title}'")
    
    # Final cleanup - only remove obvious metadata, preserve title words
    final_words = []
    words = clean_title.split()
    
    for word in words:
        word_lower = word.lower()
        # Only remove obvious metadata, preserve small words that are part of titles
        if (word_lower not in ['480p', '720p', '1080p', '4k', 'sub', 'dub', 'multi', 'dual', 'audio', 'video', 
                              'bdrip', 'bluray', 'webrip', 'hdtv', 'dvdrip', 'esub', 'x264', 'x265', 'hevc'] and
            not (word.isdigit() and len(word) <= 2) and  # Keep numbers that might be part of title
            len(word) > 0):
            final_words.append(word)
    
    clean_title = ' '.join(final_words)
    print(f"📝 After final filtering: '{clean_title}'")
    
    # Final cleanup
    clean_title = re.sub(r'\s+', ' ', clean_title).strip()
    
    # If we have a reasonable title, process it
    if len(clean_title) >= 3:
        final_title = smart_title_case(clean_title)
        
        # Truncate if longer than max_length
        if len(final_title) > max_length:
            final_title = final_title[:max_length].rstrip()
            if final_title and not final_title.endswith(' '):
                last_space = final_title.rfind(' ')
                if last_space > 0:
                    final_title = final_title[:last_space].rstrip()
            final_title += '...' if len(final_title) < len(clean_title) else ''
        
        print(f"✅ FINAL CLEAN TITLE: '{final_title}' (Length: {len(final_title)})")
        print("=" * 60)
        return final_title
    
    # Fallback: Try to extract from original filename using different strategy
    return extract_title_fallback(base_name, max_length)

def extract_title_fallback(filename, max_length=45):
    """Fallback title extraction when main method fails"""
    print("🔄 Using fallback extraction...")
    
    # Look for title patterns in the original filename
    title_patterns = [
        # Look for words in ALL CAPS (common in anime titles)
        r'([A-Z]{2,}(?:\s+[A-Z]{2,})+)',
        # Look for Title Case phrases
        r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
        # Look for common anime title structures
        r'([A-Za-z]+\s+[A-Za-z]+\s+[A-Za-z]+)',
    ]
    
    for pattern in title_patterns:
        match = re.search(pattern, filename)
        if match:
            title = match.group(1).strip()
            print(f"🎯 Fallback found: '{title}'")
            
            # Apply truncation
            if len(title) > max_length:
                title = title[:max_length].rstrip()
                if title and not title.endswith(' '):
                    last_space = title.rfind(' ')
                    if last_space > 0:
                        title = title[:last_space].rstrip()
                title += '...' if len(title) < len(match.group(1)) else ''
            
            return smart_title_case(title)
    
    # Last resort: remove all non-alphanumeric and hope something remains
    simple_clean = re.sub(r'[^a-zA-Z\s]', ' ', filename)
    simple_clean = re.sub(r'\s+', ' ', simple_clean).strip()
    words = simple_clean.split()
    
    # Keep only words that look like title words (not metadata)
    metadata_words = {'season', 'episode', 'sub', 'dub', 'multi', 'dual', '480p', '720p', '1080p'}
    title_words = []
    
    for word in words:
        word_lower = word.lower()
        if (len(word) > 2 and 
            not word.isdigit() and 
            word_lower not in metadata_words):
            title_words.append(word)
    
    if title_words:
        final = ' '.join(title_words[:8])  # Limit to 8 words max
        
        # Apply truncation
        if len(final) > max_length:
            final = final[:max_length].rstrip()
            if final and not final.endswith(' '):
                last_space = final.rfind(' ')
                if last_space > 0:
                    final = final[:last_space].rstrip()
            final += '...' if len(final) < len(' '.join(title_words)) else ''
        
        print(f"🎯 Simple fallback: '{final}'")
        return smart_title_case(final)
    
    print("❌ All extraction methods failed")
    return "Unknown Title"

def smart_title_case(text):
    """Smart title casing that preserves acronyms and proper formatting"""
    if not text:
        return text
    
    # Words to keep in lowercase (unless they're the first word)
    lowercase_words = {
        'a', 'an', 'the', 'and', 'but', 'or', 'for', 'nor', 'on', 
        'at', 'to', 'from', 'by', 'of', 'in', 'as', 'da', 'de', 'del',
        'van', 'von', 'el', 'la', 'le'
    }
    
    words = text.split()
    result = []
    
    for i, word in enumerate(words):
        # Preserve ALL CAPS words (acronyms)
        if word.isupper() and len(word) > 1:
            result.append(word)
        # Preserve mixed case (already properly formatted)
        elif any(c.isupper() for c in word[1:]):
            result.append(word)
        # Keep common lowercase words in lowercase (except first word)
        elif word.lower() in lowercase_words and i > 0:
            result.append(word.lower())
        else:
            # Title case for normal words
            result.append(word.capitalize())
    
    final = ' '.join(result)
    
    # Ensure first character is uppercase
    if final and final[0].islower():
        final = final[0].upper() + final[1:]
    
    return final

def extract_title_fallback(filename):
    """Fallback title extraction when main method fails"""
    print("🔄 Using fallback extraction...")
    
    # Look for title patterns in the original filename
    title_patterns = [
        # Look for words in ALL CAPS (common in anime titles)
        r'([A-Z]{2,}(?:\s+[A-Z]{2,})+)',
        # Look for Title Case phrases
        r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
        # Look for common anime title structures
        r'([A-Za-z]+\s+[A-Za-z]+\s+[A-Za-z]+)',
    ]
    
    for pattern in title_patterns:
        match = re.search(pattern, filename)
        if match:
            title = match.group(1).strip()
            print(f"🎯 Fallback found: '{title}'")
            return smart_title_case(title)
    
    # Last resort: remove all metadata and hope something remains
    simple_clean = re.sub(r'[^a-zA-Z\s]', ' ', filename)
    simple_clean = re.sub(r'\s+', ' ', simple_clean).strip()
    words = simple_clean.split()
    
    # Keep only words that look like title words (not metadata)
    title_words = []
    for word in words:
        if (len(word) > 2 and 
            not word.isdigit() and 
            word.lower() not in ['season', 'episode', 'sub', 'dub', 'multi', 'dual', '480p', '720p', '1080p']):
            title_words.append(word)
    
    if title_words:
        final = ' '.join(title_words[:6])  # Limit to 6 words max
        print(f"🎯 Simple fallback: '{final}'")
        return smart_title_case(final)
    
    print("❌ All extraction methods failed")
    return "Unknown Title"
# ==================== ADVANCED + RELIABLE AUDIO DETECTION ====================
async def detect_audio_info(file_path):
    """Best audio detection using filename + ffprobe(json) + ffprobe(csv)"""
    try:
        filename = os.path.basename(file_path)
        print(f"🎯 AUDIO DETECTION STARTED for: {filename}")

        # Method 1: Filename pattern (FASTEST)
        audio_label = _detect_audio_from_filename(filename)
        if audio_label:
            print(f"🎯 Filename detection: {audio_label}")
            return {
                'audio_tracks': 1,
                'audio_label': audio_label,
                'detection_method': 'filename'
            }

        # Method 2: FFprobe JSON (ACCURATE STREAM COUNT)
        print("🎯 Trying FFprobe JSON stream detection…")
        json_result = await _detect_audio_with_ffprobe_json(file_path)
        if json_result:
            label = _detect_audio_from_streams(json_result)
            if label:
                print(f"🎯 JSON stream detection: {label}")
                return {
                    'audio_tracks': len(json_result['audio']),
                    'audio_label': label,
                    'detection_method': 'ffprobe_json'
                }

        # Method 3: FFprobe CSV language detection (LANGUAGE BASED)
        print("🎯 Trying FFprobe CSV language detection…")
        csv_label = await _detect_audio_with_ffprobe(file_path)
        if csv_label:
            print(f"🎯 CSV FFprobe detection: {csv_label}")
            return {
                'audio_tracks': 1,
                'audio_label': csv_label,
                'detection_method': 'ffprobe_csv'
            }

        # Fallback
        print("🎯 Using fallback: Sub")
        return {'audio_tracks': 1, 'audio_label': 'Sub', 'detection_method': 'fallback'}

    except Exception as e:
        print(f"🎯 Audio detection error: {e}")
        return {'audio_tracks': 1, 'audio_label': 'Sub', 'detection_method': 'error'}


# ==================== FILENAME DETECTION ====================
def _detect_audio_from_filename(filename):
    name = filename.lower()
    if any(x in name for x in ['multi', 'multi audio', '[multi]', '(multi)']):
        return "Multi"
    if any(x in name for x in ['dual', 'dual audio', '[dual]', '(dual)', 'eng,jap', 'jap,eng']):
        return "Dual"
    if any(x in name for x in ['dub', 'dubbed', 'english', 'eng', '[dub]', '(dub)']):
        return "Dub"
    if any(x in name for x in ['sub', 'subbed', 'japanese', 'jp', '[sub]', '(sub)']):
        return "Sub"
    return None


# ==================== FFprobe JSON (STREAM INDEX + COUNT) ====================
async def _detect_audio_with_ffprobe_json(input_path):
    try:
        probe = await asyncio.create_subprocess_exec(
            'ffprobe', '-v', 'error',
            '-select_streams', 'v,a,s',
            '-show_entries', 'stream=index,codec_type',
            '-of', 'json', input_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, _ = await probe.communicate()
        if not stdout:
            return None

        data = json.loads(stdout.decode())

        video = [s['index'] for s in data['streams'] if s['codec_type'] == 'video']
        audio = [s['index'] for s in data['streams'] if s['codec_type'] == 'audio']
        subs  = [s['index'] for s in data['streams'] if s['codec_type'] == 'subtitle']

        return {
            "video": video,
            "audio": audio,
            "subs": subs
        }

    except Exception as e:
        print(f"FFprobe JSON Error: {e}")
        return None


# ==================== DETECT BASED ON STREAM COUNTS ====================
def _detect_audio_from_streams(stream_data: dict):
    audio_count = len(stream_data['audio'])

    if audio_count >= 3:
        return "Multi"
    elif audio_count == 2:
        return "Dual"
    elif audio_count == 1:
        return "Sub"  # language detection handled below in CSV method
    else:
        return None


# ==================== FFprobe CSV LANGUAGE DETECTION ====================
async def _detect_audio_with_ffprobe(file_path):
    try:
        cmd = [
            "ffprobe",
            "-v", "error",
            "-select_streams", "a",
            "-show_entries", "stream=codec_type:stream_tags=language",
            "-of", "csv=p=0",
            file_path
        ]

        process = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await process.communicate()

        if process.returncode != 0 or not stdout:
            return None

        output = stdout.decode().strip().split("\n")

        languages = []
        for line in output:
            if "audio" in line and "language=" in line:
                m = re.search(r"language=([a-z]+)", line)
                if m: languages.append(m.group(1))

        if not languages:
            return None

        # Single-audio: detect language accurately
        lang = languages[0]
        if lang in ["jpn", "ja"]:
            return "Sub"
        if lang in ["eng", "en"]:
            return "Dub"

        return "Sub"

    except Exception as e:
        print(f"FFprobe CSV error: {e}")
        return None


# ==================== SAFE GET LABEL ====================
def get_audio_label(info):
    if isinstance(info, dict) and "audio_label" in info:
        return info["audio_label"]
    return "Sub"

async def detect_video_resolution(file_path):
    """Detect actual video resolution using FFmpeg"""
    ffprobe = shutil.which('ffprobe')
    if not ffprobe:
        raise RuntimeError("ffprobe not found in PATH")

    cmd = [
        ffprobe,
        '-v', 'quiet',
        '-print_format', 'json',
        '-show_streams',
        '-select_streams', 'v',
        file_path
    ]

    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()

    try:
        info = json.loads(stdout)
        streams = info.get('streams', [])
        
        if not streams:
            return "Unknown"
            
        video_stream = streams[0]
        width = video_stream.get('width', 0)
        height = video_stream.get('height', 0)
        
        if height >= 2160 or width >= 3840:
            return "2160p"
        elif height >= 1440:
            return "1440p"
        elif height >= 1080:
            return "1080p"
        elif height >= 720:
            return "720p"
        elif height >= 480:
            return "480p"
        elif height >= 360:
            return "360p"
        elif height >= 240:
            return "240p"
        elif height >= 144:
            return "144p"
        else:
            return f"{height}p"
            
    except Exception as e:
        logger.error(f"Resolution detection error: {e}")
        return "Unknown"

async def convert_to_mkv(input_path, output_path):
    """Convert video file to MKV format"""
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise RuntimeError("FFmpeg not found in PATH")

    cmd = [
        ffmpeg,
        '-hide_banner',
        '-i', input_path,
        '-map', '0',
        '-c', 'copy',
        '-f', 'matroska',
        '-y',
        output_path
    ]

    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    _, stderr = await process.communicate()

    if process.returncode != 0:
        error_msg = stderr.decode().strip()
        raise RuntimeError(f"MKV conversion failed: {error_msg}")
    
    return output_path
@Client.on_message(filters.command("law") & filters.private)
@check_ban_status
async def channel_rename(client, message: Message):
    """Rename files directly from channels using message links"""
    user_id = message.from_user.id
    
    if ADMIN_MODE and user_id not in ADMINS:
        return await message.reply_text("**Aᴅᴍɪɴ ᴍᴏᴅᴇ ɪs ᴀᴄᴛɪᴠᴇ - Oɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ᴜsᴇ ᴛʜɪs ʙᴏᴛ!**")
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text(
            "**📥 Cʜᴀɴɴᴇʟ Rᴇɴᴀᴍᴇ - Usᴀɢᴇ:**\n\n"
            "**• Single File:**\n"
            "`/law https://t.me/channel/123`\n\n"
            "**• Batch Range:**\n"
            "`/law https://t.me/c/2303393084/368-400`\n\n"
            "**• Multiple Links:**\n"
            "`/law https://t.me/c/123/100`\n"
            "`https://t.me/c/123/101`\n"
            "`https://t.me/c/123/102`\n\n"
            "**⚠️ For private channels, make bot admin**\n"
            "**💡 Works with videos, documents, and audio files**"
        )
    
    # Extract all URLs from the message
    urls = extract_urls_from_message(message.text)
    if not urls:
        return await message.reply_text("**❌ Nᴏ ᴠᴀʟɪᴅ ᴜʀʟs ғᴏᴜɴᴅ! Pʟᴇᴀsᴇ ᴜsᴇ ᴠᴀʟɪᴅ Tᴇʟᴇɢʀᴀᴍ ᴍᴇssᴀɢᴇ ʟɪɴᴋs.**")
    
    processing_msg = await flood_control.safe_reply_text(message, 
        f"**🔍 Pᴀʀsɪɴɢ {len(urls)} ᴜʀʟ(s)...**\n"
        f"**Pʟᴇᴀsᴇ ᴡᴀɪᴛ...**"
    )
    try:
        # Parse all URLs to get message IDs
        all_message_ids = []
        channel_id = None
        
        for url in urls:
            try:
                parsed_channel_id, message_ids = await parse_channel_url(client, url)
                if parsed_channel_id and message_ids:
                    if channel_id is None:
                        channel_id = parsed_channel_id
                    elif channel_id != parsed_channel_id:
                        await processing_msg.edit_text("**❌ Aʟʟ ʟɪɴᴋs ᴍᴜsᴛ ʙᴇ ғʀᴏᴍ ᴛʜᴇ sᴀᴍᴇ ᴄʜᴀɴɴᴇʟ!**")
                        return
                    
                    all_message_ids.extend(message_ids)
            except Exception as e:
                logger.error(f"Error parsing URL {url}: {e}")
                continue
        
        if not channel_id or not all_message_ids:
            await processing_msg.edit_text("**❌ Nᴏ ᴠᴀʟɪᴅ ᴍᴇssᴀɢᴇ ɪᴅs ғᴏᴜɴᴅ!**")
            return
        
        # Remove duplicates and sort
        all_message_ids = sorted(set(all_message_ids))
        

        await flood_control.safe_edit_message(processing_msg,
            f"**🔍 Fᴇᴛᴄʜɪɴɢ {len(all_message_ids)} ᴍᴇssᴀɢᴇ(s) ғʀᴏᴍ ᴄʜᴀɴɴᴇʟ...**\n"
            f"**Rᴀɴɢᴇ:** `{all_message_ids[0]}`-`{all_message_ids[-1]}`\n"
            f"**Pʟᴇᴀsᴇ ᴡᴀɪᴛ...**"
        )
            
        # Fetch and process messages
        files_found = []
        failed_messages = []
        
        for msg_id in all_message_ids:
            try:
                logger.info(f"Fetching message {msg_id} from channel {channel_id}")
                channel_message = await client.get_messages(channel_id, msg_id)
                
                if not channel_message or channel_message.empty:
                    logger.warning(f"Message {msg_id} is empty or not found")
                    failed_messages.append(f"{msg_id}: Empty message")
                    continue
                
                # Check if message contains downloadable media
                if (channel_message.document or channel_message.video or channel_message.audio):
                    file_info = {
                        'file_id': None,
                        'file_name': None,
                        'file_size': 0,
                        'media_type': None,
                        'message': channel_message,
                        'message_id': msg_id,
                        'channel_id': channel_id
                    }
                    
                    if channel_message.document:
                        file_info['file_id'] = channel_message.document.file_id
                        file_info['file_name'] = channel_message.document.file_name
                        file_info['file_size'] = channel_message.document.file_size
                        file_info['media_type'] = 'document'
                        file_info['file_ext'] = os.path.splitext(channel_message.document.file_name or '')[-1].lower()
                        logger.info(f"Found document: {file_info['file_name']}")
                    
                    elif channel_message.video:
                        file_info['file_id'] = channel_message.video.file_id
                        file_info['file_name'] = channel_message.video.file_name or f"video_{msg_id}.mp4"
                        file_info['file_size'] = channel_message.video.file_size
                        file_info['media_type'] = 'video'
                        file_info['file_ext'] = '.mp4'
                        logger.info(f"Found video: {file_info['file_name']}")
                    
                    elif channel_message.audio:
                        file_info['file_id'] = channel_message.audio.file_id
                        file_info['file_name'] = channel_message.audio.file_name or f"audio_{msg_id}.mp3"
                        file_info['file_size'] = channel_message.audio.file_size
                        file_info['media_type'] = 'audio'
                        file_info['file_ext'] = '.mp3'
                        logger.info(f"Found audio: {file_info['file_name']}")
                    
                    if file_info['file_id']:
                        files_found.append(file_info)
                    else:
                        failed_messages.append(f"{msg_id}: No file ID")
                else:
                    logger.warning(f"Message {msg_id} has no downloadable media")
                    failed_messages.append(f"{msg_id}: No media")
                        
            except Exception as e:
                error_msg = f"{msg_id}: {str(e)}"
                logger.error(f"Error fetching message {msg_id}: {e}")
                failed_messages.append(error_msg)
                continue
        
        # Detailed results
        if not files_found:
            error_details = "\n".join(failed_messages[:10])  # Show first 10 errors
            await processing_msg.edit_text(
                f"**❌ Nᴏ ᴅᴏᴡɴʟᴏᴀᴅᴀʙʟᴇ ғɪʟᴇs ғᴏᴜɴᴅ!**\n\n"
                f"**Mᴇssᴀɢᴇs ᴄʜᴇᴄᴋᴇᴅ:** `{len(all_message_ids)}`\n"
                f"**Fɪʟᴇs ғᴏᴜɴᴅ:** `0`\n\n"
                f"**Cᴏᴍᴍᴏɴ ɪssᴜᴇs:**\n"
                f"• Bᴏᴛ ɴᴏᴛ ᴀᴅᴍɪɴ ɪɴ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀɴɴᴇʟ\n"
                f"• Mᴇssᴀɢᴇs ᴅᴏɴ'ᴛ ᴄᴏɴᴛᴀɪɴ ғɪʟᴇs\n"
                f"• Fɪʟᴇs ᴀʀᴇ ᴛᴏᴏ ʟᴀʀɢᴇ\n\n"
                f"**Fɪʀsᴛ 10 ᴇʀʀᴏʀs:**\n`{error_details}`"
            )
            return
        
        await processing_msg.edit_text(
            f"**✅ Fᴏᴜɴᴅ {len(files_found)} ғɪʟᴇ(s)!**\n"
            f"**🚀 Aᴅᴅɪɴɢ ᴛᴏ ǫᴜᴇᴜᴇ...**\n\n"
            f"**Sᴜᴄᴄᴇss:** `{len(files_found)}` | **Fᴀɪʟᴇᴅ:** `{len(failed_messages)}`\n"
            f"**Fɪʟᴇs:**\n" + "\n".join([f"• `{f['file_name']}`" for f in files_found[:3]]) +
            (f"\n• ... and {len(files_found) - 3} more" if len(files_found) > 3 else "")
        )
        
        # Process each file through the queue
        queued_count = 0
        for file_info in files_found:
            try:
                success = await task_queue.add_task(
                    user_id, 
                    file_info['file_id'], 
                    message, 
                    lambda file_size=None, fi=file_info: process_channel_file(
                        client, message, fi, user_id, file_size
                    ),
                    file_info['file_size']
                )
                if success:
                    queued_count += 1
                    logger.info(f"Queued channel file: {file_info['file_name']}")
                else:
                    logger.error(f"Failed to queue: {file_info['file_name']}")
            except Exception as e:
                logger.error(f"Error queuing file {file_info['file_name']}: {e}")
        
        result_text = (
            f"**📥 Cʜᴀɴɴᴇʟ Rᴇɴᴀᴍᴇ Rᴇsᴜʟᴛs**\n\n"
            f"**• Uʀʟs ᴘᴀʀsᴇᴅ:** `{len(urls)}`\n"
            f"**• Mᴇssᴀɢᴇs ғᴏᴜɴᴅ:** `{len(all_message_ids)}`\n"
            f"**• Fɪʟᴇs ғᴏᴜɴᴅ:** `{len(files_found)}`\n"
            f"**• Qᴜᴇᴜᴇᴅ:** `{queued_count}`\n"
            f"**• Fᴀɪʟᴇᴅ:** `{len(failed_messages)}`\n\n"
        )
        
        if failed_messages:
            result_text += f"**⚠️ {len(failed_messages)} ᴍᴇssᴀɢᴇs ғᴀɪʟᴇᴅ**\n"
        
        result_text += (
            f"**⚡ Fɪʟᴇs ᴡɪʟʟ ʙᴇ ᴀᴜᴛᴏ-ʀᴇɴᴀᴍᴇᴅ ᴀɴᴅ sᴇɴᴛ ʜᴇʀᴇ!**\n"
            f"**📊 Usᴇ /queue ᴛᴏ ᴠɪᴇᴡ ᴘʀᴏɢʀᴇss**"
        )
        
        await processing_msg.edit_text(result_text)
        
    except Exception as e:
        logger.error(f"Channel rename error: {e}")
        await processing_msg.edit_text(
            f"**❌ Cʀɪᴛɪᴄᴀʟ ᴇʀʀᴏʀ:**\n`{str(e)[:200]}`\n\n"
            f"**Pʟᴇᴀsᴇ ᴄʜᴇᴄᴋ:**\n"
            f"• Bᴏᴛ ɪs ᴀᴅᴍɪɴ ɪɴ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀɴɴᴇʟs\n"
            f"• Cʜᴀɴɴᴇʟ ɪs ᴀᴄᴄᴇssɪʙʟᴇ\n"
            f"• Mᴇssᴀɢᴇ ʟɪɴᴋs ᴀʀᴇ ᴠᴀʟɪᴅ\n"
            f"• Fɪʟᴇs ᴀʀᴇ ɴᴏᴛ ᴛᴏᴏ ʟᴀʀɢᴇ"
        )

async def process_channel_file(client, message, file_info, user_id, file_size=None):
    """Process a file from channel with enhanced error handling"""
    try:
        # Get user data for premium/token check
        user_data = await db.col.find_one({"_id": user_id})
        is_premium = user_data.get("is_premium", False) if user_data else False
        
        if not is_premium:
            current_tokens = user_data.get("token", getattr(Config, 'DEFAULT_TOKEN', 0))
            if current_tokens <= 0:
                await message.reply_text("**❌ Yᴏᴜ'ᴠᴇ ʀᴜɴ ᴏᴜᴛ ᴏғ ᴛᴏᴋᴇɴs! Usᴇ /gentoken**")
                return
        
        if PREMIUM_MODE and not is_premium:
            current_tokens = user_data.get("token", 0)
            if current_tokens <= 0:
                await message.reply_text("**❌ Yᴏᴜ'ᴠᴇ ʀᴜɴ ᴏᴜᴛ ᴏғ ᴛᴏᴋᴇɴs! Usᴇ /gentoken**")
                return
            await db.col.update_one(
                {"_id": user_id},
                {"$inc": {"token": -1}}
            )
        
        # Get renaming mode
        mode = await db.get_renaming_mode(user_id) or "autorename"
        msg = await message.reply_text(f"**🔄 Pʀᴏᴄᴇssɪɴɢ:** `{file_info['file_name']}`")
        
        # Verify the file still exists and is accessible
        try:
            # Re-fetch the message to ensure file is still accessible
            channel_message = await client.get_messages(file_info['channel_id'], file_info['message_id'])
            if not channel_message or not (channel_message.document or channel_message.video or channel_message.audio):
                await msg.edit_text(f"**❌ Fɪʟᴇ ɴᴏ ʟᴏɴɢᴇʀ ᴀᴠᴀɪʟᴀʙʟᴇ:** `{file_info['file_name']}`")
                return
        except Exception as e:
            await msg.edit_text(f"**❌ Cᴀɴɴᴏᴛ ᴀᴄᴄᴇss ғɪʟᴇ:** `{file_info['file_name']}`\n`{str(e)}`")
            return

        if mode == "manual":
            # Add file to manual rename queue - FIXED: Use correct file_info data
            manual_file_info = {
                'file_id': file_info['file_id'],
                'file_name': file_info['file_name'],
                'file_size': file_info.get('file_size', 0),
                'file_ext': file_info.get('file_ext', ''),
                'media_type': file_info['media_type'],
                'message': msg,
                'original_message': message,
                'from_channel': True,
                'channel_message': file_info['message']  # Store channel message for later use
            }
            
            # Add to manual queue
            await manual_rename_queue.add_manual_file(user_id, manual_file_info)
            
            # Update queue message
            queue_size = await manual_rename_queue.get_queue_size(user_id)
            await msg.edit_text(
                f"**📥 File Added to Manual Rename**\n\n"
                f"**File:** `{file_info['file_name']}`\n"
                f"**Position:** `#{queue_size}` in manual queue\n\n"
                f"*You'll be prompted for each file name.*",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Start manual processing if not already running
            if not await manual_rename_queue.is_user_processing(user_id):
                await manual_rename_queue.start_manual_processing(user_id)
            return  # Stop here, wait for user input

        elif mode == "replace":
            old_text, new_text = await db.get_replace_pattern(user_id)
            if not old_text or not new_text:
                await msg.edit("**❌ Rᴇᴘʟᴀᴄᴇ ᴍᴏᴅᴇ ᴇɴᴀʙʟᴇᴅ ʙᴜᴛ ɴᴏ ᴘᴀᴛᴛᴇʀɴ sᴇᴛ!**\nUsᴇ /replace \"old_text\" \"new_text\"")
                return
            new_filename = file_info['file_name'].replace(old_text, new_text)
            
        else:  # autorename mode (default)
            try:
                format_template = await db.get_format_template(user_id)
                metadata_source = await db.get_metadata_source(user_id)
                
                # FIXED: Use correct channel message for caption
                channel_msg = file_info.get('message')
                if metadata_source == "caption" and channel_msg and channel_msg.caption:
                    source_text = channel_msg.caption
                else:
                    source_text = file_info['file_name']
                
                # FIXED: Use enhanced extraction functions
                season, episode = extract_season_episode(source_text)
                chapter = extract_chapter(source_text)
                volume = extract_volume(source_text)
                quality = extract_quality(source_text)

                # Get CLEAN title
                clean_title = extract_clean_title(source_text)
                if not format_template:
                    await msg.edit("**❌ Aᴜᴛᴏ ʀᴇɴᴀᴍᴇ ғᴏʀᴍᴀᴛ ɴᴏᴛ sᴇᴛ! Usᴇ /room**")
                    return
                
                # FIXED: Initialize new_filename properly
                new_filename = format_template
                temp_audio_label = "Sub"

                # FIXED: Enhanced audio detection from filename
                filename_audio = _detect_audio_from_filename(source_text)
                if filename_audio:
                    temp_audio_label = filename_audio

                replacements = {
                    # Title variations
                    '{title}': clean_title,
                    '{Title}': clean_title,
                    '{TITLE}': clean_title.upper(),
                    # Audio will be updated after download
                    '{audio}': temp_audio_label,
                    '{Audio}': temp_audio_label, 
                    '{AUDIO}': temp_audio_label.upper(),
                    '[Sub]': f'[{temp_audio_label}]',
                    '[SUB]': f'[{temp_audio_label.upper()}]',
                    '(Sub)': f'({temp_audio_label})',
                    'Sub': temp_audio_label,
                    'SUB': temp_audio_label.upper(),
                    '{season}': season or '01',
                    '{episode}': episode or '01',
                    '{chapter}': chapter or '01',
                    '{volume}': volume or '01',
                    '{quality}': quality,
                    '{Season}': season or '01',
                    '{Episode}': episode or '01',
                    '{Chapter}': chapter or '01',
                    '{Volume}': volume or '01',
                    '{Quality}': quality,
                    '{SEASON}': season or '01',
                    '{EPISODE}': episode or '01',
                    '{CHAPTER}': chapter or '01',
                    '{VOLUME}': volume or '01',
                    '{QUALITY}': quality,
                    'Season': season or '01',
                    'Episode': episode or '01',
                    'Chapter': chapter or '01',
                    'Volume': volume or '01',
                    'Quality': quality,
                    'SEASON': season or '01',
                    'EPISODE': episode or '01',
                    'CHAPTER': chapter or '01',
                    'VOLUME': volume or '01',
                    'QUALITY': quality,
                    'season': season or '01',
                    'episode': episode or '01',
                    'chapter': chapter or '01',
                    'volume': volume or '01',
                    'quality': quality,
                }
                
                # FIXED: Apply replacements to new_filename
                for placeholder, value in replacements.items():
                    if placeholder in new_filename:
                        new_filename = new_filename.replace(placeholder, value)
                        logger.info(f"   Replaced '{placeholder}' with '{value}'")
                new_filename = remove_duplicate_tags(new_filename)

                # Add file extension
                new_filename = f"{new_filename}{file_info.get('file_ext', '')}"
                
            except Exception as rename_error:
                logger.error(f"Auto-rename error for channel file: {rename_error}")
                await msg.edit("**⚠️ Aᴜᴛᴏ ʀᴇɴᴀᴍᴇ ғᴀɪʟᴇᴅ! Usɪɴɢ ᴏʀɪɢɪɴᴀʟ ɴᴀᴍᴇ.**")
                new_filename = file_info['file_name']

        # Process the file through the same pipeline but use channel message
        await post_rename_process(
            client, 
            message, 
            new_filename, 
            file_info['media_type'], 
            file_info.get('file_ext', ''), 
            msg, 
            user_id, 
            message.from_user, 
            is_premium, 
            file_info['file_id'], 
            file_info['file_name'], 
            file_info['file_size'], 
            channel_message=file_info['message']  # Pass channel_message here
        )
    except Exception as e:
        logger.error(f"Channel file processing error: {e}")
        error_msg = f"**❌ Eʀʀᴏʀ ᴘʀᴏᴄᴇssɪɴɢ ᴄʜᴀɴɴᴇʟ ғɪʟᴇ:** `{file_info['file_name']}`\n`{str(e)[:200]}`"
        if 'msg' in locals():
            try:
                await msg.edit(error_msg)
                await asyncio.sleep(30)
                await msg.delete()
            except:
                await message.reply_text(error_msg)
        else:
            error_response = await message.reply_text(error_msg)
            await asyncio.sleep(30)
            await error_response.delete()
def extract_urls_from_message(text):
    """Extract all Telegram URLs from message text"""
    import re
    
    # Pattern to match Telegram URLs
    url_pattern = r'https?://t\.me/(?:c/)?(?:\w+/\d+(?:-\d+)?|\w+/\d+)'
    
    urls = re.findall(url_pattern, text)
    return urls
# Update the URL parsing function to accept client parameter
async def parse_channel_url(client, url):
    """
    Parse Telegram channel URL and extract channel ID and message IDs
    """
    try:
        import re
        
        url = url.strip()
        
        # Enhanced pattern to match various Telegram URL formats
        pattern = r'https?://t\.me/(?:c/)?(\d+|[a-zA-Z0-9_]+)/(\d+(?:-\d+)?)'
        match = re.search(pattern, url)
        
        if not match:
            return None, None
        
        channel_part = match.group(1)
        message_part = match.group(2)
        
        # Parse message IDs
        message_ids = []
        if '-' in message_part:
            try:
                start_id, end_id = map(int, message_part.split('-'))
                message_ids = list(range(start_id, end_id + 1))
            except ValueError:
                return None, None
        else:
            try:
                message_ids = [int(message_part)]
            except ValueError:
                return None, None
        
        # Handle channel ID resolution
        if channel_part.isdigit():
            # Private channel with numeric ID
            channel_id = int(channel_part)
            if channel_id > 0:  # Convert to negative for private channels
                channel_id = -1000000000000 - abs(channel_id)
        else:
            # Public channel with username
            try:
                chat = await client.get_chat(channel_part)
                channel_id = chat.id
            except Exception as e:
                logger.error(f"Error resolving channel {channel_part}: {e}")
                return None, None
        
        return channel_id, message_ids
        
    except Exception as e:
        logger.error(f"URL parsing error for {url}: {e}")
        return None, None
@Client.on_message(filters.command("law_sort") & filters.private)
@check_ban_status
async def channel_sort_command(client, message: Message):
    """Sort files from channel links using the same sorting modes"""
    user_id = message.from_user.id
    
    if ADMIN_MODE and user_id not in ADMINS:
        return await message.reply_text("**Aᴅᴍɪɴ ᴍᴏᴅᴇ ɪs ᴀᴄᴛɪᴠᴇ - Oɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ᴜsᴇ ᴄʜᴀɴɴᴇʟ sᴏʀᴛɪɴɢ!**")
    
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text(
            "**📥 Cʜᴀɴɴᴇʟ Sᴏʀᴛ - Usᴀɢᴇ:**\n\n"
            "**• Single File:**\n"
            "`/law_sort https://t.me/channel/123`\n\n"
            "**• Batch Range:**\n"
            "`/law_sort https://t.me/c/2303393084/368-400`\n\n"
            "**• Multiple Links:**\n"
            "`/law_sort https://t.me/c/123/100`\n"
            "`https://t.me/c/123/101`\n"
            "`https://t.me/c/123/102`\n\n"
            "**⚡ Sᴏʀᴛɪɴɢ:** Uses your current sorting mode\n"
            "**🔧 Sᴇᴛ Mᴏᴅᴇ:** Use `/sorting_mode` to change\n"
            "**💡 Tɪᴘ:** Works with videos, documents, and audio files"
        )
    
    # Get user's current sorting mode
    sorting_mode = await db.get_sorting_mode(user_id) or "Season"
    
    processing_msg = await flood_control.safe_reply_text(message, 
        f"**🔍 Pᴀʀsɪɴɢ ᴄʜᴀɴɴᴇʟ ʟɪɴᴋs...**\n"
        f"**Sᴏʀᴛɪɴɢ Mᴏᴅᴇ:** `{sorting_mode}`\n"
        f"**Pʟᴇᴀsᴇ ᴡᴀɪᴛ...**"
    )
    
    try:
        # Extract URLs from message
        urls = extract_urls_from_message(message.text)
        if not urls:
            await processing_msg.edit_text("**❌ Nᴏ ᴠᴀʟɪᴅ ᴜʀʟs ғᴏᴜɴᴅ!**")
            return
        
        # Parse all URLs to get message IDs
        all_message_ids = []
        channel_id = None
        
        for url in urls:
            try:
                parsed_channel_id, message_ids = await parse_channel_url(client, url)
                if parsed_channel_id and message_ids:
                    if channel_id is None:
                        channel_id = parsed_channel_id
                    elif channel_id != parsed_channel_id:
                        await processing_msg.edit_text("**❌ Aʟʟ ʟɪɴᴋs ᴍᴜsᴛ ʙᴇ ғʀᴏᴍ ᴛʜᴇ sᴀᴍᴇ ᴄʜᴀɴɴᴇʟ!**")
                        return
                    
                    all_message_ids.extend(message_ids)
            except Exception as e:
                logger.error(f"Error parsing URL {url}: {e}")
                continue
        
        if not channel_id or not all_message_ids:
            await processing_msg.edit_text("**❌ Nᴏ ᴠᴀʟɪᴅ ᴍᴇssᴀɢᴇ ɪᴅs ғᴏᴜɴᴅ!**")
            return
        
        # Remove duplicates and sort
        all_message_ids = sorted(set(all_message_ids))
        
        await processing_msg.edit_text(
            f"**🔍 Fᴇᴛᴄʜɪɴɢ {len(all_message_ids)} ᴍᴇssᴀɢᴇ(s)...**\n"
            f"**Rᴀɴɢᴇ:** `{all_message_ids[0]}`-`{all_message_ids[-1]}`\n"
            f"**Sᴏʀᴛ Mᴏᴅᴇ:** `{sorting_mode}`\n"
            f"**Pʟᴇᴀsᴇ ᴡᴀɪᴛ...**"
        )
        
        # Fetch messages and collect file information
        files_found = []
        failed_messages = []
        
        for msg_id in all_message_ids:
            try:
                channel_message = await client.get_messages(channel_id, msg_id)
                
                if not channel_message or channel_message.empty:
                    failed_messages.append(f"{msg_id}: Empty message")
                    continue
                
                # Check if message contains downloadable media
                if (channel_message.document or channel_message.video or channel_message.audio):
                    file_info = {
                        'file_id': None,
                        'file_name': None,
                        'file_size': 0,
                        'media_type': None,
                        'message': channel_message,
                        'message_id': msg_id,
                        'channel_id': channel_id
                    }
                    
                    if channel_message.document:
                        file_info['file_id'] = channel_message.document.file_id
                        file_info['file_name'] = channel_message.document.file_name
                        file_info['file_size'] = channel_message.document.file_size
                        file_info['media_type'] = 'document'
                        file_info['file_ext'] = os.path.splitext(channel_message.document.file_name or '')[-1].lower()
                    
                    elif channel_message.video:
                        file_info['file_id'] = channel_message.video.file_id
                        file_info['file_name'] = channel_message.video.file_name or f"video_{msg_id}.mp4"
                        file_info['file_size'] = channel_message.video.file_size
                        file_info['media_type'] = 'video'
                        file_info['file_ext'] = '.mp4'
                    
                    elif channel_message.audio:
                        file_info['file_id'] = channel_message.audio.file_id
                        file_info['file_name'] = channel_message.audio.file_name or f"audio_{msg_id}.mp3"
                        file_info['file_size'] = channel_message.audio.file_size
                        file_info['media_type'] = 'audio'
                        file_info['file_ext'] = '.mp3'
                    
                    if file_info['file_id']:
                        files_found.append(file_info)
                    else:
                        failed_messages.append(f"{msg_id}: No file ID")
                else:
                    failed_messages.append(f"{msg_id}: No media")
                        
            except Exception as e:
                error_msg = f"{msg_id}: {str(e)}"
                logger.error(f"Error fetching message {msg_id}: {e}")
                failed_messages.append(error_msg)
                continue
        
        if not files_found:
            error_details = "\n".join(failed_messages[:10])
            await processing_msg.edit_text(
                f"**❌ Nᴏ ᴅᴏᴡɴʟᴏᴀᴅᴀʙʟᴇ ғɪʟᴇs ғᴏᴜɴᴅ!**\n\n"
                f"**Mᴇssᴀɢᴇs ᴄʜᴇᴄᴋᴇᴅ:** `{len(all_message_ids)}`\n"
                f"**Fɪʟᴇs ғᴏᴜɴᴅ:** `0`\n\n"
                f"**Fɪʀsᴛ 10 ᴇʀʀᴏʀs:**\n`{error_details}`"
            )
            return
        
        # Apply sorting using the same logic as /esequence
        sorted_files = await apply_sorting_to_files(files_found, user_id, sorting_mode)
        
        await processing_msg.edit_text(
            f"**✅ Fᴏᴜɴᴅ {len(files_found)} ғɪʟᴇ(s)!**\n"
            f"**🎯 Sᴏʀᴛᴇᴅ ɪɴ `{sorting_mode}` ᴍᴏᴅᴇ**\n"
            f"**🚀 Sᴇɴᴅɪɴɢ sᴏʀᴛᴇᴅ ғɪʟᴇs...**\n\n"
            f"**Sᴜᴄᴄᴇss:** `{len(files_found)}` | **Fᴀɪʟᴇᴅ:** `{len(failed_messages)}`"
        )
        
        # Send sorted files
        sent_count = await send_sorted_channel_files(client, message, sorted_files, user_id, sorting_mode)
        
        # Update statistics
        await db.add_sorted_history(user_id, sent_count)
        await db.sequence_logs.insert_one({
            "user_id": user_id,
            "file_count": sent_count,
            "timestamp": datetime.now(),
            "type": "channel_sort"
        })
        
        await processing_msg.edit_text(
            f"**🎉 Cʜᴀɴɴᴇʟ Sᴏʀᴛ Cᴏᴍᴘʟᴇᴛᴇ!**\n\n"
            f"**• Fɪʟᴇs Fᴏᴜɴᴅ:** `{len(files_found)}`\n"
            f"**• Fɪʟᴇs Sᴇɴᴛ:** `{sent_count}`\n"
            f"**• Sᴏʀᴛ Mᴏᴅᴇ:** `{sorting_mode}`\n"
            f"**• Fᴀɪʟᴇᴅ:** `{len(failed_messages)}`\n\n"
           # f"**📊 Usᴇ /renamed ᴛᴏ ᴠɪᴇᴡ ʏᴏᴜʀ sᴛᴀᴛs**"
        )
        
    except Exception as e:
        logger.error(f"Channel sort error: {e}")
        await processing_msg.edit_text(
            f"**❌ Cʜᴀɴɴᴇʟ sᴏʀᴛ ғᴀɪʟᴇᴅ:**\n`{str(e)[:200]}`"
        )

async def apply_sorting_to_files(files_list, user_id, sorting_mode):
    """Apply sorting to channel files using the same logic as sequence sorting"""
    
    def _get_filename(item):
        """Extract a filename string from different item shapes (dicts, objects, raw strings)."""
        if isinstance(item, dict):
            for k in ("file_name", "file", "name", "file_path", "filename"):
                if k in item and item[k]:
                    return str(item[k])
            # fallback to str
            return str(item)
        # object with attribute
        if hasattr(item, "file_name"):
            return str(getattr(item, "file_name"))
        if hasattr(item, "name"):
            return str(getattr(item, "name"))
        return str(item)

    QUALITY_RANK = {
        "2160p": 8, "4k": 8,
        "1440p": 7, "2k": 7,
        "1080p": 6, "fhd": 6,
        "720p": 5, "hd": 5,
        "480p": 4, "sd": 4,
        "360p": 3, "240p": 2, "144p": 1
    }

    def _normalize_text(s: str) -> str:
        s = unicodedata.normalize("NFKD", s)
        s = re.sub(r'\s+', ' ', s).strip()
        return s.lower()

    def detect_quality_from_token(token: str):
        """Enhanced quality detection for anime/manga"""
        t = token.lower()
        
        # Anime-specific quality patterns
        quality_patterns = [
            (r'2160p|\b4k\b', '2160p'),
            (r'1440p|\b2k\b', '1440p'), 
            (r'1080p|\bfhd\b', '1080p'),
            (r'720p|\bhd\b', '720p'),
            (r'480p|\bsd\b', '480p'),
            (r'360p', '360p'),
            (r'240p', '240p'),
            (r'144p', '144p'),
            (r'(\d{3,4})p', None),
            
            # Manga quality indicators
            (r'\b(?:high|good|excellent)\s*quality\b', 'High Quality'),
            (r'\b(?:web|digital)\s*(?:dl|download)\b', 'Digital'),
            (r'\bscanlation\b', 'Scanlation'),
            (r'\bvolume\b', 'Volume'),
            (r'\b(colored|color|colour)\b', 'Colored'),
            (r'\b(bw|black.white|monochrome)\b', 'B&W'),
        ]
        
        for pat, lab in quality_patterns:
            m = re.search(pat, t)
            if m:
                return lab if lab else f"{m.group(1)}p"
        
        return None

    def parse_filename(filename: str):
        """
        Enhanced parser for anime, manga, and general media files
        Return dict: { title, title_norm, season (int), episode (int), chapter (int),
                    quality (str), quality_rank (int), group (str), raw }
        """
        raw = filename or ""
        base = os.path.splitext(raw)[0]

        # Find bracketed tokens first (common in release names)
        bracket_tokens = re.findall(r'\[(.*?)\]', base)
        paren_tokens = re.findall(r'\((.*?)\)', base)
        tokens = bracket_tokens + paren_tokens

        season = None
        episode = None
        chapter = None
        volume = None
        quality = None
        group = None

        # ==================== ENHANCED PATTERNS FOR ANIME/MANGA ====================
        
        # Anime/Manga specific patterns - EXPANDED
        anime_manga_patterns = [
            # ADDED: Pattern for "Ep. (103)" format
            r'(?i)\b(?:EP|Ep|ep|Episode|episode)\s*\((\d{1,3})\)',
            
            # Episode patterns (anime)
            r'(?i)\b(?:EP|Ep|ep|Episode|episode)\s*(\d{1,3})\b',
            r'(?i)\bE\s*(\d{1,3})\b',
            r'(?i)\b-\s*(\d{1,3})(?:\s|v|\]|$)',
            
            # Chapter patterns (manga) - EXPANDED
            r'(?i)\b(?:CH|Ch|ch|Chapter|chapter)\s*[\.\-_\s]?(\d{1,4}(?:\.\d+)?)\b',
            r'(?i)\bC\s*(\d{1,4})\b',
            r'(?i)\bCh\.\s*(\d{1,4})\b',
            r'(?i)\bCh\s*[\.\-_\s]?\s*(\d{1,4})\b',  # Added for "Ch-57" pattern
            r'(?i)\[Ch[\.\-_\s]?(\d{1,4})\]',  # Added for "[Ch-57]" pattern
            
            # Combined season+episode
            r'(?i)\bS(\d{1,2})\s*[\.\-_\s]?\s*E(\d{1,3})\b',
            r'(?i)\bSeason\s*(\d{1,2})\s*[\.\-_\s]?\s*Episode\s*(\d{1,3})\b',
            r'(?i)\b(\d{1,2})x(\d{1,3})\b',
            
            # Volume patterns
            r'(?i)\b(?:Vol|Volume|VOL)\s*[\.\-_]?\s*(\d{1,2})\b',
            r'(?i)\bV\s*[\.\-_]?\s*(\d{1,2})\b',
            
            # Standalone numbers (will be classified later)
            r'(?i)(?:^|\s|\]|\[)(\d{1,4})(?:\.\d+)?(?:\s|$|\[|\]|v)',
        ]

        # Check tokens first (higher confidence)
        for t in tokens:
            # Season+Episode
            if not season and not episode:
                season_ep_match = re.search(r'(?i)S(\d{1,2})[\.\-_\s]?E?(\d{1,3})', t)
                if season_ep_match:
                    try:
                        season = int(season_ep_match.group(1))
                        episode = int(season_ep_match.group(2))
                        continue
                    except:
                        pass

            # Chapter patterns in brackets (like [Ch-57])
            if not chapter:
                # Handle "Ch-57" pattern
                ch_hyphen_match = re.search(r'(?i)ch[\.\-_\s]?(\d{1,4})', t)
                if ch_hyphen_match:
                    try:
                        chapter = float(ch_hyphen_match.group(1))
                        continue
                    except:
                        pass
                
                # Handle other chapter patterns
                ch_match = re.search(r'(?i)(?:CH|Chapter)\s*(\d{1,4}(?:\.\d+)?)', t)
                if ch_match:
                    try:
                        chapter = float(ch_match.group(1))
                        continue
                    except:
                        pass

            # Episode only in brackets
            if not episode:
                ep_match = re.search(r'(?i)(?:EP|Episode)\s*(\d{1,3})', t)
                if ep_match:
                    try:
                        episode = int(ep_match.group(1))
                        if not season:
                            season = 1
                        continue
                    except:
                        pass

            # Volume
            if not volume:
                vol_match = re.search(r'(?i)(?:Vol|Volume)\s*(\d{1,2})', t)
                if vol_match:
                    try:
                        volume = int(vol_match.group(1))
                        continue
                    except:
                        pass

            # Standalone numbers in brackets (common in manga)
            if not chapter and not episode:
                standalone_match = re.search(r'^\s*(\d{1,4}(?:\.\d+)?)\s*$', t)
                if standalone_match:
                    try:
                        num_val = standalone_match.group(1)
                        if '.' in num_val:
                            chapter = float(num_val)
                        else:
                            num_int = int(num_val)
                            # Numbers in brackets are usually chapters
                            chapter = float(num_int)
                        continue
                    except:
                        pass

        # If not found in tokens, search in base filename
        if not episode and not chapter:
            for pattern in anime_manga_patterns:
                match = re.search(pattern, base)
                if match:
                    try:
                        groups = match.groups()
                        
                        # Episode patterns (including the new "Ep. (103)" pattern)
                        if 'ep' in pattern.lower() or 'e\s*\d' in pattern.lower() or 'episode' in pattern.lower():
                            episode = int(groups[0])
                            if not season:
                                season = 1
                            logger.info(f"Found episode {episode} using pattern: {pattern} in filename: {filename}")
                            break
                        # Chapter patterns  
                        elif 'ch' in pattern.lower():
                            chapter = float(groups[0])
                            break
                        # Volume patterns
                        elif 'vol' in pattern.lower():
                            volume = int(groups[0])
                            break
                        # Standalone numbers - need classification
                        elif len(groups) == 1 and groups[0].isdigit():
                            num_val = groups[0]
                            num_int = int(num_val)
                            
                            # Classification logic for standalone numbers
                            if _is_likely_manga(base, num_int):
                                chapter = float(num_int)
                            else:
                                episode = num_int
                                if not season:
                                    season = 1
                            break
                    except Exception as parse_error:
                        logger.warning(f"Error parsing pattern {pattern} for {filename}: {parse_error}")
                        continue

        # Special handling for pure number filenames
        if not episode and not chapter:
            # Pattern for filenames that are just numbers
            pure_number_match = re.search(r'^\s*(\d{1,4}(?:\.\d+)?)\s*$', base)
            if pure_number_match:
                try:
                    num_val = pure_number_match.group(1)
                    num_int = int(float(num_val)) if '.' in num_val else int(num_val)
                    
                    if _is_likely_manga(base, num_int):
                        chapter = float(num_val)
                    else:
                        episode = num_int
                        if not season:
                            season = 1
                except:
                    pass

        # Final fallback - extract any number from filename
        if not episode and not chapter:
            any_number_match = re.search(r'(\d{1,4}(?:\.\d+)?)', base)
            if any_number_match:
                try:
                    num_val = any_number_match.group(1)
                    num_int = int(float(num_val)) if '.' in num_val else int(num_val)
                    
                    if _is_likely_manga(base, num_int):
                        chapter = float(num_val)
                    else:
                        episode = num_int
                        if not season:
                            season = 1
                except:
                    pass

        # Quality detection
        for t in tokens:
            q = detect_quality_from_token(t)
            if q:
                quality = q
                break
        if not quality:
            q = detect_quality_from_token(base)
            if q:
                quality = q

        # Group detection - improved
        for t in bracket_tokens:
            # Look for group indicators
            if re.search(r'@|team|group|fansub|subs|scanlation|manga2u', t, flags=re.I):
                group = t
                break
        
        # If no group found but we have tokens, use the first non-metadata token
        if not group and bracket_tokens:
            for t in bracket_tokens:
                # Skip if it's clearly metadata
                if re.search(r'\b(?:s\d+e\d+|\d{3,4}p|4k|x264|x265|hevc|multi|dub|sub|bdrip|bluray|web[- ]?rip|ch[\.\-]?\d+|ep?\d+)\b', t, flags=re.I):
                    continue
                # Skip if it's just a number
                if re.search(r'^\s*\d+\s*$', t):
                    continue
                group = t
                break

        # Title extraction with anime/manga awareness
        title_candidate = None
        
        # Remove common anime/manga tags for title extraction
        cleaned_base = base
        
        # First, try to extract title from brackets (common in anime/manga)
        title_bracket_match = re.search(r'\[([^\]\d]+)\]', base)
        if title_bracket_match:
            potential_title = title_bracket_match.group(1).strip()
            # Check if it looks like a title (not a group, not metadata)
            if (len(potential_title) > 2 and 
                not re.search(r'@|team|group|fansub', potential_title, re.I) and
                not re.search(r'\d{3,4}p|4k|x264', potential_title, re.I)):
                title_candidate = potential_title
        
        if not title_candidate:
            clean_patterns = [
                r'\[.*?\]', r'\(.*?\)',  # Remove brackets/parens
                r'\b(?:S\d+\s*E\d+|\d+x\d+)\b',  # Remove S01E01 patterns
                r'\b(?:EP?\s*\d+|Episode\s*\d+)\b',  # Remove Episode patterns
                r'\b(?:CH?[\.\-]?\s*\d+|Chapter\s*\d+)\b',  # Remove Chapter patterns (including Ch-57)
                r'\b(?:Vol\.?\s*\d+|Volume\s*\d+)\b',  # Remove Volume patterns
                r'\b\d{3,4}p\b', r'\b4k\b', r'\b1080p\b', r'\b720p\b',  # Remove quality
                r'\b(?:x264|x265|hevc|avc)\b',  # Remove codecs
                r'\b(?:sub|dub|dual)\b',  # Remove audio tags
            ]
            
            for pattern in clean_patterns:
                cleaned_base = re.sub(pattern, '', cleaned_base, flags=re.IGNORECASE)
            
            # Clean up extra spaces and separators
            cleaned_base = re.sub(r'[._\-]+', ' ', cleaned_base)
            cleaned_base = re.sub(r'\s+', ' ', cleaned_base).strip()
            
            # Find title in remaining text
            if cleaned_base:
                title_candidate = cleaned_base
        
        # Final fallback
        if not title_candidate:
            title_candidate = os.path.splitext(os.path.basename(raw))[0]

        title = title_candidate.strip(" -._")
        title_norm = _normalize_text(title)

        q_rank = QUALITY_RANK.get((quality or "").lower(), 0)

        return {
            "raw": raw,
            "title": title,
            "title_norm": title_norm,
            "season": int(season) if season is not None else 0,
            "episode": int(episode) if episode is not None else 0,
            "chapter": float(chapter) if chapter is not None else 0.0,
            "volume": int(volume) if volume is not None else 0,
            "quality": quality or "",
            "quality_rank": q_rank,
            "group": group or "",
            "is_manga": chapter is not None,  # Flag to identify manga
            "is_anime": episode is not None and chapter is None  # Flag to identify anime
        }


    def _is_likely_manga(filename: str, number: int) -> bool:
        """
        Helper function to determine if a standalone number is likely a chapter or episode
        """
        filename_lower = filename.lower()
        
        # Manga indicators
        manga_indicators = [
            'chapter', 'ch.', 'ch', 'ch-', 'vol', 'volume', 
            'manga', 'comic', 'oneshot', 'one-shot', 'scanlation',
            'gb', 'graphic novel', 'panel', 'page'
        ]
        
        # Anime indicators  
        anime_indicators = [
            'episode', 'ep.', 'ep', 'season', 's01', 's02',
            'anime', 'batch', 'cour', 'ova', 'movie', 'special',
            'opening', 'ending', 'preview', 'trailer'
        ]
        
        manga_score = sum(1 for indicator in manga_indicators if indicator in filename_lower)
        anime_score = sum(1 for indicator in anime_indicators if indicator in filename_lower)
        
        # File extension hints
        file_ext = os.path.splitext(filename)[1].lower()
        if file_ext in ['.pdf', '.cbz', '.cbr', '.epub', '.mobi']:
            manga_score += 2
        elif file_ext in ['.mp4', '.mkv', '.avi', '.mov', '.wmv']:
            anime_score += 2
        
        # Number range hints (chapters are often higher numbers)
        if number > 100:
            manga_score += 1
        elif number < 50:
            anime_score += 1
        
        return manga_score > anime_score

    # ---------- parse all files ----------
    parsed = []
    for item in files_list:
        fname = _get_filename(item)
        logger.info(f"Parsing filename: {fname}")
        meta = parse_filename(fname)
        meta["orig_item"] = item
        parsed.append(meta)
        logger.info(f"Parsed result: S{meta['season']}E{meta['episode']} - {meta['title']}")

    mode = sorting_mode.lower()

    if mode == "quality":
        # Highest quality first, then season, episode/chapter
        keyfunc = lambda m: (
            -m["quality_rank"], 
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            m["title_norm"]
        )
    elif mode == "title":
        # Title first, then season, episode/chapter, quality
        keyfunc = lambda m: (
            m["title_norm"], 
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"]
        )
    elif mode == "both":
        # Title, quality, then episode/chapter
        keyfunc = lambda m: (
            m["title_norm"], 
            -m["quality_rank"],
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"]
        )
    elif mode == "episode":
        # Episode/chapter ascending (season ignored)
        keyfunc = lambda m: (
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"], 
            m["title_norm"]
        )
    elif mode == "season":
        # Season -> episode/chapter -> best quality
        keyfunc = lambda m: (
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"], 
            m["title_norm"]
        )
    else:
        # Default: season -> episode/chapter -> best quality
        keyfunc = lambda m: (
            m["season"], 
            m["chapter"] if m["is_manga"] else m["episode"],
            -m["quality_rank"], 
            m["title_norm"]
        )
    
    sorted_parsed = sorted(parsed, key=keyfunc)

    # Log sorted results for debugging
    logger.info(f"=== SORTED RESULTS ({sorting_mode} mode) ===")
    for i, meta in enumerate(sorted_parsed):
        logger.info(f"#{i+1}: '{meta['raw']}' -> S{meta['season']}E{meta['episode']}")

    # Build sorted list of original items to send
    sorted_files = [m["orig_item"] for m in sorted_parsed]
    sort_count = len(sorted_files)
    
    return sorted_files
async def send_sorted_channel_files(client, message, sorted_files, user_id, sorting_mode):
    """Send sorted channel files to user with enhanced error handling"""
    sent_count = 0
    sent_files = set()
    
    for index, file_info in enumerate(sorted_files):
        max_retries = 2
        for attempt in range(max_retries):
            try:
                if file_info['file_id'] in sent_files:
                    break
                
                # USING BLOCKQUOTE FORMAT FOR FILENAME
                caption = f"<blockquote>{file_info['file_name']}</blockquote>"
                
                # Method 1: Try document first (most compatible)
                if attempt == 0:
                    try:
                        if file_info['media_type'] == 'video':
                            # For video files, try as document first to avoid "Expected DOCUMENT, got VIDEO" error
                            sent_msg = await client.send_document(
                                message.chat.id,
                                file_info['file_id'],
                                caption=caption,
                                parse_mode=ParseMode.HTML  # CHANGED TO HTML FOR BLOCKQUOTE
                            )
                        else:
                            # For documents and audio, use their respective methods
                            if file_info['media_type'] == 'document':
                                sent_msg = await client.send_document(
                                    message.chat.id,
                                    file_info['file_id'],
                                    caption=caption,
                                    parse_mode=ParseMode.HTML  # CHANGED TO HTML FOR BLOCKQUOTE
                                )
                            elif file_info['media_type'] == 'audio':
                                sent_msg = await client.send_audio(
                                    message.chat.id,
                                    file_info['file_id'],
                                    caption=caption,
                                    parse_mode=ParseMode.HTML  # CHANGED TO HTML FOR BLOCKQUOTE
                                )
                        
                        sent_files.add(file_info['file_id'])
                        sent_count += 1
                        break  # Success, break retry loop
                        
                    except Exception as e:
                        if "Expected DOCUMENT" in str(e) or "got VIDEO" in str(e):
                            # This is a video file that needs to be sent as video
                            logger.info(f"File {file_info['file_name']} is a video, retrying as video...")
                            continue  # Go to next attempt
                        else:
                            raise e  # Re-raise other errors
                
                # Method 2: Try as video (for actual video files)
                elif attempt == 1:
                    try:
                        sent_msg = await client.send_video(
                            message.chat.id,
                            file_info['file_id'],
                            caption=caption,  # Uses the same blockquote caption
                            parse_mode=ParseMode.HTML  # CHANGED TO HTML FOR BLOCKQUOTE
                        )
                        sent_files.add(file_info['file_id'])
                        sent_count += 1
                        break
                    except Exception as video_error:
                        logger.warning(f"Video send failed for {file_info['file_name']}: {video_error}")
                        # Final fallback - try as document again
                        try:
                            sent_msg = await client.send_document(
                                message.chat.id,
                                file_info['file_id'],
                                caption=caption,  # Uses the same blockquote caption
                                parse_mode=ParseMode.HTML  # CHANGED TO HTML FOR BLOCKQUOTE
                            )
                            sent_files.add(file_info['file_id'])
                            sent_count += 1
                            break
                        except Exception as final_error:
                            logger.error(f"Final attempt failed for {file_info['file_name']}: {final_error}")
                
            except FloodWait as e:
                await asyncio.sleep(e.value + 1)
                continue  # Retry after flood wait
            except Exception as e:
                logger.error(f"Error sending file {file_info['file_name']} (attempt {attempt+1}): {e}")
                if attempt == max_retries - 1:
                    break  # Final attempt failed
                await asyncio.sleep(1)  # Wait before retry
        
        # Small delay between sends to avoid flooding
        if index < len(sorted_files) - 1:
            await asyncio.sleep(1)
    
    return sent_count
@Client.on_message(filters.command("Lawhelp") & filters.private)
@check_ban_status
async def help_command(client, message: Message):
    help_text = f"""
**🤖 {Config.BOT_NAME} - Cᴏᴍᴍᴀɴᴅs Mᴇɴᴜ**

**📁 Fɪʟᴇ Rᴇɴᴀᴍɪɴɢ:**
• **Jᴜsᴛ sᴇɴᴅ ғɪʟᴇ** - Aᴜᴛᴏ ʀᴇɴᴀᴍᴇ
• `/room` - Sᴇᴛ ᴀᴜᴛᴏ ʀᴇɴᴀᴍᴇ ғᴏʀᴍᴀᴛ
• `/manual` - Mᴀɴᴜᴀʟ ʀᴇɴᴀᴍᴇ ᴍᴏᴅᴇ
• `/replace` - Rᴇᴘʟᴀᴄᴇ ᴍᴏᴅᴇ
• `/mode` - Rᴇname modes 

**🎬 Cʜᴀɴɴᴇʟ Rᴇɴᴀᴍᴇ:**
• `/law ᴜʀʟ` - Rᴇɴᴀᴍᴇ ғʀᴏᴍ ᴄʜᴀɴɴᴇʟ ʟɪɴᴋ
• `ᴇɢ: /law https://t.me/channel/123`
• `ᴇɢ: /law https://t.me/c/123456/100-120`

**📊 Sᴇǫᴜᴇɴᴄᴇ & Sᴏʀᴛɪɴɢ:**
• `/ssequence` - Sᴛᴀʀᴛ ғɪʟᴇ sᴇǫᴜᴇɴᴄᴇ
• `/esequence` - Eɴᴅ & sᴏʀᴛ sᴇǫᴜᴇɴᴄᴇ
• `/sorting_mode` - Sᴇᴛ sᴏʀᴛɪɴɢ ᴘʀᴇғᴇʀᴇɴᴄᴇ

**📈 Sᴛᴀᴛs & Lᴇᴀᴅᴇʀʙᴏᴀʀᴅ:**
• `/renamed` - Yᴏᴜʀ sᴛᴀᴛɪsᴛɪᴄs
• `/leaderboard` - Tᴏᴘ ᴜsᴇʀs
• `/info` - Sʏsᴛᴇᴍ ɪɴғᴏ

**⚙️ Sᴇᴛᴛɪɴɢs:**
• `/settings` - Bᴏᴛ sᴇᴛᴛɪɴɢs
• `/mode_pdf` - PDF sᴇᴛᴛɪɴɢs
• `/queue` - Vɪᴇᴡ ǫᴜᴇᴜᴇ

**🎟️ Tᴏᴋᴇɴs & Pʀᴇᴍɪᴜᴍ:**
• `/gentoken` - Gᴇɴᴇʀᴀᴛᴇ ᴛᴏᴋᴇɴs
• `/buy` - Bᴜʏ ᴘʀᴇᴍɪᴜᴍ

**💡 Tɪᴘ:** Usᴇ `/law` ᴛᴏ ʀᴇɴᴀᴍᴇ ғɪʟᴇs ᴅɪʀᴇᴄᴛʟʏ ғʀᴏᴍ ᴄʜᴀɴɴᴇʟs ᴡɪᴛʜᴏᴜᴛ ғᴏʀᴡᴀʀᴅɪɴɢ!
"""
    await message.reply_text(help_text, parse_mode=ParseMode.MARKDOWN)
async def process_pdf_with_banner(client, file_path, user_id, original_filename=None):
    """Process PDF with banner and lock settings for ALL rename modes"""
    try:
        pdf_banner_on = await db.get_pdf_banner_mode(user_id)
        pdf_banner_file = await db.get_pdf_banner(user_id)
        pdf_lock_on = await db.get_pdf_lock_mode(user_id) 
        pdf_lock_password = await db.get_pdf_lock_password(user_id)
        pdf_banner_placement = await db.get_pdf_banner_placement(user_id) or "first"

        current_path = file_path
        
        # Apply banner if enabled and banner file exists
        if pdf_banner_on and pdf_banner_file:
            temp_banner_path = f"{file_path}_banner.jpg"
            try:
                await client.download_media(pdf_banner_file, file_name=temp_banner_path)
                if await aiofiles.os.path.exists(temp_banner_path):
                    reader = PdfReader(current_path)
                    writer = PdfWriter()
                    
                    # Process banner image
                    img = Image.open(temp_banner_path).convert("RGB")
                    img_pdf_path = temp_banner_path + ".pdf"
                    img.save(img_pdf_path, "PDF")
                    img_reader = PdfReader(img_pdf_path)
                    img_page = img_reader.pages[0]
                    
                    # Apply placement logic
                    if pdf_banner_placement == "first":
                        writer.add_page(img_page)
                        for page in reader.pages:
                            writer.add_page(page)
                    elif pdf_banner_placement == "last":
                        for page in reader.pages:
                            writer.add_page(page)
                        writer.add_page(img_page)
                    elif pdf_banner_placement == "both":
                        writer.add_page(img_page)
                        for page in reader.pages:
                            writer.add_page(page)
                        writer.add_page(img_page)
                    
                    bannered_pdf_path = current_path.replace(".pdf", "_bannered.pdf")
                    with open(bannered_pdf_path, "wb") as f:
                        writer.write(f)
                    
                    await cleanup_files(temp_banner_path, img_pdf_path)
                    current_path = bannered_pdf_path
                    
            except Exception as banner_error:
                logger.error(f"PDF banner processing failed: {banner_error}")

        # Apply lock if enabled
        if pdf_lock_on and pdf_lock_password:
            try:
                reader = PdfReader(current_path)
                writer = PdfWriter()
                for page in reader.pages:
                    writer.add_page(page)
                writer.encrypt(pdf_lock_password)
                
                locked_pdf_path = current_path.replace(".pdf", "_locked.pdf")
                with open(locked_pdf_path, "wb") as f:
                    writer.write(f)
                
                # Cleanup previous file if it was temporary
                if current_path != file_path:
                    await cleanup_files(current_path)
                
                current_path = locked_pdf_path
                
            except Exception as lock_error:
                logger.error(f"PDF lock processing failed: {lock_error}")

        return current_path
        
    except Exception as e:
        logger.error(f"PDF processing error: {e}")
        return file_path  # Return original on error
# ==================== FIXED AUTO RENAME FUNCTION ====================
@Client.on_message(filters.private & (filters.document | filters.video | filters.audio))
@check_ban_status
async def auto_rename_files(client, message: Message):
    user_id = message.from_user.id
    user = message.from_user

    if ADMIN_MODE and user_id not in ADMINS:
        return await message.reply_text("Aᴅᴍɪɴ ᴍᴏᴅᴇ ɪs ᴀᴄᴛɪᴠᴇ - Oɴʟʏ ᴀᴅᴍɪɴs ᴄᴀɴ ᴜsᴇ ᴛʜɪs ʙᴏᴛ!")
    
    try:
        # Extract file information with enhanced error handling
        if message.document:
            file_id = message.document.file_id
            file_name = message.document.file_name
            file_size = message.document.file_size
            media_type = "document"
            file_ext = os.path.splitext(file_name)[1].lower() if file_name else ".bin"
        elif message.video:
            file_id = message.video.file_id
            file_name = message.video.file_name or f"video_{int(time.time())}.mp4"
            file_size = message.video.file_size
            media_type = "video"
            file_ext = ".mp4"
        elif message.audio:
            file_id = message.audio.file_id
            file_name = message.audio.file_name or f"audio_{int(time.time())}.mp3"
            file_size = message.audio.file_size
            media_type = "audio"
            file_ext = ".mp3"
        else:
            return await message.reply_text("**Uɴsᴜᴘᴘᴏʀᴛᴇᴅ ғɪʟᴇ ᴛʏᴘᴇ**")
                    # FIXED: Clean the original filename BEFORE downloading to remove duplicates
        original_file_name = file_name
        file_name = remove_duplicate_tags_from_filename(file_name)
        
        if file_name != original_file_name:
            logger.info(f"🧹 Cleaned filename: '{original_file_name}' -> '{file_name}'")
            
        # Enhanced file validation
        if not file_size or file_size == 0:
            return await message.reply_text("**❌ Iɴᴠᴀʟɪᴅ ғɪʟᴇ sɪᴢᴇ! Fɪʟᴇ ᴀᴘᴘᴇᴀʀs ᴛᴏ ʙᴇ ᴇᴍᴘᴛʏ.**")
        
        # Check disk space before processing
        disk_usage = shutil.disk_usage("/")
        free_space = disk_usage.free
        if free_space < file_size * 2:  # Need at least 2x file size for processing
            return await message.reply_text(
                f"**❌ Iɴsᴜғғɪᴄɪᴇɴᴛ ᴅɪsᴋ sᴘᴀᴄᴇ!**\n"
                f"**Rᴇǫᴜɪʀᴇᴅ:** {humanbytes(file_size * 2)}\n"
                f"**Aᴠᴀɪʟᴀʙʟᴇ:** {humanbytes(free_space)}"
            )
            
    except Exception as e:
        logger.error(f"Error extracting file info: {e}")
        return await message.reply_text("**❌ Eʀʀᴏʀ ᴇxᴛʀᴀᴄᴛɪɴɢ ғɪʟᴇ ɪɴғᴏʀᴍᴀᴛɪᴏɴ!**")
        
    # Handle sequence mode
    if user_id in active_sequences:
        file_info = {
            "file_id": file_id,
            "file_name": file_name if file_name else "Unknown",
            "file_size": file_size
        }
        active_sequences[user_id].append(file_info)

        now = time.time()
        last_update = last_sequence_update.get(user_id, 0)

        # FIRST message
        if user_id not in sequence_status_msg:
            msg = await message.reply_text(
                "📥 **Sequence Mode Active**\n"
                f"Files Received: **{len(active_sequences[user_id])}**\n"
                "Use /esequence to end."
            )
            sequence_status_msg[user_id] = msg
            last_sequence_update[user_id] = now
            return

        # Update ONLY if 2 seconds passed
        if now - last_update >= 0.5:
            try:
                msg = sequence_status_msg[user_id]
                await msg.edit_text(
                    "📥 **Sequence Mode Active**\n"
                    f"Files Received: **{len(active_sequences[user_id])}**\n"
                    "Use /esequence to end."
                )
                last_sequence_update[user_id] = now
            except:
                pass

        return
        
    async def process_file(file_size_param=None):
        """Process file with enhanced error handling and I/O protection"""
        nonlocal file_id, file_name, media_type, file_ext
        
        # Use provided file size or fallback
        actual_file_size = file_size_param if file_size_param is not None else file_size
        
        try:
            # Check user status and tokens
            user_data = await db.col.find_one({"_id": user_id})
            is_premium = user_data.get("is_premium", False) if user_data else False
            is_admin = user_id in ADMINS

            if is_premium and user_data.get("premium_expiry"):
                if datetime.now() < user_data["premium_expiry"]:
                    is_premium = True
                else:
                    await db.col.update_one(
                        {"_id": user_id},
                        {"$set": {"is_premium": False, "premium_expiry": None}}
                    )
                    is_premium = False

            if not is_premium:
                current_tokens = user_data.get("token", getattr(Config, 'DEFAULT_TOKEN', 0))
                if current_tokens <= 0:
                    await message.reply_text("**Yᴏᴜ'ᴠᴇ ʀᴜɴ ᴏᴜᴛ ᴏғ ᴛᴏᴋᴇɴs!\nGᴇɴᴇʀᴀᴛᴇ ᴍᴏʀᴇ ʙʏ ᴜsɪɴɢ /gentoken ᴄᴍᴅ.**")
                    return
            
            if PREMIUM_MODE and not is_premium:
                current_tokens = user_data.get("token", 0)
                if current_tokens <= 0:
                    return await message.reply_text("**Yᴏᴜ'ᴠᴇ ʀᴜɴ ᴏᴜᴛ ᴏғ ᴛᴏᴋᴇɴs!\nGᴇɴᴇʀᴀᴛᴇ ᴍᴏʀᴇ ʙʏ ᴜsɪɴɢ /gentoken ᴄᴍᴅ.**")
                await db.col.update_one(
                    {"_id": user_id},
                    {"$inc": {"token": -1}}
                )
            
            # Get renaming mode
            mode = await db.get_renaming_mode(user_id) or "autorename"
            msg = await flood_control.safe_reply_text(message, "**Yᴏᴜʀ ꜰɪʟᴇ ʜᴀs ʙᴇᴇɴ ᴀᴅᴅᴇᴅ ᴛᴏ ǫᴜᴇᴜᴇ. Pʟᴇᴀsᴇ Wᴀɪᴛ.......**")
            
            # Handle different renaming modes
            if mode == "manual":
                file_info = {
                    'file_id': file_id,
                    'file_name': file_name,
                    'file_size': actual_file_size,
                    'file_ext': file_ext,
                    'media_type': media_type,
                    'message': msg,
                    'original_message': message,
                    'from_channel': False
                }
                
                # Add to manual queue
                await manual_rename_queue.add_manual_file(user_id, file_info)
                
                # Update queue message
                queue_size = len(manual_rename_queue.pending_manual_files.get(user_id, {}))
                await msg.edit_text(
                    f"**📥 File Added to Manual Rename**\n\n"
                    f"**File:** `{file_name}`\n"
                    f"**Position:** `#{queue_size}` in manual queue\n\n"
                    f"*You'll be prompted for each file name.*",
                    parse_mode=ParseMode.MARKDOWN
                )
                
                # Start manual processing if not already running
                await manual_rename_queue.start_manual_processing(user_id)
                return  # Stop here, wait for user input
            
            elif mode == "replace":
                # Replace mode logic
                old_text, new_text = await db.get_replace_pattern(user_id)
                if not old_text or not new_text:
                    await msg.edit("**Replace mode enabled but no pattern set!**\nUse /replace \"old_text\" \"new_text\" first.")
                    return
                new_filename = file_name.replace(old_text, new_text)
            
            else:  # autorename mode (default)
                # Auto rename logic with enhanced error handling
                try:
                    format_template = await db.get_format_template(user_id)
                    metadata_source = await db.get_metadata_source(user_id)
                    
                    # FIXED: Define source_text properly
                    if metadata_source == "caption" and message.caption:
                        source_text = message.caption
                    else:
                        source_text = file_name
                    
                    # FIXED: Enhanced season/episode extraction with better patterns
                    season, episode = extract_season_episode(source_text)
                    chapter = extract_chapter(source_text)
                    volume = extract_volume(source_text)
                    quality = extract_quality(source_text)

                    # Get CLEAN title
                    clean_title = extract_clean_title(source_text)
                    if not format_template:
                        await msg.edit("**Aᴜᴛᴏ ʀᴇɴᴀᴍᴇ ғᴏʀᴍᴀᴛ ɴᴏᴛ sᴇᴛ\nPʟᴇᴀsᴇ sᴇᴛ ᴀ ʀᴇɴᴀᴍᴇ ғᴏʀᴍᴀᴛ ᴜsɪɴɢ /room**")
                        return

                    # Initialize new_filename with the template
                    new_filename = format_template
                    temp_audio_label = "Sub"

                    # FIXED: Audio detection - use filename-based detection only here
                    filename_audio = _detect_audio_from_filename(source_text)
                    if filename_audio:
                        temp_audio_label = filename_audio

                    replacements = {
                        # Title variations
                        '{title}': clean_title,
                        '{Title}': clean_title,
                        '{TITLE}': clean_title.upper(),
                        # Audio will be updated after download
                        '{audio}': temp_audio_label,
                        '{Audio}': temp_audio_label, 
                        '{AUDIO}': temp_audio_label.upper(),
                        '[Sub]': f'[{temp_audio_label}]',
                        '[SUB]': f'[{temp_audio_label.upper()}]',
                        '(Sub)': f'({temp_audio_label})',
                        'Sub': temp_audio_label,
                        'SUB': temp_audio_label.upper(),
                        '{season}': season or '01',
                        '{episode}': episode or '01',
                        '{chapter}': chapter or '01',
                        '{volume}': volume or '01',
                        '{quality}': quality,
                        '{Season}': season or '01',
                        '{Episode}': episode or '01',
                        '{Chapter}': chapter or '01',
                        '{Volume}': volume or '01',
                        '{Quality}': quality,
                        '{SEASON}': season or '01',
                        '{EPISODE}': episode or '01',
                        '{CHAPTER}': chapter or '01',
                        '{VOLUME}': volume or '01',
                        '{QUALITY}': quality,
                        'Season': season or '01',
                        'Episode': episode or '01',
                        'Chapter': chapter or '01',
                        'Volume': volume or '01',
                        'Quality': quality,
                        'SEASON': season or '01',
                        'EPISODE': episode or '01',
                        'CHAPTER': chapter or '01',
                        'VOLUME': volume or '01',
                        'QUALITY': quality,
                        'season': season or '01',
                        'episode': episode or '01',
                        'chapter': chapter or '01',
                        'volume': volume or '01',
                        'quality': quality,
                    }
                    
                    # Apply replacements to new_filename
                    for placeholder, value in replacements.items():
                        if placeholder in new_filename:
                            new_filename = new_filename.replace(placeholder, value)
                            logger.info(f"   Replaced '{placeholder}' with '{value}'")

                    # Add file extension
                            # FIXED: Remove any duplicate tags after template replacement
                    new_filename = remove_duplicate_tags(new_filename)
                    
                    # Add file extension
                    new_filename = f"{new_filename}{file_ext}"
   
                    
                except Exception as rename_error:
                    logger.error(f"Auto-rename error: {rename_error}")
                    await msg.edit("**❌ Aᴜᴛᴏ ʀᴇɴᴀᴍᴇ ғᴀɪʟᴇᴅ! Usɪɴɢ ᴏʀɪɢɪɴᴀʟ ɴᴀᴍᴇ.**")
                    new_filename = file_name

            # Common processing pipeline for all modes
            await post_rename_process(
                client, message, new_filename, media_type, file_ext, 
                msg, user_id, user, is_premium, file_id, file_name, actual_file_size
            )

        except Exception as e:
            logger.error(f"Processing error: {e}")
            error_msg = f"**❌ Eʀʀᴏʀ ᴘʀᴏᴄᴇssɪɴɢ ғɪʟᴇ:** `{str(e)[:200]}`"
            if 'msg' in locals():
                try:
                    await msg.edit(error_msg)
                    # Auto-delete error message after 30 seconds
                    await asyncio.sleep(30)
                    await msg.delete()
                except:
                    await message.reply_text(error_msg)
            else:
                error_response = await message.reply_text(error_msg)
                await asyncio.sleep(30)
                await error_response.delete()

    # Add task to queue WITH FILE SIZE
    success = await task_queue.add_task(user_id, file_id, message, process_file, file_size)
    
    if not success:
        error_msg = await message.reply_text("**❌ Fᴀɪʟᴇᴅ ᴛᴏ ᴀᴅᴅ ғɪʟᴇ ᴛᴏ ǫᴜᴇᴜᴇ**")
        await asyncio.sleep(15)
        await error_msg.delete()
async def prompt_manual_rename(user_id: int, file_info: dict):
    """Show manual rename prompt for a file - ONE PROMPT PER FILE"""
    try:
        # Check if user is already processing a file
        if await manual_rename_queue.is_user_processing(user_id):
            return  # Don't show multiple prompts
        
        # Mark this file as being processed
        manual_rename_queue.current_processing[user_id] = file_info
        
        # SIMPLIFIED KEYBOARD - NO QUEUE BUTTONS
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("📹 Sample (1min)", callback_data=f"sample_{user_id}_{file_info['queue_id']}"),
                InlineKeyboardButton("🖼️ Screenshots", callback_data=f"screenshots_{user_id}_{file_info['queue_id']}")
            ],
            [
                InlineKeyboardButton("✏️ Rename Now", callback_data=f"rename_{user_id}_{file_info['queue_id']}"),
                InlineKeyboardButton("❌ Skip File", callback_data=f"skip_manual_{user_id}_{file_info['queue_id']}")
            ]
        ])
        
        prompt_msg = await file_info['original_message'].reply_text(
            f"**🎬 Manual Rename Request**\n\n"
            f"**File:** `{file_info['file_name']}`\n"
            f"**Size:** `{humanbytes(file_info['file_size'])}`\n"
            f"**Type:** `{file_info['media_type'].upper()}`\n\n"
            f"**Choose an action:**",
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Store the prompt message
        file_info['prompt_message'] = prompt_msg
        manual_rename_queue.pending_prompts[user_id] = prompt_msg
        
    except Exception as e:
        logger.error(f"Error showing manual rename prompt: {e}")

async def prompt_manual_rename_for_next_file(user_id: int, file_info: dict):
    """Prompt for the next file in queue after completing one"""
    try:
        # Small delay to avoid flooding
        await asyncio.sleep(1)
        await prompt_manual_rename(user_id, file_info)
    except Exception as e:
        logger.error(f"Error prompting for next file: {e}")
async def post_rename_process(client, message, new_filename, media_type, file_ext, msg, user_id, user, is_premium, file_id, original_file_name, file_size, processed_file_path=None, channel_message=None):
    """
    Universal post-rename processing for both forwarded files and channel files
    """
    file_path = processed_file_path
    download_path = None
    metadata_path = None
    thumb_path = None
    output_path = None
    success = False

    # Use UUID for unique identifier
    unique_id = str(uuid.uuid4())[:12]

    try:
        media_preference = await db.get_media_preference(user_id)
        
        # Sanitize filename
        new_filename = sanitize_filename(new_filename)
        if not new_filename or len(new_filename) > 250:
            await msg.edit("**❌ Iɴᴠᴀʟɪᴅ ғɪʟᴇɴᴀᴍᴇ! Usɪɴɢ ᴏʀɪɢɪɴᴀʟ.**")
            new_filename = original_file_name
        
        # File extension logic
        if media_type == "video" and media_preference == "document":
            ext = ".mkv"
        elif media_type == "document" and media_preference == "video":
            ext = ".mp4"
        elif file_ext and file_ext.lower() == ".pdf":
            ext = ".pdf"
        else:
            ext = file_ext or ('.mp4' if media_type == 'video' else '.mp3')
        
        if not new_filename.endswith(ext):
            new_filename = os.path.splitext(new_filename)[0] + ext
        
        safe_filename = new_filename
        
        # If file_path is already provided (from channel download), use it directly
        if file_path and os.path.exists(file_path):
            logger.info(f"Using pre-downloaded file: {file_path}")
        else:
            # Download the file (for regular forwarded files)
            download_path = f"downloads/{unique_id}_{safe_filename}"
            metadata_path = f"metadata/{unique_id}_{safe_filename}"
            output_path = f"processed/{unique_id}_{safe_filename}"

            # Create directories with permission check
            await create_directories(["downloads", "metadata", "processed"])
            
            # Disk space check
            disk_usage = shutil.disk_usage("/")
            if disk_usage.free < file_size * 5:
                raise Exception(f"Insufficient disk space. Required: {humanbytes(file_size * 5)}, Available: {humanbytes(disk_usage.free)}")
            
            # Download with logging
            await flood_control.safe_edit_message(msg, "**📥 Dᴏᴡɴʟᴏᴀᴅɪɴɢ...**")
            logger.info(f"Starting download to {download_path} for file_id {file_id}")
            
            # Choose download source: channel_message or regular message
            if channel_message:
                # Download from channel message
                file_path = await client.download_media(
                    channel_message,
                    file_name=download_path,
                    progress=progress_for_pyrogram,
                    progress_args=("**Dᴏᴡɴʟᴏᴀᴅɪɴɢ...**", msg, time.time())
                )
            else:
                # Download from regular message
                file_path = await client.download_media(
                    message,
                    file_name=download_path,
                    progress=progress_for_pyrogram,
                    progress_args=("**Dᴏᴡɴʟᴏᴀᴅɪɴɢ...**", msg, time.time())
                )
            actual_audio_label = "Sub"  # Initialize with default

            try:
                await flood_control.safe_edit_message(msg, "**🎵 Detecting audio...**")

                # FIXED: Initialize file_exists properly
                file_exists = False
                if file_path:
                    try:
                        file_exists = await aiofiles.os.path.exists(file_path)
                    except Exception as path_error:
                        logger.warning(f"Error checking file existence: {path_error}")
                        file_exists = False

                if file_exists and file_path:
                    # Real probe detection
                    audio_info = await detect_audio_info(file_path)
                    actual_audio_label = get_audio_label(audio_info)
                    logger.info(f"🎵 Audio detected from file: {actual_audio_label}")
                else:
                    # Fallback to filename detection
                    filename_audio = _detect_audio_from_filename(original_file_name)
                    if filename_audio:
                        actual_audio_label = filename_audio
                        logger.info(f"🎵 Audio detected from filename: {actual_audio_label}")
                    else:
                        actual_audio_label = "Sub"
                        logger.info("🎵 No audio info found, using 'Sub'")

            except Exception as audio_error:
                logger.warning(f"Audio detection failed: {audio_error}")
                actual_audio_label = "Sub"

            # Apply audio label to filename
            new_filename = apply_audio_to_filename(new_filename, actual_audio_label)
            logger.info(f"✅ Final filename with audio: {new_filename}")

            # Enhanced download verification
            if not file_path or not file_exists:
                raise Exception("Download failed - file not found")

            # Verify file size and integrity
            actual_size = await get_file_size(file_path)
            if actual_size == 0:
                raise Exception("Downloaded file is empty")
            
            if actual_size < file_size * 0.8:  # If less than 80% of expected size
                logger.warning(f"File size mismatch: expected {file_size}, got {actual_size}")
            
            await asyncio.sleep(1)
            await flood_control.safe_edit_message(msg, "**✅ Dᴏᴡɴʟᴏᴀᴅ Cᴏᴍᴘʟᴇᴛᴇ**")

    
        await flood_control.safe_edit_message(msg, "**🔄 Pʀᴏᴄᴇssɪɴɢ ғɪʟᴇ...**")
        
        # Handle media conversion based on preference with error handling
        original_file_path = file_path  # Keep reference to original
        if media_type == "video" and media_preference == "document":
            try:
                await convert_to_mkv(file_path, output_path)
                file_path = output_path
                logger.info(f"Successfully converted to MKV: {output_path}")
            except Exception as conversion_error:
                await msg.edit(f"**⚠️ Vɪᴅᴇᴏ ᴄᴏɴᴠᴇʀsɪᴏɴ ғᴀɪʟᴇᴅ, ᴜsɪɴɢ ᴏʀɪɢɪɴᴀʟ:** `{conversion_error}`")
                file_path = original_file_path

        # Add metadata for supported file types with error handling
        if media_type in ["video", "audio"] or (media_type == "document" and file_ext != ".pdf"):
            try:
                await flood_control.safe_edit_message(msg, "**📝 Aᴅᴅɪɴɢ ᴍᴇᴛᴀᴅᴀᴛᴀ...**")
                metadata_result = await add_metadata(file_path, metadata_path, user_id)
                if metadata_result and await aiofiles.os.path.exists(metadata_result):
                    file_path = metadata_result
                    logger.info("Metadata added successfully")
                else:
                    logger.warning("Metadata addition failed, using original file")
            except Exception as metadata_error:
                await msg.edit(f"**⚠️ Mᴇᴛᴀᴅᴀᴛᴀ ғᴀɪʟᴇᴅ, ᴄᴏɴᴛɪɴᴜɪɴɢ:** `{metadata_error}`")

        # Handle PDF processing with error handling
        elif media_type == "document" and file_ext == ".pdf":
            try:
                # Use the centralized PDF processing function
                processed_pdf_path = await process_pdf_with_banner(client, file_path, user_id, original_file_name)
                if processed_pdf_path != file_path:
                    file_path = processed_pdf_path
                    logger.info("PDF banner/lock processing applied successfully")
                    
            except Exception as pdf_error:
                logger.error(f"PDF processing failed: {pdf_error}")
                # Continue with original file

        # Prepare for upload
        await flood_control.safe_edit_message(msg, "**📤 Pʀᴇᴘᴀʀɪɴɢ ᴜᴘʟᴏᴀᴅ...**")
        caption = await db.get_caption(message.chat.id) or f"**{new_filename}**"
        thumb = await db.get_thumbnail(message.chat.id)
        thumb_path = None

        if thumb:
            try:
                thumb_path = await client.download_media(thumb)
            except Exception as thumb_error:
                logger.warning(f"Thumbnail download failed: {thumb_error}")
        elif media_type == "video" and hasattr(message, 'video') and message.video and message.video.thumbs:
            try:
                thumb_path = await client.download_media(message.video.thumbs[0].file_id)
            except Exception as thumb_error:
                logger.warning(f"Thumbnail download failed: {thumb_error}")

        # Upload file with retry logic
        await flood_control.safe_edit_message(msg, "**🚀 Uᴘʟᴏᴀᴅɪɴɢ...**")
        max_upload_attempts = 3
        
        for attempt in range(max_upload_attempts):
            try:
                upload_params = {
                    'chat_id': message.chat.id,
                    'caption': caption,
                    'thumb': thumb_path,
                    'progress': progress_for_pyrogram,
                    'progress_args': ("Uᴘʟᴏᴀᴅɪɴɢ...", msg, time.time()),
                    'file_name': new_filename
                }

                if file_ext in (
                    ".pdf", ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
                    ".odt", ".rtf", ".csv", ".epub", ".mobi", ".zip", ".rar", ".7z",
                    ".xml", ".html", ".json", ".md", ".log", ".ini", ".bat", ".sh"
                ):
                    await client.send_document(
                        document=file_path,
                        **upload_params
                    )
                elif media_type == "video":
                    if media_preference == "video":
                        await client.send_video(
                            video=file_path,
                            **upload_params
                        )
                    else:
                        await client.send_document(
                            document=file_path,
                            force_document=True,
                            **upload_params
                        )
                elif media_type == "document":
                    if media_preference == "video":
                        await client.send_video(
                            video=file_path,
                            **upload_params
                        )
                    else:
                        await client.send_document(
                            document=file_path,
                            **upload_params
                        )
                elif media_type == "audio":
                    await client.send_audio(
                        audio=file_path,
                        **upload_params
                    )
                
                success = True
                break
                
            except FloodWait as flood:
                wait_time = flood.value + 2
                await flood_control.safe_edit_message(msg, f"**⏳ Flood wait, retrying in {wait_time}s...**")
                await asyncio.sleep(wait_time)
                continue
            except Exception as upload_error:
                if attempt < max_upload_attempts - 1:
                    await msg.edit(f"**⚠️ Upload failed (attempt {attempt + 1}), retrying...**")
                    await asyncio.sleep(2)
                    continue
                else:
                    raise upload_error
        
        if success:
            # Update database statistics
            await db.col.update_one(
                {"_id": user_id},
                {
                    "$inc": {
                        "rename_count": 1,
                        "files_processed_count": 1,
                        "total_renamed_size": file_size,
                        "daily_count": 1
                    },
                    "$max": {
                        "max_file_size": file_size
                    }
                }
            )

            # Log the rename operation
            await db.add_rename_log_entry(
                user_id, 
                original_name=original_file_name, 
                renamed_name=new_filename,
                file_size=file_size
            )
            await db.add_rename_history(user_id, original_name=original_file_name, renamed_name=new_filename)
            
            # Send to dump channel if configured
            if hasattr(Config, 'DUMP') and Config.DUMP and hasattr(Config, 'DUMP_CHANNEL'):
                try:
                    ist = pytz.timezone('Asia/Kolkata')
                    current_time = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S IST")
                    
                    full_name = user.first_name
                    if user.last_name:
                        full_name += f" {user.last_name}"
                    username = f"@{user.username}" if user.username else "N/A"
                    premium_status = '🗸' if is_premium else '✘'
                    
                    dump_caption = (
                        f"» Usᴇʀ Dᴇᴛᴀɪʟs «\n"
                        f"ID: {user_id}\n"
                        f"Nᴀᴍᴇ: {full_name}\n"
                        f"Usᴇʀɴᴀᴍᴇ: {username}\n"
                        f"Pʀᴇᴍɪᴜᴍ: {premium_status}\n"
                        f"Tɪᴍᴇ: {current_time}\n"
                        f"Oʀɪɢɪɴᴀʟ Fɪʟᴇɴᴀᴍᴇ: {original_file_name}\n"
                        f"Rᴇɴᴀᴍᴇᴅ Fɪʟᴇɴᴀᴍᴇ: {new_filename}"
                    )
                    
                    dump_channel = Config.DUMP_CHANNEL
                    await asyncio.sleep(1.2)
                    
                    if media_type == "document":
                        await client.send_document(
                            chat_id=dump_channel,
                            document=file_path,
                            caption=dump_caption,
                            file_name=new_filename
                        )
                    elif media_type == "video":
                        await client.send_video(
                            chat_id=dump_channel,
                            video=file_path,
                            caption=dump_caption,
                            file_name=new_filename
                        )
                    elif media_type == "audio":
                        await client.send_audio(
                            chat_id=dump_channel,
                            audio=file_path,
                            caption=dump_caption,
                            file_name=new_filename
                        )
                except Exception as dump_error:
                    logger.error(f"Error sending to dump channel: {dump_error}")

            await msg.delete()
            
        else:
            await msg.edit(f"**❌ Uᴘʟᴏᴀᴅ ғᴀɪʟᴇᴅ ᴀғᴛᴇʀ {max_upload_attempts} ᴀᴛᴛᴇᴍᴘᴛs**")
            raise Exception("Upload failed after all retry attempts")

    except Exception as e:
        error_message = f"**❌ Eʀʀᴏʀ:** `{str(e)[:200]}`"
        await flood_control.safe_edit_message(msg, error_message)
        await asyncio.sleep(30)
        await flood_control.safe_delete_message(msg)
    finally:
        try:
            # Only clean up if we created these paths (not for pre-downloaded files)
            if not processed_file_path:
                await cleanup_files(download_path, metadata_path, thumb_path, output_path, file_path)
        except Exception as cleanup_error:
            logger.error(f"Cleanup error: {cleanup_error}")
        
        renaming_operations.pop(file_id, None)
        
        if not success:
            logger.info(f"Rename operation failed for user {user_id}, file {original_file_name}")
# ==================== FIXED HELPER FUNCTIONS ====================
async def check_disk_space(required_size: int) -> bool:
    """Check if there's enough disk space"""
    try:
        disk_usage = shutil.disk_usage("/")
        return disk_usage.free >= required_size
    except Exception as e:
        logger.error(f"Disk space check failed: {e}")
        return False

async def verify_file_integrity(file_path: str, expected_size: int = None) -> bool:
    """Verify file integrity and size"""
    try:
        if not await aiofiles.os.path.exists(file_path):
            return False
            
        actual_size = await get_file_size(file_path)
        
        if expected_size and actual_size < expected_size * 0.8:
            logger.warning(f"File size mismatch: expected {expected_size}, got {actual_size}")
            return False
            
        return actual_size > 0
    except Exception as e:
        logger.error(f"File integrity check failed: {e}")
        return False

async def safe_file_operation(operation, *args, max_retries=3, **kwargs):
    """Execute file operations with retry logic"""
    last_error = None
    for attempt in range(max_retries):
        try:
            return await operation(*args, **kwargs)
        except OSError as e:
            if e.errno == 5:  # Input/output error
                last_error = e
                if attempt < max_retries - 1:
                    await asyncio.sleep(2 ** attempt)  # Exponential backoff
                    continue
            raise
        except Exception as e:
            last_error = e
            if attempt < max_retries - 1:
                await asyncio.sleep(2 ** attempt)
                continue
            raise
    
    if last_error:
        raise last_error

@Client.on_message(filters.command("health") & filters.private)
@check_ban_status
async def system_health(client, message: Message):
    """Check system health and disk status"""
    try:
        # Disk usage
        disk = shutil.disk_usage("/")
        disk_total = humanbytes(disk.total)
        disk_used = humanbytes(disk.used)
        disk_free = humanbytes(disk.free)
        disk_percent = (disk.used / disk.total) * 100
        
        # Memory usage
        memory = psutil.virtual_memory()
        mem_total = humanbytes(memory.total)
        mem_used = humanbytes(memory.used)
        mem_percent = memory.percent
        
        # CPU usage
        cpu_percent = psutil.cpu_percent(interval=1)
        
        # Check critical directories
        directories = ["downloads", "metadata", "processed"]
        dir_status = []
        
        for directory in directories:
            try:
                if os.path.exists(directory):
                    dir_size = sum(os.path.getsize(os.path.join(dirpath, filename))
                                 for dirpath, dirnames, filenames in os.walk(directory)
                                 for filename in filenames)
                    dir_status.append(f"✅ {directory}: {humanbytes(dir_size)}")
                else:
                    dir_status.append(f"❌ {directory}: Missing")
            except Exception as e:
                dir_status.append(f"⚠️ {directory}: Error ({str(e)})")
        
        health_report = [
            "**🩺 Sʏsᴛᴇᴍ Hᴇᴀʟᴛʜ Rᴇᴘᴏʀᴛ**",
            "",
            "**💾 Dɪsᴋ Sᴛᴀᴛᴜs:**",
            f"• Total: {disk_total}",
            f"• Used: {disk_used} ({disk_percent:.1f}%)",
            f"• Free: {disk_free}",
            "",
            "**🧠 Mᴇᴍᴏʀʏ Sᴛᴀᴛᴜs:**",
            f"• Total: {mem_total}",
            f"• Used: {mem_used} ({mem_percent:.1f}%)",
            "",
            "**⚡ Cᴘᴜ Sᴛᴀᴛᴜs:**",
            f"• Usage: {cpu_percent}%",
            "",
            "**📁 Dɪʀᴇᴄᴛᴏʀʏ Sᴛᴀᴛᴜs:**"
        ]
        
        health_report.extend(dir_status)
        
        # Add warnings
        if disk_percent > 90:
            health_report.append("\n**🚨 WARNING: Disk space critically low!**")
        elif disk_percent > 80:
            health_report.append("\n**⚠️ WARNING: Disk space running low!**")
            
        if mem_percent > 90:
            health_report.append("**🚨 WARNING: Memory usage critically high!**")
        
        await message.reply_text("\n".join(health_report))
        
    except Exception as e:
        await message.reply_text(f"**❌ Health check failed:** `{str(e)}`")
async def create_directories(dirs):
    """Create necessary directories"""
    for directory in dirs:
        try:
            await aiofiles.os.makedirs(directory, exist_ok=True)
        except Exception as e:
            logger.error(f"Error creating directory {directory}: {e}")

async def get_file_size(file_path: str) -> int:
    """Get file size safely"""
    try:
        if await aiofiles.os.path.exists(file_path):
            stat = await aiofiles.os.stat(file_path)
            return stat.st_size
    except Exception as e:
        logger.error(f"Error getting file size for {file_path}: {e}")
    return 0

def sanitize_filename(filename: str) -> str:
    """Sanitize filename to remove invalid characters"""
    if not filename:
        return f"file_{int(time.time())}"
    
    # Remove invalid characters for filenames
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # Limit length
    if len(filename) > 200:
        name, ext = os.path.splitext(filename)
        filename = name[:200-len(ext)] + ext
    
    return filename

async def cleanup_files(*paths):
    """Clean up temporary files safely"""
    for path in paths:
        try:
            if path and await aiofiles.os.path.exists(path):
                await aiofiles.os.remove(path)
        except Exception as e:
            logger.error(f"Error removing {path}: {e}")

# ==================== FIXED MANUAL RENAME HANDLING ====================
# FIXED manual rename input handler with proper message deletion
@Client.on_message(filters.private & filters.text & ~filters.regex(r'^/'))
async def handle_manual_name_input(client, message: Message):
    """Handle manual filename input from users"""
    user_id = message.from_user.id
    
    # Check if user is waiting for manual input
    if user_id not in manual_rename_queue.waiting_for_input:
        return  # No active manual rename
    
    current_file = manual_rename_queue.waiting_for_input[user_id]
    new_filename = message.text.strip()
    file_id = current_file['file_id']
    
    # Delete the user's input message immediately
    try:
        await message.delete()
    except Exception as e:
        logger.warning(f"Could not delete user input message: {e}")
    
    # Also delete the rename prompt message if it exists
    if 'prompt_message' in current_file:
        try:
            await current_file['prompt_message'].delete()
        except Exception as e:
            logger.warning(f"Could not delete rename prompt: {e}")
    
    # Validate filename
    if not new_filename or len(new_filename) > 250:
        error_msg = await message.reply_text(
            f"**❌ Invalid filename!**\n\n"
            f"**Please enter a valid filename (1-250 characters):**",
            parse_mode=ParseMode.MARKDOWN
        )
        await asyncio.sleep(10)
        try:
            await error_msg.delete()
        except:
            pass
        return
    
    # Add file extension if missing
    original_ext = current_file.get('file_ext')
    if original_ext and not new_filename.endswith(original_ext):
        new_filename += original_ext
    
    # Show processing message
    processing_msg = await message.reply_text("**🔄 Processing manual rename...**")
    
    # Process the manual rename using TaskQueue
    async def process_manual_rename_task(file_size_param=None):
        """Process manual rename in TaskQueue"""
        try:
            user_data = await db.col.find_one({"_id": user_id})
            is_premium = user_data.get("is_premium", False) if user_data else False
            
            await post_rename_process(
                client, 
                current_file['original_message'],
                new_filename, 
                current_file['media_type'], 
                current_file['file_ext'], 
                processing_msg,  # Use the processing message
                user_id, 
                message.from_user, 
                is_premium,
                current_file['file_id'], 
                current_file['file_name'],
                current_file['file_size']
            )
            
            # Log manual rename
            await db.log_manual_rename(user_id, current_file['file_name'], new_filename)
            
            # Auto-delete processing message after success
            await asyncio.sleep(5)
            try:
                await processing_msg.delete()
            except:
                pass
            
        except Exception as e:
            logger.error(f"Manual rename processing error: {e}")
            await processing_msg.edit_text(f"**❌ Manual rename failed:** `{str(e)[:200]}`")
            await asyncio.sleep(15)
            try:
                await processing_msg.delete()
            except:
                pass
        finally:
            # Complete this file and process next
            await manual_rename_queue.complete_manual_file(user_id, file_id)
            await manual_rename_queue.start_manual_processing(user_id)
    
    # Add manual rename to TaskQueue
    success = await task_queue.add_task(
        user_id, 
        f"manual_{file_id}", 
        message, 
        process_manual_rename_task,
        current_file['file_size']
    )
    
    if not success:
        error_msg = await message.reply_text("**❌ Failed to process manual rename**")
        await asyncio.sleep(10)
        await error_msg.delete()

async def process_manual_rename(client, message, file_info):
    """Process manual rename with proper progress tracking"""
    user_id = message.from_user.id
    
    # Show processing message with file details
    processing_msg = await message.reply_text(
        f"""
**🔄 Processing Manual Rename...**

**Original Name:** `{file_info['file_name']}`
**New Name:** `{file_info['manual_filename']}`
**Size:** `{humanbytes(file_info.get('file_size', 0))}`
        """,
        parse_mode=ParseMode.MARKDOWN
    )
    
    try:
        # Extract file information
        file_id = file_info['file_id']
        original_file_name = file_info['file_name']
        media_type = file_info['media_type']
        file_ext = file_info['file_ext']
        new_filename = file_info['manual_filename']
        file_size = file_info.get('file_size', 0)
        
        # Get user data for premium status
        user_data = await db.col.find_one({"_id": user_id})
        is_premium = user_data.get("is_premium", False) if user_data else False
        
        # Process the file using the same pipeline as auto rename
        await post_rename_process(
            client, 
            file_info['original_message'],  # Use original message
            new_filename, 
            media_type, 
            file_ext, 
            processing_msg,  # Use the processing message for updates
            user_id, 
            message.from_user, 
            is_premium,
            file_id, 
            original_file_name,
            file_size  # Pass file_size parameter
        )
        # Log manual rename
        await db.log_manual_rename(user_id, original_file_name, new_filename)
        
        # Auto-delete success message after 5 seconds
        await asyncio.sleep(5)
        try:
            await processing_msg.delete()
        except:
            pass
        
    except Exception as e:
        error_msg = await processing_msg.edit_text(
            f"**❌ Manual Rename Failed!**\n\n"
            f"**Original Name:** `{file_info['file_name']}`\n"
            f"**New Name:** `{file_info['manual_filename']}`\n\n"
            f"**Error:** `{str(e)}`",
            parse_mode=ParseMode.MARKDOWN
        )

        # Auto-delete error message after 15 seconds
        await asyncio.sleep(15)
        try:
            await error_msg.delete()
        except:
            pass

@Client.on_callback_query(filters.regex(r"^cancel_manual_(\d+)$"))
async def cancel_manual_rename(client, callback_query: CallbackQuery):
    user_id = int(callback_query.data.split("_")[2])
    if callback_query.from_user.id != user_id:
        await callback_query.answer("This is not for you!", show_alert=True)
        return
    
    if user_id in manual_rename_queue:
        del manual_rename_queue[user_id]
    if user_id in pending_manual_requests:
        del pending_manual_requests[user_id]
    
    await callback_query.message.edit_text("**❌ Mᴀɴᴜᴀʟ ʀᴇɴᴀᴍᴇ ᴄᴀɴᴄᴇʟʟᴇᴅ!**")
    await callback_query.answer("Manual rename cancelled!")

async def generate_screenshots(client, callback_query, file_info, user_id):
    """Generate high-quality screenshots without terminal spam"""
    file_path = None
    output_dir = None
    processing_msg = None
    
    try:
        # Answer callback immediately to prevent expiration
        try:
            await callback_query.answer("🖼️ Generating screenshots...")
        except:
            pass  # Ignore if callback already expired
        
        processing_msg = await callback_query.message.reply_text("**🖼️ Generating high-quality screenshots...**")
        
        # Download the file
        file_path = await client.download_media(
            file_info['file_id'],
            file_name=f"downloads/{user_id}_{int(time.time())}.mp4"
        )
        
        # Get video info silently
        duration, video_info = await get_video_metadata_silent(file_path)
        if not duration or duration < 10:
            raise Exception("Video too short or invalid")
        
        # Create output directory
        output_dir = f"ss_{user_id}_{int(time.time())}"
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate high-quality screenshots
        collage_path = await generate_hq_screenshots(file_path, output_dir, duration)
        
        if collage_path and os.path.exists(collage_path):
            # Create final image with metadata
            final_image_path = await create_metadata_image(collage_path, file_info, video_info, output_dir)
            
            if final_image_path:
                # Send final image silently
                caption = f"**🎬 {file_info['file_name']}**"
                await client.send_photo(
                    callback_query.message.chat.id,
                    final_image_path,
                    caption=caption
                )
                
                await callback_query.answer("✅ Screenshots generated!")
            else:
                # Send just the collage if metadata fails
                await client.send_photo(
                    callback_query.message.chat.id,
                    collage_path,
                    caption=f"**🎬 {file_info['file_name']}**"
                )
        else:
            raise Exception("Failed to generate screenshots")
        
    except Exception as e:
        # Silent error handling - no terminal spam
        try:
            error_msg = await callback_query.message.reply_text(
                f"**❌ Could not generate screenshots**\n`File may be too short or corrupted`"
            )
            await asyncio.sleep(10)
            await error_msg.delete()
        except:
            pass
    
    finally:
        # Silent cleanup
        try:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
            if output_dir and os.path.exists(output_dir):
                shutil.rmtree(output_dir, ignore_errors=True)
            if processing_msg:
                await processing_msg.delete()
        except:
            pass

async def get_video_metadata_silent(file_path):
    """Get video metadata without terminal output"""
    try:
        cmd = [
            'ffprobe', '-v', 'quiet', '-print_format', 'json',
            '-show_format', '-show_streams', file_path
        ]
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        if process.returncode == 0:
            import json
            data = json.loads(stdout.decode())
            
            # Get duration from format or video stream
            duration = float(data['format']['duration']) if 'duration' in data['format'] else 0
            
            # Get video stream info
            video_stream = next((s for s in data['streams'] if s['codec_type'] == 'video'), {})
            
            video_info = {
                'duration': duration,
                'resolution': f"{video_stream.get('width', 0)}x{video_stream.get('height', 0)}",
                'codec': video_stream.get('codec_name', 'Unknown').upper(),
                'bitrate': humanbytes(int(data['format'].get('bit_rate', 0))) if data['format'].get('bit_rate') else 'Unknown',
                'size': humanbytes(int(data['format'].get('size', 0))) if data['format'].get('size') else 'Unknown'
            }
            
            return duration, video_info
            
    except:
        pass
    
    return None, {}

async def generate_hq_screenshots(file_path, output_dir, duration):
    """Generate high-quality screenshots without FFmpeg spam"""
    try:
        # Calculate positions (avoid edges)
        num_shots = 12  # Reduced for better quality
        positions = [(duration * (i + 1)) / (num_shots + 1) for i in range(num_shots)]
        
        screenshots = []
        
        for i, pos in enumerate(positions):
            output_file = os.path.join(output_dir, f"img_{i+1:02d}.jpg")
            
            # High-quality FFmpeg command with quiet output
            cmd = [
                'ffmpeg', '-v', 'quiet', '-ss', str(pos),
                '-i', file_path, '-vframes', '1', '-qscale:v', '1',
                '-y', output_file
            ]
            
            process = await asyncio.create_subprocess_exec(*cmd)
            await process.wait()
            
            if os.path.exists(output_file) and os.path.getsize(output_file) > 5000:
                screenshots.append(output_file)
        
        if len(screenshots) >= 6:  # Minimum 6 screenshots
            return await create_hq_collage(screenshots, output_dir)
        
    except:
        pass
    
    return None

async def create_hq_collage(screenshot_paths, output_dir):
    """Create high-quality collage"""
    try:
        images = []
        for path in screenshot_paths[:12]:  # Max 12 images
            try:
                img = Image.open(path)
                # High quality resize
                img = img.resize((400, 225), Image.Resampling.LANCZOS)
                images.append(img)
            except:
                continue
        
        if not images:
            return None
        
        # 4x3 grid for high quality
        cols = 4
        rows = min(3, (len(images) + cols - 1) // cols)
        
        img_width, img_height = 400, 225
        collage_width = cols * img_width
        collage_height = rows * img_height
        
        # Create white background collage
        collage = Image.new('RGB', (collage_width, collage_height), (255, 255, 255))
        
        for i, img in enumerate(images):
            if i >= cols * rows:
                break
            row = i // cols
            col = i % cols
            x = col * img_width
            y = row * img_height
            collage.paste(img, (x, y))
        
        collage_path = os.path.join(output_dir, "collage_hq.jpg")
        collage.save(collage_path, "JPEG", quality=95, optimize=True)
        
        return collage_path
        
    except:
        return None

async def create_metadata_image(collage_path, file_info, video_info, output_dir):
    """Create image with metadata header"""
    try:
        collage = Image.open(collage_path)
        c_width, c_height = collage.size
        
        # Metadata header
        header_height = 180
        final_width = c_width
        final_height = header_height + c_height
        
        final_img = Image.new('RGB', (final_width, final_height), (255, 255, 255))
        draw = ImageDraw.Draw(final_img)
        
        # Try to load font
        try:
            font_large = ImageFont.truetype("arial.ttf", 24)
            font_medium = ImageFont.truetype("arial.ttf", 18)
            font_small = ImageFont.truetype("arial.ttf", 14)
        except:
            font_large = font_medium = font_small = ImageFont.load_default()
        
        y = 20
        
        # Title
        title = f"🎬 {file_info['file_name'][:40]}{'...' if len(file_info['file_name']) > 40 else ''}"
        draw.text((20, y), title, fill=(0, 0, 0), font=font_large)
        y += 40
        
        # Metadata
        infos = [
            f"📦 Size: {humanbytes(file_info.get('file_size', 0))}",
            f"⏱️ Duration: {time.strftime('%H:%M:%S', time.gmtime(video_info.get('duration', 0)))}",
            f"🖼️ Resolution: {video_info.get('resolution', 'Unknown')}",
            f"🔧 Codec: {video_info.get('codec', 'Unknown')}",
        ]
        
        for info in infos:
            draw.text((20, y), info, fill=(80, 80, 80), font=font_medium)
            y += 30
        
        # Paste collage
        final_img.paste(collage, (0, header_height))
        
        final_path = os.path.join(output_dir, "final.jpg")
        final_img.save(final_path, "JPEG", quality=95, optimize=True)
        
        return final_path
        
    except:
        return collage_path  # Return original collage if metadata fails

# Updated humanbytes function (make sure it exists)
def humanbytes(size: int) -> str:
    """Convert bytes to human readable format"""
    if not size:
        return "0 B"
    
    units = ["B", "KB", "MB", "GB", "TB"]
    unit_index = 0
    
    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1
    
    return f"{size:.2f} {units[unit_index]}"

# Updated sample generation function with proper cleanup
async def generate_sample(client, callback_query, file_info, user_id):
    file_path = None
    sample_path = None
    processing_msg = None
    
    try:
        processing_msg = await callback_query.message.reply_text("**📹 Creating 1-minute sample...**")
        
        # Download the file
        file_path = await client.download_media(
            file_info['file_id'],
            file_name=f"downloads/{user_id}_{file_info['file_name']}"
        )
        
        # Get video duration
        ffprobe_cmd = [
            'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
            '-of', 'default=noprint_wrappers=1:nokey=1', file_path
        ]
        
        process = await asyncio.create_subprocess_exec(
            *ffprobe_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        duration = float(stdout.decode().strip())
        
        # Determine sample segment (middle of video)
        sample_duration = 60  # 1 minute
        start_time = max(0, (duration - sample_duration) / 2)
        
        # Create sample
        sample_path = f"sample_{user_id}.mp4"
        ffmpeg_cmd = [
            'ffmpeg', '-ss', str(start_time), '-i', file_path,
            '-t', str(sample_duration), '-c', 'copy', '-y', sample_path
        ]
        
        process = await asyncio.create_subprocess_exec(*ffmpeg_cmd)
        await process.wait()
        
        if os.path.exists(sample_path):
            # Send sample video
            sent_message = await client.send_video(
                callback_query.message.chat.id,
                sample_path,
                caption=f"**📹 1-minute sample from {file_info['file_name']}**",
                duration=int(sample_duration),
                reply_to_message_id=callback_query.message.id
            )
            
            # Delete processing message
            if processing_msg:
                await processing_msg.delete()
            
            # Auto-delete sample message after 60 seconds (longer for video)
            await asyncio.sleep(1000)
            try:
                await sent_message.delete()
            except:
                pass
            
            await callback_query.answer("Sample sent! Message will auto-delete.")
        
    except Exception as e:
        if processing_msg:
            error_msg = await processing_msg.edit_text(f"**❌ Error generating sample:** `{str(e)}`")
            # Auto-delete error message
            await asyncio.sleep(10)
            try:
                await error_msg.delete()
            except:
                pass
        logger.error(f"Sample generation error: {e}")
    
    finally:
        # COMPLETE CLEANUP
        # Cleanup sample file
        if sample_path and os.path.exists(sample_path):
            try:
                os.remove(sample_path)
            except:
                pass
        
        # Cleanup downloaded file
        if file_path and os.path.exists(file_path):
            try:
                os.remove(file_path)
            except:
                pass
        
        # Cleanup processing message if still exists
        if processing_msg:
            try:
                await processing_msg.delete()
            except:
                pass

# ==================== FIXED CALLBACK HANDLER ====================
# FIXED callback handler with proper message deletion
@Client.on_callback_query(filters.regex(r"^(sample|ss|ren|skip)_(\d+)_(.+)$"))
async def handle_manual_options(client, callback_query: CallbackQuery):
    try:
        data_parts = callback_query.data.split("_")
        action = data_parts[0]
        user_id = int(data_parts[1])
        short_file_id = data_parts[2]
        
        if callback_query.from_user.id != user_id:
            await callback_query.answer("This is not for you!", show_alert=True)
            return
        
        # Get current file by short ID
        current_file = await manual_rename_queue.get_file_by_short_id(user_id, short_file_id)
        if not current_file:
            await callback_query.answer("File not found!", show_alert=True)
            return
        
        # DELETE THE MENU MESSAGE FIRST
        await callback_query.message.delete()
        
        # Map actions to full names
        action_map = {
            'ss': 'screenshots',
            'ren': 'rename',
            'skip': 'skip_manual'
        }
        action_full = action_map.get(action, action)
        
        if action_full == "skip_manual":
            await manual_rename_queue.skip_manual_file(user_id, short_file_id)
            await callback_query.answer("File skipped!")
        
        elif action_full == "rename":
            rename_prompt = await callback_query.message.reply_text(
                f"**✏️ Manual Rename**\n\n"
                f"**File:** `{current_file['file_name']}`\n"
                f"**Size:** `{humanbytes(current_file['file_size'])}`\n\n"
                f"**Please enter the new filename:**",
                parse_mode=ParseMode.MARKDOWN
            )
            current_file['prompt_message'] = rename_prompt
            await callback_query.answer("Enter new filename...")
        
        elif action_full == "screenshots":
            await callback_query.answer("Generating screenshots...")
            await generate_screenshots(client, callback_query, current_file, user_id)
        
        elif action_full == "sample":
            await callback_query.answer("Creating sample...")
            await generate_sample(client, callback_query, current_file, user_id)
    
    except Exception as e:
        logger.error(f"Error in manual options: {e}")
        await callback_query.answer("An error occurred!", show_alert=True)

async def process_next_manual_file(client, user_id: int):
    """Process the next file in manual rename queue"""
    try:
        # Complete current file first
        await manual_rename_queue.complete_current_file(user_id)
        
        # Get next file
        next_file = await manual_rename_queue.process_next_file(user_id)
        if next_file:
            await asyncio.sleep(1)  # Small delay between files
            await prompt_manual_rename(user_id, next_file)
        else:
            # No more files, cleanup
            manual_rename_queue.cleanup_user(user_id)
            
    except Exception as e:
        logger.error(f"Error processing next manual file: {e}")

async def process_thumbnail(thumb_path):
    if not thumb_path or not await aiofiles.os.path.exists(thumb_path):
        return None
    try:
        img = await asyncio.to_thread(Image.open, thumb_path)
        img = await asyncio.to_thread(lambda: img.convert("RGB").resize((320, 320)))
        await asyncio.to_thread(img.save, thumb_path, "JPEG")
        return thumb_path
    except Exception as e:
        logger.error(f"Thumbnail processing failed: {e}")
        await cleanup_files(thumb_path)
        return None

async def cleanup_files(*paths):
    for path in paths:
        try:
            if path and await aiofiles.os.path.exists(path):
                await aiofiles.os.remove(path)
        except Exception as e:
            logger.error(f"Error removing {path}: {e}")

async def add_metadata(input_path, output_path, user_id):
    """Add metadata to media files with comprehensive fallback strategies."""

    # Verify FFmpeg availability
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise RuntimeError("FFmpeg not found in PATH")

    # Ensure directories exist
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    # Verify input file exists
    if not os.path.exists(input_path):
        raise RuntimeError(f"Input file does not exist: {input_path}")

    # Fetch metadata fields
    metadata = {
        'title': await db.get_title(user_id) or "Untitled",
        'video': await db.get_video(user_id) or "Video Track",
        'audio': await db.get_audio(user_id) or "Audio Track",
        'subtitle': await db.get_subtitle(user_id) or "Subtitle Track",
        'artist': await db.get_artist(user_id) or "Unknown Artist",
        'author': await db.get_author(user_id) or "Unknown Author",
        'encoded_by': await db.get_encoded_by(user_id) or Config.BOT_NAME,
        'custom_tag': await db.get_custom_tag(user_id) or "",
        'commentz': await db.get_commentz(user_id) or ""
    }

    # Safe temp file name
    file_ext = os.path.splitext(output_path)[1].lower()
    temp_output = f"{output_path}.temp{file_ext}"

    # Determine output format (default MKV)
    format_map = {
        '.mp4': 'mp4', '.mkv': 'matroska', '.avi': 'avi', '.mov': 'mov',
        '.wmv': 'asf', '.flv': 'flv', '.webm': 'webm', '.m4v': 'mp4',
        '.3gp': '3gp', '.mp3': 'mp3', '.flac': 'flac', '.wav': 'wav',
        '.aac': 'adts', '.ogg': 'ogg', '.wma': 'asf'
    }
    output_format = format_map.get(file_ext, 'matroska')

    # Build metadata attempts (progressively simpler)
    metadata_attempts = [
        [
            ffmpeg, '-hide_banner', '-i', input_path,
            '-map', '0', '-c', 'copy',
            '-metadata', f'title={metadata["title"]}',
            '-metadata:s:v', f'title={metadata["video"]}',
            '-metadata:s:a', f'title={metadata["audio"]}',
            '-metadata:s:s', f'title={metadata["subtitle"]}',
            '-metadata', f'artist={metadata["artist"]}',
            '-metadata', f'author={metadata["author"]}',
            '-metadata', f'encoded_by={metadata["encoded_by"]}',
            '-metadata', f'comment={metadata["commentz"]}',
            '-metadata', f'custom_tag={metadata["custom_tag"]}',
            '-f', output_format, '-loglevel', 'error', '-y', temp_output
        ],
        [
            ffmpeg, '-hide_banner', '-i', input_path,
            '-map', '0', '-c', 'copy',
            '-metadata', f'title={metadata["title"]}',
            '-metadata', f'artist={metadata["artist"]}',
            '-metadata', f'author={metadata["author"]}',
            '-metadata', f'encoded_by={metadata["encoded_by"]}',
            '-f', output_format, '-loglevel', 'error', '-y', temp_output
        ],
        [
            ffmpeg, '-hide_banner', '-i', input_path,
            '-map', '0', '-c', 'copy',
            '-metadata', f'title={metadata["title"]}',
            '-f', output_format, '-loglevel', 'error', '-y', temp_output
        ],
        [
            ffmpeg, '-hide_banner', '-i', input_path,
            '-map', '0', '-c', 'copy',
            '-f', output_format, '-loglevel', 'error', '-y', temp_output
        ]
    ]

    last_error = None
    success = False

    # Attempt metadata application with fallbacks
    for attempt_num, cmd in enumerate(metadata_attempts, 1):
        try:
            if os.path.exists(temp_output):
                os.remove(temp_output)

            logger.info(f"Metadata attempt {attempt_num} with format {output_format}")
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await process.communicate()

            if process.returncode == 0 and os.path.exists(temp_output):
                success = True
                logger.info(f"Metadata attempt {attempt_num} succeeded")
                break
            else:
                error_msg = (stderr or b"").decode(errors="ignore").strip()
                last_error = error_msg
                logger.warning(f"Metadata attempt {attempt_num} failed: {error_msg}")

        except Exception as e:
            last_error = str(e)
            logger.warning(f"Metadata attempt {attempt_num} exception: {e}")

    # If all attempts failed, fallback to raw copy
    if not success:
        logger.error(f"All metadata attempts failed. Last error: {last_error}")
        try:
            shutil.copy2(input_path, output_path)
            logger.info("Fallback copy succeeded (no metadata applied).")
            return output_path
        except Exception as e:
            logger.error(f"Even fallback copy failed: {e}")
            raise RuntimeError(f"Metadata addition failed: {last_error}")

    # Move temp to final file
    try:
        if os.path.exists(temp_output):
            if os.path.exists(output_path):
                os.remove(output_path)
            shutil.move(temp_output, output_path)
            logger.info(f"Metadata successfully added: {output_path}")
        return output_path

    except Exception as e:
        logger.error(f"Final move failed: {e}")
        if not os.path.exists(output_path) and os.path.exists(input_path):
            shutil.copy2(input_path, output_path)
            logger.warning("Returned original file after final failure.")
        return output_path
def apply_audio_to_filename(filename, audio_label):
    """Apply audio label to filename - FIXED to handle extensions properly"""
    if not audio_label or audio_label == "Sub":
        return remove_duplicate_tags_from_filename(filename)
    
    print(f"🎵 Applying audio label: '{audio_label}' to '{filename}'")
    
    # Separate filename and extension FIRST
    name_without_ext, file_ext = os.path.splitext(filename)
    
    # Clean the filename part (without extension)
    clean_name = remove_duplicate_tags_from_filename(name_without_ext)
    
    print(f"🎵 After cleaning: '{clean_name}'")
    
    # Remove existing audio tags from the clean name
    audio_patterns_to_remove = [
        r'\[Sub\]', r'\[SUB\]', r'\[sub\]',
        r'\[Dub\]', r'\[DUB\]', r'\[dub\]', 
        r'\[Multi\]', r'\[MULTI\]', r'\[multi\]',
        r'\[Dual\]', r'\[DUAL\]', r'\[dual\]',
        r'\(Sub\)', r'\(SUB\)', r'\(sub\)',
        r'\(Dub\)', r'\(DUB\)', r'\(dub\)',
    ]
    
    for pattern in audio_patterns_to_remove:
        clean_name = re.sub(pattern, '', clean_name, flags=re.IGNORECASE)
    
    # Clean up
    clean_name = re.sub(r'\s+', ' ', clean_name).strip()
    clean_name = re.sub(r'\s*\[\s*\]', '', clean_name)
    clean_name = re.sub(r'\s*\(\s*\)', '', clean_name)
    clean_name = clean_name.strip()
    
    print(f"🎵 After audio tag removal: '{clean_name}'")
    
    # Apply audio label to the clean name (not the extension)
    result_name = clean_name
    
    # Check if we should add audio tag
    should_add_audio = True
    
    # If the name already ends with audio tag, replace it
    audio_end_patterns = [
        r'\[Sub\]$', r'\[Dub\]$', r'\[Multi\]$', r'\[Dual\]$',
        r'\(Sub\)$', r'\(Dub\)$', r'\(Multi\)$', r'\(Dual\)$',
    ]
    
    for pattern in audio_end_patterns:
        if re.search(pattern, result_name, re.IGNORECASE):
            result_name = re.sub(pattern, f'[{audio_label}]', result_name, flags=re.IGNORECASE)
            should_add_audio = False
            print(f"🎵 Replaced existing audio tag: '{result_name}'")
            break
    
    # If no existing audio tag found, add it at the end
    if should_add_audio:
        result_name = f"{result_name} [{audio_label}]"
        print(f"🎵 Added audio tag: '{result_name}'")
    
    # Final cleanup
    result_name = remove_duplicate_tags(result_name)
    
    # Combine with extension
    final_filename = f"{result_name}{file_ext}"
    
    print(f"🎵 Final filename: '{final_filename}'")
    return final_filename

def remove_duplicate_tags(filename):
    if not filename:
        return filename

    clean_name = filename

    # Step 1: Normalize audio/quality tags (Sub, Multi, Dual, Dub)
    audio_tags = ["sub", "multi", "dual", "dub"]
    qualities = ["360p", "480p", "720p", "1080p", "2160p"]

    for q in qualities:
        for tag in audio_tags:
            # Match optional 264/bdrip/10bit + audio tag, ignore case, ignore spaces
            pattern = rf'\[\s*{q}\s*(?:\d{{3,4}}p)?\s*(?:\d{{2}}bit)?\s*(?:bdrip\s*)?{tag}\s*\]'
            replacement = f'[{q}] [{tag.capitalize()}]'
            clean_name = re.sub(pattern, replacement, clean_name, flags=re.IGNORECASE)

    # Step 2: Normalize standalone audio tags (like [sub], [multi])
    for tag in audio_tags:
        pattern = rf'\[\s*{tag}\s*\]'
        replacement = f'[{tag.capitalize()}]'
        clean_name = re.sub(pattern, replacement, clean_name, flags=re.IGNORECASE)

    # Step 3: Remove duplicate audio tags (like [Sub] [Sub])
    clean_name = re.sub(r'\[(Sub|Multi|Dual|Dub)\](\s*\[\1\])+', r'[\1]', clean_name, flags=re.IGNORECASE)

    # Step 4: Remove duplicate quality tags (like [720p] [720p])
    for q in qualities:
        clean_name = re.sub(rf'\[{q}\](\s*\[{q}\])+', f'[{q}]', clean_name, flags=re.IGNORECASE)

    # Step 5: Remove empty brackets
    clean_name = re.sub(r'\[\s*\]', '', clean_name)

    # Step 6: Remove common format tags (BDRip, WEBRip, etc.)
    format_tags = ["BDRip", "BDrip", "BluRay", "WEBRip", "WebRip", "WEB-DL", "HDTV", "DVDRip"]
    for tag in format_tags:
        clean_name = re.sub(rf'\b{tag}\b', '', clean_name, flags=re.IGNORECASE)

    # Step 7: Cleanup multiple spaces
    clean_name = re.sub(r'\s+', ' ', clean_name).strip()

    return clean_name

def extract_chapter(filename): 
    """Extract chapter number from filename with decimal support"""
    if not filename:
        return None

    patterns = [
        # Decimal chapter patterns - UPDATED
        r'Ch[\.\s\-_]?(\d+\.\d+)',  # Ch2.4, Ch 2.4, Ch-2.4, Ch_2.4
        r'Chapter[\.\s\-_]?(\d+\.\d+)',  # Chapter2.4, Chapter 2.4
        r'CH[\.\s\-_]?(\d+\.\d+)',  # CH2.4, CH 2.4
        r'ch[\.\s\-_]?(\d+\.\d+)',  # ch2.4, ch 2.4
        r'Chap[\.\s\-_]?(\d+\.\d+)',  # Chap2.4, Chap 2.4
        r'\[Ch[\.\s\-_]?(\d+\.\d+)\]',  # [Ch2.4], [Ch-2.4]
        r'\[Chapter[\.\s\-_]?(\d+\.\d+)\]',  # [Chapter2.4]
        
        # Standard chapter patterns (keep existing)
        r'Ch(\d+)', r'Chapter(\d+)', r'CH(\d+)', 
        r'ch(\d+)', r'Chap(\d+)', r'chap(\d+)',
        r'Ch\.(\d+)', r'Chapter\.(\d+)', r'CH\.(\d+)',
        r'ch\.(\d+)', r'Chap\.(\d+)', r'chap\.(\d+)',
        r'Ch-(\d+)', r'Chapter-(\d+)', r'CH-(\d+)',
        r'ch-(\d+)', r'Chap-(\d+)', r'chap-(\d+)',
        r'CH-(\d+)', r'CHAP-(\d+)', r'CHAPTER (\d+)',
        r'Ch (\d+)', r'Chapter (\d+)', r'CH (\d+)',
        r'ch (\d+)', r'Chap (\d+)', r'chap (\d+)',
        r'\[Ch(\d+)\]', r'\[Chapter(\d+)\]', r'\[CH(\d+)\]',
        r'\[ch(\d+)\]', r'\[Chap(\d+)\]', r'\[chap(\d+)\]',
        r'\[C(\d+)\]',
        
        # Standalone decimal numbers (common in PDFs)
        r'\b(\d+\.\d+)\b',  # 2.4, 15.5, etc.
        r'\[(\d+\.\d+)\]',  # [2.4], [15.5]
        r'\((\d+\.\d+)\)',  # (2.4), (15.5)
    ]
    
    for pattern in patterns:
        match = re.search(pattern, filename, re.IGNORECASE)
        if match:
            chapter_str = match.group(1)
            try:
                # Return as string to preserve decimal formatting
                return chapter_str
            except:
                continue
    
    return None
def extract_volume(filename):
    """Extract volume number from filename"""
    if not filename:
        return None

    patterns = [
        r'\[V(?:ol(?:ume)?)?[._ -]?(\d+)\]',
        r'V(?:ol(?:ume)?)?[._ -]?(\d+)',
        r'\bvol(?:ume)?[._ -]?(\d+)\b',
        r'\bvol(?:ume)?\s*(\d+)\b',
        r'\(vol(?:ume)?[._ -]?(\d+)\)',
        r'\bV\s*[\.:_-]?\s*(\d+)\b',
        r'\bVol\s*[\.:_-]?\s*(\d+)\b',
        r'\bVolume\s*[\.:_-]?\s*(\d+)\b'
    ]

    for pattern in patterns:
        match = re.search(pattern, filename, re.IGNORECASE)
        if match:
            return match.group(1).zfill(2)

    return None

@Client.on_message(filters.command("renamed") & (filters.group | filters.private))
@check_ban_status
async def renamed_stats(client, message: Message):
    try:
        args = message.command[1:] if len(message.command) > 1 else []
        target_user = None
        requester_id = message.from_user.id
        time_filter = "lifetime"
        
        requester_data = await db.col.find_one({"_id": requester_id})
        is_premium = requester_data.get("is_premium", False) if requester_data else False
        is_admin = requester_id in ADMINS

        if is_premium and requester_data.get("premium_expiry"):
            if datetime.now() > requester_data["premium_expiry"]:
                is_premium = False
                await db.col.update_one(
                    {"_id": requester_id},
                    {"$set": {"is_premium": False}}
                )

        if args:
            try:
                if args[0].startswith("@"):
                    user = await client.get_users(args[0])
                    target_user = user.id
                else:
                    target_user = int(args[0])
            except:
                await message.reply_text("**Iɴᴠᴀʟɪᴅ ғᴏʀᴍᴀᴛ! Usᴇ /renamed [@username|user_id]**")
                return

        if target_user and not (is_admin or is_premium):
            return await message.reply_text("**Pʀᴇᴍɪᴜᴍ ᴏʀ ᴀᴅᴍɪɴ ʀᴇǫᴜɪʀᴇᴅ ᴛᴏ ᴠɪᴇᴡ ᴏᴛʜᴇʀs' sᴛᴀᴛs!**")

        await show_stats(client, message, target_user, time_filter, is_admin, is_premium, requester_id)

    except Exception as e:
        error_msg = await message.reply_text(f"❌ Error: {str(e)}")
        await asyncio.sleep(30)
        await error_msg.delete()
        logger.error(f"Stats error: {e}", exc_info=True)

async def show_stats(client, message, target_user, time_filter, is_admin, is_premium, requester_id):
    try:
        now = datetime.now()
        date_filter = None
        period_text = "Lɪғᴇᴛɪᴍᴇ"
        
        if time_filter == "today":
            date_filter = {"$gte": datetime.combine(now.date(), datetime.min.time())}
            period_text = "Tᴏᴅᴀʏ"
        elif time_filter == "week":
            start_of_week = now - timedelta(days=now.weekday())
            date_filter = {"$gte": datetime.combine(start_of_week.date(), datetime.min.time())}
            period_text = "Tʜɪs Wᴇᴇᴋ"
        elif time_filter == "month":
            start_of_month = datetime(now.year, now.month, 1)
            date_filter = {"$gte": start_of_month}
            period_text = "Tʜɪs Mᴏɴᴛʜ"
        elif time_filter == "year":
            start_of_year = datetime(now.year, 1, 1)
            date_filter = {"$gte": start_of_year}
            period_text = "Tʜɪs Yᴇᴀʀ"
        
        if target_user:
            user_data = await db.col.find_one({"_id": target_user})
            if not user_data:
                return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
            
            if date_filter:
                rename_logs = await db.rename_logs.find({
                    "user_id": target_user,
                    "timestamp": date_filter
                }).to_list(length=None)
                
                rename_count = len(rename_logs)
                total_renamed_size = sum(log.get("file_size", 0) for log in rename_logs)
                max_file_size = max([log.get("file_size", 0) for log in rename_logs] or [0])
            else:
                rename_count = user_data.get('rename_count', 0)
                total_renamed_size = user_data.get('total_renamed_size', 0)
                max_file_size = user_data.get('max_file_size', 0)

            response = [
                f"**┌─── ∘° {period_text} Sᴛᴀᴛs °∘ ───┐**",
                f"**➤ Usᴇʀ: {target_user}**",
                f"**➤ Tᴏᴛᴀʟ Rᴇɴᴀᴍᴇs: {rename_count}**",
                f"**➤ Tᴏᴛᴀʟ Sɪᴢᴇ: {humanbytes(total_renamed_size)}**",
                f"**➤ Mᴀx Fɪʟᴇ Sɪᴢᴇ: {humanbytes(max_file_size)}**",
                f"**➤ Pʀᴇᴍɪᴜᴍ Sᴛᴀᴛᴜs: {'Active' if user_data.get('is_premium') else 'Inactive'}**"
            ]
            
            if is_admin or is_premium:
                response.append(f"**➤ Tᴏᴋᴇɴs: {user_data.get('token', 0)}**")
                response.append(f"**└───────── °∘ ❉ ∘° ───────┘**")

        else:
            user_data = await db.col.find_one({"_id": requester_id})
            if not user_data:
                user_data = {}
                
            if date_filter:
                rename_logs = await db.rename_logs.find({
                    "user_id": requester_id,
                    "timestamp": date_filter
                }).to_list(length=None)
                
                rename_count = len(rename_logs)
                total_renamed_size = sum(log.get("file_size", 0) for log in rename_logs)
                max_file_size = max([log.get("file_size", 0) for log in rename_logs] or [0])
            else:
                rename_count = user_data.get('rename_count', 0)
                total_renamed_size = user_data.get('total_renamed_size', 0)
                max_file_size = user_data.get('max_file_size', 0)
                
            response = [
                f"**┌─── ∘° Yᴏᴜʀ {period_text} Sᴛᴀᴛs °∘ ───┐**",
                f"**➤ Tᴏᴛᴀʟ Rᴇɴᴀᴍᴇs: {rename_count}**",
                f"**➤ Tᴏᴛᴀʟ Sɪᴢᴇ: {humanbytes(total_renamed_size)}**",
                f"**➤ Mᴀx Fɪʟᴇ Sɪᴢᴇ: {humanbytes(max_file_size)}**",
                f"**➤ Pʀᴇᴍɪᴜᴍ Sᴛᴀᴛᴜs: {'Active' if is_premium else 'Inactive'}**",
                f"**➤ Rᴇᴍᴀɪɴɪɴɢ Tᴏᴋᴇɴs: {user_data.get('token', 0)}**",
                f"**└──────── °∘ ❉ ∘° ─────────┘**"
            ]

            if (is_admin or is_premium) and time_filter == "lifetime":
                pipeline = [{"$group": {
                    "_id": None,
                    "total_renames": {"$sum": "$rename_count"},
                    "total_size": {"$sum": "$total_renamed_size"},
                    "max_size": {"$max": "$max_file_size"},
                    "user_count": {"$sum": 1}
                }}]
                stats = (await db.col.aggregate(pipeline).to_list(1))[0]
                
                response.extend([
                    f"\n<blockquote>**┌─── ∘° Gʟᴏʙᴀʟ Sᴛᴀᴛs °∘ ───┐**</blockquote>",
                    f"**➤ Tᴏᴛᴀʟ Usᴇʀs: {stats['user_count']}**",
                    f"**➤ Tᴏᴛᴀʟ Fɪʟᴇs: {stats['total_renames']}**",
                    f"**➤ Tᴏᴛᴀʟ Sɪᴢᴇ: {humanbytes(stats['total_size'])}**",
                    f"**➤ Lᴀʀɢᴇsᴛ Fɪʟᴇ: {humanbytes(stats['max_size'])}**",
                    f"**<blockquote>**└─────── °∘ ❉ ∘° ────────┘**</blockquote>**"
                ])

        reply = await message.reply_text("\n".join(response))
        
        if message.chat.type != "private":
            await asyncio.sleep(getattr(Config, 'RENAMED_DELETE_TIMER', 30))
            await reply.delete()
            await message.delete()

    except Exception as e:
        error_msg = await message.reply_text(f"❌ Error: {str(e)}")
        await asyncio.sleep(30)
        await error_msg.delete()
        logger.error(f"Stats error: {e}", exc_info=True)

@Client.on_callback_query(filters.regex(r"^renamed_filter:"))
async def renamed_filter_callback(client, callback_query):
    try:
        data_parts = callback_query.data.split(":")
        time_filter = data_parts[1]
        user_id = int(data_parts[2])
        
        requester_id = callback_query.from_user.id
        
        requester_data = await db.col.find_one({"_id": requester_id})
        is_premium = requester_data.get("is_premium", False) if requester_data else False
        is_admin = requester_id in ADMINS
        
        target_user = None
        if user_id != requester_id:
            if is_admin or is_premium:
                target_user = user_id
            else:
                await callback_query.answer("Yᴏᴜ ᴄᴀɴɴᴏᴛ ᴠɪᴇᴡ ᴏᴛʜᴇʀ ᴜsᴇʀs' sᴛᴀᴛs!", show_alert=True)
                return
        
        await show_stats(client, callback_query.message, target_user, time_filter, is_admin, is_premium, requester_id)
        
        await callback_query.answer()
        
    except Exception as e:
        await callback_query.answer(f"Error: {str(e)}", show_alert=True)
        logger.error(f"Callback error: {e}", exc_info=True)

@Client.on_message(filters.command("info") & (filters.group | filters.private))
@check_ban_status
async def system_info(client, message: Message):
    try:
        total_users = await db.col.count_documents({})
        active_30d = await db.col.count_documents({
            "last_active": {"$gte": datetime.now() - timedelta(days=30)}
        })
        active_24h = await db.col.count_documents({
            "last_active": {"$gte": datetime.now() - timedelta(hours=24)}
        })
        
        storage_pipeline = [
            {"$group": {
                "_id": None,
                "total_size": {"$sum": "$total_renamed_size"},
                "total_files": {"$sum": "$rename_count"}
            }}
        ]
        storage_stats = await db.col.aggregate(storage_pipeline).to_list(1)
        
        cpu_usage = psutil.cpu_percent()
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        boot_time = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
        
        response = f"""
<blockquote>「 🔍 Sʏsᴛᴇᴍ Iɴғᴏ 」</blockquote>


<blockquote>┍─**[Usᴇʀ Sᴛᴀᴛɪsᴛɪᴄs]**
├─**Tᴏᴛᴀʟ Usᴇʀs = {total_users:,}**
├─**Tᴏᴛᴀʟ Fɪʟᴇs Rᴇɴᴀᴍᴇᴅ = {storage_stats[0].get('total_files', 0) if storage_stats else 0}**
┕─**Tᴏᴛᴀʟ Sᴛᴏʟᴀɢᴇ Usᴇᴅ = {humanbytes(storage_stats[0].get('total_size', 0)) if storage_stats else '0 B'}**</blockquote>

<blockquote>┍─**[Sʏsᴛᴇᴍ Iɴғᴏʀᴍᴀᴛɪᴏɴ]**
├─**OS Vᴇʀsɪᴏɴ = {system()} {release()}**
├─**Pʏᴛʜᴏɴ Vᴇʀsɪᴏɴ = {python_version()}**
├─**CPU Usᴀɢᴇ = {cpu_usage}%**
├─**Mᴇᴜᴍᴏʀʏ Usᴀɢᴇ = {humanbytes(mem.used)} / {humanbytes(mem.total)}**
├─**Dɪsᴋ Usᴀɢᴇ = {humanbytes(disk.used)} / {humanbytes(disk.total)}**
┕─**Uᴘᴛɪᴍᴇ = {datetime.now() - datetime.fromtimestamp(psutil.boot_time())}**</blockquote>

<blockquote>┍─**[Vᴇʀsɪᴏɴ Iɴғᴏʀᴍᴀᴛɪᴏɴ]**
├─**Bᴏᴛ Vᴇʀsɪᴏɴ = ****{getattr(Config, 'VERSION', 'Unknown')}**
├─**Lᴀsᴛ Uᴘᴅᴀᴛᴇᴅ = ****{getattr(Config, 'LAST_UPDATED', 'Unknown')}**
┕─**Dᴀᴛᴀʙᴀsᴇ Vᴇʀsɪᴏɴ =** **{getattr(Config, 'DB_VERSION', 'Unknown')}**</blockquote>

<blockquote>╘══════════**「 {Config.BOT_NAME} 」**══════════╛</blockquote>
    """
        await message.reply_text(response)

    except Exception as e:
        await message.reply_text(f"Eʀʀᴏʀ: {str(e)}")
        logger.error(f"System info error: {e}", exc_info=True)

@Client.on_message(filters.command("leaderboard") & (filters.group | filters.private))
@check_ban_status
async def leaderboard_cmd(client, message: Message):
    try:
        # Get time filter from command arguments
        args = message.text.split()
        time_filter = args[1].lower() if len(args) > 1 else "lifetime"
        
        if time_filter not in ["today", "week", "month", "year", "lifetime"]:
            time_filter = "lifetime"
        
        await show_leaderboard(client, message, time_filter)
        
    except Exception as e:
        error_msg = await message.reply_text(f"❌ Error: {str(e)}")
        await asyncio.sleep(30)
        await error_msg.delete()
        logger.error(f"Leaderboard error: {e}", exc_info=True)
        
async def show_leaderboard(client, message, time_filter="lifetime", edit=False):
    try:
        now = datetime.now()
        period_text = {
            "today": "Tᴏᴅᴀʏ",
            "week": "Tʜɪs Wᴇᴇᴋ", 
            "month": "Tʜɪs Mᴏɴᴛʜ",
            "year": "Tʜɪs Yᴇᴀʀ",
            "lifetime": "Lɪғᴇᴛɪᴍᴇ"
        }.get(time_filter, "Lɪғᴇᴛɪᴍᴇ")
        
        # Get top renamers - USING FIXED METHODS
        top_renamers_data = await db.get_leaderboard_renames(10, time_filter)
        top_sorted_data = await db.get_leaderboard_sorted(10, time_filter)
        
        # Build leaderboard message
        response = [f"**🏆 Lᴇᴀᴅᴇʀʙᴏᴀʀᴅ ({period_text}) 🏆**", ""]
        
        # Top Renamers section
        response.append("**📊 Tᴏᴘ Rᴇɴᴀᴍᴇʀs:**")
        if top_renamers_data:
            for i, user_data in enumerate(top_renamers_data, 1):
                user_id = user_data["_id"]
                user_info = await db.col.find_one({"_id": user_id}) or {}
                
                username = user_info.get("username", "Unknown")
                first_name = user_info.get("first_name", "Unknown User")
                display_name = f"@{username}" if username != "Unknown" else first_name
                
                rename_count = user_data.get("rename_count", 0)
                total_size = user_data.get("total_size", 0)
                
                response.append(
                    f"**{i}. {display_name}** - "
                    f"**{rename_count}** files, "
                    f"**{humanbytes(total_size)}**"
                )
        else:
            response.append("**Nᴏ ʀᴇɴᴀᴍᴇ ᴅᴀᴛᴀ ᴀᴠᴀɪʟᴀʙʟᴇ**")
        
        response.append("")
        
        # Top Sorted Files section
        response.append("**🎬 Tᴏᴘ Fɪʟᴇ Sᴏʀᴛᴇʀs:**")
        if top_sorted_data:
            for i, user_data in enumerate(top_sorted_data, 1):
                user_id = user_data["_id"]
                user_info = await db.col.find_one({"_id": user_id}) or {}
                
                username = user_info.get("username", "Unknown")
                first_name = user_info.get("first_name", "Unknown User")
                display_name = f"@{username}" if username != "Unknown" else first_name
                
                sorted_count = user_data.get("sorted_count", 0)
                sequence_count = user_data.get("sequence_count", 0)
                
                response.append(
                    f"**{i}. {display_name}** - "
                    f"**{sorted_count}** files in **{sequence_count}** sequences"
                )
        else:
            response.append("**Nᴏ sᴏʀᴛᴇᴅ ᴅᴀᴛᴀ ᴀᴠᴀɪʟᴀʙʟᴇ**")
        
        response.append("")
        response.append("**💡 Tɪᴘ:** Use `/leaderboard today|week|month|year|lifetime` to filter")
        
        # Add filter buttons
        buttons = [
            [
                InlineKeyboardButton("📅 Tᴏᴅᴀʏ", callback_data=f"leaderboard_filter:today"),
                InlineKeyboardButton("📆 Wᴇᴇᴋ", callback_data=f"leaderboard_filter:week")
            ],
            [
                InlineKeyboardButton("📊 Mᴏɴᴛʜ", callback_data=f"leaderboard_filter:month"),
                InlineKeyboardButton("🎯 Yᴇᴀʀ", callback_data=f"leaderboard_filter:year")
            ],
            [
                InlineKeyboardButton("🌟 Lɪғᴇᴛɪᴍᴇ", callback_data=f"leaderboard_filter:lifetime")
            ]
        ]
        
        if edit:
            await message.edit_text("\n".join(response), reply_markup=InlineKeyboardMarkup(buttons))
        else:
            reply = await message.reply_text("\n".join(response), reply_markup=InlineKeyboardMarkup(buttons))
            
            if message.chat.type != "private":
                await asyncio.sleep(getattr(Config, 'LEADERBOARD_DELETE_TIMER', 120))
                try:
                    await reply.delete()
                    await message.delete()
                except:
                    pass

    except Exception as e:
        error_msg = await message.reply_text(f"❌ Error: {str(e)}")
        await asyncio.sleep(30)
        await error_msg.delete()
        logger.error(f"Leaderboard error: {e}", exc_info=True)
        
@Client.on_callback_query(filters.regex(r"^leaderboard_filter:(today|week|month|year|lifetime)$"))
async def leaderboard_filter_callback(client, callback_query):
    try:
        time_filter = callback_query.matches[0].group(1)
        
        # Answer the callback immediately
        await callback_query.answer(f"Showing {time_filter} leaderboard")
        
        # Then process the request
        await show_leaderboard(client, callback_query.message, time_filter, edit=True)
        
    except Exception as e:
        await callback_query.answer(f"Error: {str(e)}", show_alert=True)
        logger.error(f"Leaderboard callback error: {e}", exc_info=True)

# FIXED cleanup function with correct attribute names
async def cleanup_manual_requests():
    """Clean up expired manual rename requests every minute"""
    while True:
        try:
            current_time = datetime.now()
            expired_users = []
            
            # Check user_prompts instead of pending_prompts
            for user_id, prompt_msg in list(manual_rename_queue.user_prompts.items()):
                try:
                    # If prompt is older than 10 minutes, cleanup
                    if (current_time - prompt_msg.date).total_seconds() > 600:
                        expired_users.append(user_id)
                except:
                    # If we can't get the date, cleanup anyway
                    expired_users.append(user_id)
            
            for user_id in expired_users:
                manual_rename_queue.cleanup_user(user_id)
                logger.info(f"Cleaned up expired manual requests for user {user_id}")
            
            await asyncio.sleep(60)
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
            await asyncio.sleep(60)

# Add this helper function to handle datetime conversions
def safe_datetime_convert(date_obj):
    """Safely convert datetime objects for MongoDB"""
    if isinstance(date_obj, datetime):
        return date_obj
    elif isinstance(date_obj, str):
        try:
            return datetime.fromisoformat(date_obj.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            return datetime.now()
    return datetime.now()   
# Add to TaskQueue class
async def get_global_queue_status(self) -> dict:
    """Get global queue statistics"""
    total_queued = sum(len(q) for q in self.queues.values())
    total_processing = sum(len(p) for p in self.processing.values())
    active_users = len(self.active_processors)
    
    return {
        "total_queued": total_queued,
        "total_processing": total_processing,
        "active_users": active_users,
        "user_queues": {
            user_id: len(queue) for user_id, queue in self.queues.items()
        }
    }

async def pause_user_queue(self, user_id: int) -> bool:
    """Pause a user's queue"""
    if user_id in self.active_processors:
        for task in self.active_processors[user_id]:
            if not task.done():
                task.cancel()
        return True
    return False

async def resume_user_queue(self, user_id: int) -> bool:
    """Resume a user's queue"""
    if user_id not in self.active_processors and user_id in self.queues:
        concurrency_limit = CON_LIMIT_ADMIN if user_id in ADMINS else CON_LIMIT_NORMAL
        USER_SEMAPHORES[user_id] = asyncio.Semaphore(concurrency_limit)
        
        self.active_processors[user_id] = []
        for i in range(concurrency_limit):
            processor_task = asyncio.create_task(
                self._process_user_queue(user_id, f"processor_{user_id}_{i}")
            )
            self.active_processors[user_id].append(processor_task)
        return True
    return False

@Client.on_message(filters.command("queue_stats") & filters.private)
@check_ban_status
async def queue_stats_admin(client, message: Message):
    """Admin command to view global queue statistics"""
    user_id = message.from_user.id
    if user_id not in ADMINS:
        return await message.reply_text("**Admin only command!**")
    
    global_status = await task_queue.get_global_queue_status()
    
    stats_text = [
        "**🌐 Global Queue Statistics**",
        f"**Total Queued:** `{global_status['total_queued']}` files",
        f"**Total Processing:** `{global_status['total_processing']}` files", 
        f"**Active Users:** `{global_status['active_users']}` users",
        "",
        "**User Queue Details:**"
    ]
    
    for user_id, queue_size in list(global_status['user_queues'].items())[:10]:  # Top 10
        user_data = await db.col.find_one({"_id": user_id}) or {}
        username = user_data.get('username', f'User{user_id}')
        stats_text.append(f"`{username}`: `{queue_size}` files")
    
    if len(global_status['user_queues']) > 10:
        stats_text.append(f"*... and {len(global_status['user_queues']) - 10} more users*")
    
    await message.reply_text("\n".join(stats_text))

@Client.on_message(filters.command("pause_queue") & filters.private)
@check_ban_status
async def pause_queue_cmd(client, message: Message):
    """Pause user's queue"""
    user_id = message.from_user.id
    
    if await task_queue.pause_user_queue(user_id):
        await message.reply_text("**⏸️ Your queue has been paused!**")
    else:
        await message.reply_text("**ℹ️ No active queue to pause!**")

@Client.on_message(filters.command("resume_queue") & filters.private)
@check_ban_status
async def resume_queue_cmd(client, message: Message):
    """Resume user's queue"""
    user_id = message.from_user.id
    
    if await task_queue.resume_user_queue(user_id):
        await message.reply_text("**▶️ Your queue has been resumed!**")
    else:
        await message.reply_text("**ℹ️ No paused queue to resume!**")
@Client.on_message(filters.command("set_pdf_banner_place"))
@check_ban_status
async def set_pdf_banner_place_cmd(client, message: Message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2 or args[1].strip().lower() not in ("first", "last", "both"):
        return await message.reply(
            "**Usᴀɢᴇ:** `/set_pdf_banner_place first|last|both`\n"
            "**Sᴇᴛ ᴡʜᴇʀᴇ ʏᴏᴜʀ PDF ʙᴀɴɴᴇʀ ᴡɪʟʟ ʙᴇ ᴀᴅᴅᴇᴅ ʙʏ ᴅᴇғᴀᴜʟᴛ.**"
        )
    placement = args[1].strip().lower()
    await DARKXSIDE78.set_pdf_banner_placement(message.from_user.id, placement)
    await message.reply(f"**PDF ʙᴀɴɴᴇʀ ᴘʟᴀᴄᴇᴍᴇɴᴛ sᴇᴛ ᴛᴏ:** `{placement}`")

@Client.on_message(
    filters.command(["mode_pdf", "modepdf", "pdfmode", "pdf_mode"]) & (filters.private | filters.group)
)
@check_ban_status
async def pdf_mode_settings(client, message, edit=False, user_id=None):
    if user_id is None:
        user_id = getattr(message, "from_user", None)
        if user_id:
            user_id = user_id.id
        else:
            user_id = message.chat.id

    pdf_banner_on = await DARKXSIDE78.get_pdf_banner_mode(user_id)
    pdf_banner_file = await DARKXSIDE78.get_pdf_banner(user_id)
    pdf_lock_on = await DARKXSIDE78.get_pdf_lock_mode(user_id)
    pdf_lock_password = await DARKXSIDE78.get_pdf_lock_password(user_id)
    pdf_banner_placement = await DARKXSIDE78.get_pdf_banner_placement(user_id) or "first"

    banner_status = "✓ Oɴ" if pdf_banner_on else "✘ Oғғ"
    lock_status = "✓ Oɴ" if pdf_lock_on else "✘ Oғғ"
    banner_file_status = "✓ Sᴇᴛ" if pdf_banner_file else "✘ Nᴏᴛ Sᴇᴛ"
    lock_pw_status = f"✓ Sᴇᴛ" if pdf_lock_password else "✘ Nᴏᴛ Sᴇᴛ"
    placement_status = {
        "first": "Fɪʀsᴛ Pᴀɢᴇ",
        "last": "Lᴀsᴛ Pᴀɢᴇ",
        "both": "Bᴏᴛʜ"
    }.get(pdf_banner_placement, "Fɪʀsᴛ Pᴀɢᴇ")

    text = (
        f"**PDF Mᴏᴅᴇ Sᴇᴛᴛɪɴɢs**\n\n**PDF Bᴀɴɴᴇʀ:**** {banner_status}**\n**Bᴀɴɴᴇʀ Fɪʟᴇ:**** {banner_file_status}**\n**PDF Lᴏᴄᴋ:**** {lock_status}**\n**Lᴏᴄᴋ Pᴀssᴡᴏʀᴅ:**** {lock_pw_status}**\n**Bᴀɴɴᴇʀ Pʟᴀᴄᴇᴍᴇɴᴛ:**** `{placement_status}`**\n\n**— Wʜᴇɴ PDF Bᴀɴɴᴇʀ ɪs ON, ʏᴏᴜʀ ʙᴀɴɴᴇʀ ᴡɪʟʟ ʙᴇ ᴀᴜᴛᴏ-ᴀᴅᴅᴇᴅ ᴛᴜ ᴀʟʟ ʀᴇɴᴀᴍᴇᴅ PDFs.**\n**— Wʜᴇɴ PDF Lᴏᴄᴋ ɪs ON, ᴀʟʟ ʀᴇɴᴀᴍᴇᴅ PDFs ᴡɪʟʟ ʙᴇ ʟᴏᴄᴋᴇᴅ ᴡɪᴛʜ ʏᴏᴜʀ ᴘᴀssᴡᴏʀᴅ.**\n**— Bᴀɴɴᴇʀ Pʟᴀᴄᴇᴍᴇɴᴛ ᴄᴏɴᴛʀᴏʟs ᴡʜᴇʀᴇ ʏᴏᴜʀ ʙᴀɴɴᴇʀ ɪs ᴀᴅᴅᴇᴅ (ғɪʀsᴛ, ʟᴀsᴛ, ᴏʀ ʙᴏᴛʜ ᴘᴀɢᴇs).**\n"
    )

    buttons = [
        [
            InlineKeyboardButton(
                f"PDF Bᴀɴɴᴇʀ: {'Dɪsᴀʙʟᴇ' if pdf_banner_on else 'Eɴᴀʙʟᴇ'}",
                callback_data=f"toggle_pdf_banner:{int(not pdf_banner_on)}"
            ),
            InlineKeyboardButton(
                f"PDF Lᴏᴄᴋ: {'Dɪsᴀʙʟᴇ' if pdf_lock_on else 'Eɴᴀʙʟᴇ'}",
                callback_data=f"toggle_pdf_lock:{int(not pdf_lock_on)}"
            ),
        ],
        [
            InlineKeyboardButton(
                "Sᴇᴛ PDF Bᴀɴɴᴇʀ", callback_data="set_pdf_banner"
            ),
            InlineKeyboardButton(
                "Sᴇᴛ PDF Lᴏᴄᴋ Pᴀssᴡᴏʀᴅ", callback_data="set_pdf_lock_pw"
            ),
        ],
        [
            InlineKeyboardButton(
                f"Bᴀɴɴᴇʀ Pʟᴀᴄᴇᴍᴇɴᴛ: {placement_status}", callback_data=f"set_pdf_banner_place:{user_id}"
            ),
        ]
    ]

    if edit:
        if message.text != text or getattr(message.reply_markup, "inline_keyboard", None) != InlineKeyboardMarkup(buttons).inline_keyboard:
            await message.edit_text(
                text,
                reply_markup=InlineKeyboardMarkup(buttons)
            )
    else:
        await message.reply_text(
            text,
            reply_markup=InlineKeyboardMarkup(buttons)
        )

@Client.on_callback_query(filters.regex(r"^set_pdf_banner_place:(\d+)$"))
async def set_pdf_banner_place_cb(client, callback_query):
    owner_id = int(callback_query.matches[0].group(1))
    if callback_query.from_user.id != owner_id:
        await callback_query.answer("Yᴏᴜ ᴄᴀɴ'ᴛ ᴄʜᴀɴɢᴇ sᴇᴛᴛɪɴɢs ғᴏʀ ᴀɴᴏᴛʜᴇʀ ᴜsᴇʀ!", show_alert=True)
        return
    buttons = [
        [
            InlineKeyboardButton("Fɪʀsᴛ Pᴀɢᴇ", callback_data=f"pdf_banner_place:first:{owner_id}"),
            InlineKeyboardButton("Lᴀsᴛ Pᴀɢᴇ", callback_data=f"pdf_banner_place:last:{owner_id}")
        ],
        [
            InlineKeyboardButton("Bᴏᴛʜ", callback_data=f"pdf_banner_place:both:{owner_id}")
        ]
    ]
    await callback_query.message.edit_text(
        "**Cʜᴏᴏsᴇ ᴅᴇғᴀᴜʟᴛ PDF ʙᴀɴɴᴇʀ ᴘᴀᴄᴇᴍᴇɴᴛ:**",
        reply_markup=InlineKeyboardMarkup(buttons)
    )
    await callback_query.answer()

@Client.on_callback_query(filters.regex(r"^pdf_banner_place:(first|last|both):(\d+)$"))
async def pdf_banner_place_choose_cb(client, callback_query):
    placement = callback_query.matches[0].group(1)
    owner_id = int(callback_query.matches[0].group(2))
    if callback_query.from_user.id != owner_id:
        await callback_query.answer("Yᴏᴜ ᴄᴀɴ'ᴛ ᴄʜᴀɴɢᴇ sᴇᴛᴛɪɴɢs ғᴏʀ ᴀɴᴏᴛʜᴇʀ ᴜsᴇʀ!", show_alert=True)
        return
    await DARKXSIDE78.set_pdf_banner_placement(owner_id, placement)
    await pdf_mode_settings(client, callback_query.message, edit=True, user_id=owner_id)
    await callback_query.answer(f"PDF ʙᴀɴɴᴇʀ ᴘʟᴀᴄᴇᴍᴇɴᴛ sᴇᴛ ᴛᴏ {placement}!", show_alert=True)

@Client.on_message(filters.command("set_pdf_banner_place"))
@check_ban_status
async def set_pdf_banner_place_cmd(client, message: Message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2 or args[1].strip().lower() not in ("first", "last", "both"):
        return await message.reply(
            "**Usᴀɢᴇ:** `/set_pdf_banner_place first|last|both`\n"
            "**Sᴇᴛ ᴡʜᴇʀᴇ ʏᴏᴜʀ PDF ʙᴀɴɴᴇʀ ᴡɪʟʟ ʙᴇ ᴀᴅᴅᴇᴅ ʙʏ ᴅᴇғᴀᴜʟᴛ.**"
        )
    placement = args[1].strip().lower()
    await DARKXSIDE78.set_pdf_banner_placement(message.from_user.id, placement)
    await message.reply(f"**PDF ʙᴀɴɴᴇʀ ᴘʟᴀᴄᴇᴜᴇɴᴛ sᴇᴛ ᴛᴏ:** `{placement}`")

@Client.on_callback_query(filters.regex(r"^toggle_pdf_banner:(0|1)$"))
async def toggle_pdf_banner_cb(client, callback_query):
    mode = bool(int(callback_query.matches[0].group(1)))
    user_id = callback_query.from_user.id
    await DARKXSIDE78.set_pdf_banner_mode(user_id, mode)
    await pdf_mode_settings(client, callback_query.message, edit=True, user_id=user_id)
    await callback_query.answer(f"PDF Bᴀɴɴᴇʀ {'enabled' if mode else 'disabled'}.")

@Client.on_callback_query(filters.regex(r"^toggle_pdf_lock:(0|1)$"))
async def toggle_pdf_lock_cb(client, callback_query):
    mode = bool(int(callback_query.matches[0].group(1)))
    user_id = callback_query.from_user.id
    await DARKXSIDE78.set_pdf_lock_mode(user_id, mode)
    await pdf_mode_settings(client, callback_query.message, edit=True, user_id=user_id)
    await callback_query.answer(f"PDF Lᴏᴄᴋ {'enabled' if mode else 'disabled'}.")
    
@Client.on_callback_query(filters.regex(r"^set_pdf_banner$"))
async def set_pdf_banner_cb(client, callback_query):
    await callback_query.answer("Rᴇᴘʟʏ ᴛᴏ ᴀ ᴘʜᴏᴛᴏ ᴡɪᴛʜ /set_pdf_banner ᴛᴏ sᴇᴛ ʏᴏᴜʀ ʙᴀɴɴᴇʀ.", show_alert=True)

@Client.on_callback_query(filters.regex(r"^set_pdf_lock_pw$"))
async def set_pdf_lock_pw_cb(client, callback_query):
    await callback_query.answer("Sᴇɴᴅ /set_pdf_lock <password> ᴛᴏ sᴇᴛ ʏᴏᴜʀ PDF ʟᴏᴄᴋ ᴘᴀssᴡᴏʀᴅ.", show_alert=True)
# Start cleanup when bot starts
asyncio.create_task(cleanup_manual_requests())  
