from config import Config, Txt
from helper.database import DARKXSIDE78
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram import Client, filters
from pyrogram.errors import FloodWait, InputUserDeactivated, UserIsBlocked, PeerIdInvalid
import os, sys, time, asyncio, logging, datetime, html, pytz
from datetime import datetime, timedelta
import subprocess
import json
import requests
from datetime import datetime
from pyrogram import Client, filters
import logging
import pytz
from functools import wraps
import secrets
from typing import Dict, Optional

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ADMIN_USER_ID = Config.ADMIN
PREMIUM_USERS_PER_PAGE = Config.PREMIUM_USERS_PER_PAGE
is_restarting = False

# ---------------- PREMIUM USERS ---------------- #
@Client.on_message(filters.command(["listpremium", "premium_users", "premiumusers"]) & filters.private)
async def list_premium_users(client, message):
    await send_premium_page(client, message, page=1)

@Client.on_callback_query(filters.regex(r"^premium_page:(\d+)$"))
async def premium_page_callback(client, callback_query):
    page = int(callback_query.data.split(":")[1])
    await send_premium_page(client, callback_query.message, page, callback_query)

async def send_premium_page(client, message, page=1, callback_query=None):
    total_premium = await DARKXSIDE78.col.count_documents({"is_premium": True})
    if total_premium == 0:
        text = "Nᴏ ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀs ғᴏᴜɴᴅ."
        if callback_query:
            await callback_query.answer("Nᴏ ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀs.", show_alert=True)
            return await callback_query.message.edit_text(text)
        return await message.reply_text(text)

    pages = (total_premium + PREMIUM_USERS_PER_PAGE - 1) // PREMIUM_USERS_PER_PAGE
    page = max(1, min(page, pages))
    skip = (page - 1) * PREMIUM_USERS_PER_PAGE

    users = await DARKXSIDE78.col.find({"is_premium": True}).skip(skip).limit(PREMIUM_USERS_PER_PAGE).to_list(length=PREMIUM_USERS_PER_PAGE)

    lines = []
    for idx, user in enumerate(users, start=skip + 1):
        name = user.get("name") or user.get("first_name") or "N/A"
        username = user.get("username")
        user_id = user.get("_id")
        premium_expiry = user.get("premium_expiry")
        expiry_str = f" | Expires: {premium_expiry.strftime('%Y-%m-%d')}" if premium_expiry else ""
        line = f"{idx}. {name} ({'@'+username if username else user_id}){expiry_str}"
        lines.append(line)

    text = f"**Pʀᴇᴍɪᴜᴍ Usᴇʀs (Pᴀɢᴇ {page}/{pages}):**\n\n" + "\n".join(lines)

    buttons = []
    if page > 1:
        buttons.append(InlineKeyboardButton("Bᴀᴄᴋ", callback_data=f"premium_page:{page-1}"))
    if page < pages:
        buttons.append(InlineKeyboardButton("Nᴇxᴛ", callback_data=f"premium_page:{page+1}"))

    markup = InlineKeyboardMarkup([buttons]) if buttons else None

    if callback_query:
        await callback_query.message.edit_text(text, reply_markup=markup, disable_web_page_preview=True)
        await callback_query.answer()
    else:
        await message.reply_text(text, reply_markup=markup, disable_web_page_preview=True)

# ---------------- RESTART BOT ---------------- #
@Client.on_message(filters.private & filters.command("restart") & filters.user(ADMIN_USER_ID))
async def restart_bot(b, m):
    global is_restarting
    if not is_restarting:
        is_restarting = True
        await m.reply_text(
            "**Aʀᴇ ʏᴏᴜ sᴜʀᴇ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ʀᴇsᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ?**",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("✓ Yᴇs", callback_data="confirm_restart"),
                 InlineKeyboardButton("✘ Nᴏ", callback_data="cancel_restart")]
            ])
        )

@Client.on_callback_query(filters.regex("confirm_restart"))
async def confirm_restart(bot: Client, callback_query):
    await callback_query.answer("Rᴇsᴛᴀʀᴛɪɴɢ...")
    await callback_query.message.delete()
    os.execl(sys.executable, sys.executable, *sys.argv)

@Client.on_callback_query(filters.regex("cancel_restart"))
async def cancel_restart(bot: Client, callback_query):
    global is_restarting
    is_restarting = False
    await callback_query.answer("Rᴇsᴛᴀʀᴛ Cᴀɴᴄᴇʟʟᴇᴅ!")
    await callback_query.message.delete()

# ---------------- BAN / UNBAN ---------------- #
@Client.on_message(filters.command("ban") & filters.user(Config.ADMIN))
async def ban_user(bot: Client, message: Message):
    try:
        args = message.text.split(maxsplit=2)
        if len(args) < 2:
            return await message.reply_text("**Usᴀɢᴇ:** `/ban @username/userid [reason]`")
        
        user_ref = args[1]
        reason = args[2] if len(args) > 2 else "No reason provided"

        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        await DARKXSIDE78.col.update_one(
            {"_id": user["_id"]},
            {"$set": {
                "ban_status.is_banned": True,
                "ban_status.banned_on": datetime.now(pytz.utc).isoformat(),
                "ban_status.ban_reason": reason
            }}
        )
        await message.reply_text(f"**🗸 Usᴇʀ {user['_id']} ʜᴀs ʙᴇᴇɴ ʙᴀɴɴᴇᴅ.**\n**Rᴇᴀsᴏɴ:** {reason}")
    except Exception as e:
        await message.reply_text(f"**Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /ban @username/userid [reason]**")

@Client.on_message(filters.command("unban") & filters.user(Config.ADMIN))
async def unban_user(bot: Client, message: Message):
    try:
        args = message.text.split(maxsplit=1)
        if len(args) < 2:
            return await message.reply_text("**Usᴀɢᴇ:** `/unban @username/userid`")
        
        user_ref = args[1]

        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        await DARKXSIDE78.col.update_one(
            {"_id": user["_id"]},
            {"$set": {
                "ban_status.is_banned": False,
                "ban_status.banned_on": None,
                "ban_status.ban_reason": None
            }}
        )
        await message.reply_text(f"**🗸 Usᴇʀ {user['_id']} ʜᴀs ʙᴇᴇɴ ᴜɴʙᴀɴɴᴇᴅ.**")
    except Exception as e:
        await message.reply_text(f"**Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /unban @username/userid**")

# ---------------- TOKENS / PREMIUM ---------------- #
@Client.on_message(filters.command("add_token") & filters.user(Config.ADMIN))
async def add_tokens(bot: Client, message: Message):
    try:
        _, amount, *user_info = message.text.split()
        user_ref = " ".join(user_info).strip()

        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        new_tokens = int(amount) + user.get('token', Config.DEFAULT_TOKEN)
        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {"token": new_tokens}}
        )
        await message.reply_text(f"**🗸 Aᴅᴅᴇᴅ {amount} ᴛᴏᴋᴇɴs ᴛᴏ ᴜsᴇʀ {user['_id']}. Nᴇᴡ ʙᴀʟᴀɴᴄᴇ: {new_tokens}**")
    except Exception as e:
        await message.reply_text(f"**Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /add_token <amount> @username/userid**")

@Client.on_message(filters.command("remove_token") & filters.user(Config.ADMIN))
async def remove_tokens(bot: Client, message: Message):
    try:
        _, amount, *user_info = message.text.split()
        user_ref = " ".join(user_info).strip()
        
        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        new_tokens = max(0, user.get('token', Config.DEFAULT_TOKEN) - int(amount))
        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {"token": new_tokens}}
        )
        await message.reply_text(f"**🗸 Rᴇᴍᴏᴠᴇᴅ {amount} ᴛᴏᴋᴇɴs ғʀᴏᴍ ᴜsᴇʀ {user['_id']}. Nᴇᴡ ʙᴀʟᴀɴᴄᴇ: {new_tokens}**")
    except Exception as e:
        await message.reply_text(f"Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /remove_token <amount> @username/userid")

@Client.on_message(filters.command("add_premium") & filters.user(Config.ADMIN))
async def add_premium(bot: Client, message: Message):
    try:
        parts = message.text.split(maxsplit=2)
        if len(parts) < 3:
            return await message.reply_text("**Usᴀɢᴇ: /add_premium @username/userid 1d (1h/1m/1y/lifetime)**")
        _, user_ref, duration = parts
        duration = duration.lower().strip()

        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})

        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")

        if duration in ["lifetime", "life", "forever"]:
            expiry = datetime(9999, 12, 31)
        else:
            import re
            match = re.match(r"(\d+)\s*(h|hour|hours|d|day|days|m|month|months|y|year|years)$", duration)
            if not match:
                return await message.reply_text("**Iɴᴠᴀʟɪᴅ ᴅᴜʀᴀᴛɪᴏɴ! Usᴇ 1d, 2days, 3m, 4months, 1y, 2years, lifetime, etc.**")
            num, unit = int(match.group(1)), match.group(2)
            if unit in ["h", "hour", "hours"]:
                delta = timedelta(hours=num)
            elif unit in ["d", "day", "days"]:
                delta = timedelta(days=num)
            elif unit in ["m", "month", "months"]:
                delta = timedelta(days=num * 30)
            elif unit in ["y", "year", "years"]:
                delta = timedelta(days=num * 365)
            else:
                return await message.reply_text("**Iɴᴠᴀʟɪᴅ ᴅᴜʀᴀᴛɪᴏɴ ᴜɴɪᴛ!**")
            expiry = datetime.now() + delta

        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {
                "is_premium": True,
                "premium_expiry": expiry
            }}
        )
        await message.reply_text(f"**🗸 Pʀᴇᴍɪᴜᴍ ᴀᴅᴅᴇᴅ ᴜɴᴛɪʟ {expiry.strftime('%Y-%m-%d %H:%M:%S')}**")
    except Exception as e:
        await message.reply_text(f"**Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /add_premium @username/userid 1d (1h/1m/1y/lifetime)**")

@Client.on_message(filters.command("remove_premium") & filters.user(Config.ADMIN))
async def remove_premium(bot: Client, message: Message):
    try:
        _, user_ref = message.text.split(maxsplit=1)
        
        if user_ref.startswith("@"):
            user = await DARKXSIDE78.col.find_one({"username": user_ref[1:]})
        else:
            user = await DARKXSIDE78.col.find_one({"_id": int(user_ref)})
        
        if not user:
            return await message.reply_text("**Usᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ!**")
        
        await DARKXSIDE78.col.update_one(
            {"_id": user['_id']},
            {"$set": {
                "is_premium": False,
                "premium_expiry": None
            }}
        )
        await message.reply_text("**🗸 Pʀᴇᴍɪᴜᴍ ᴀᴄᴄᴇss ʀᴇᴍᴏᴠᴇᴅ**")
    except Exception as e:
        await message.reply_text(f"**Eʀʀᴏʀ: {e}\nUsᴀɢᴇ: /remove_premium @username/userid**")

# ---------------- TUTORIAL ---------------- #
@Client.on_message(filters.private & filters.command("tutorial"))
async def tutorial(bot: Client, message: Message):
    user_id = message.from_user.id
    format_template = await DARKXSIDE78.get_format_template(user_id)
    await message.reply_text(
        text=Txt.FILE_NAME_TXT.format(format_template=format_template),
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("ᴏᴡɴᴇʀ", url=f"https://t.me/{Config.OWNER_USERNAME}"),
             InlineKeyboardButton("ᴛᴜᴛᴏʀɪᴀʟ", url=f"https://t.me/{Config.SUPPORT_CHANNEL_USERNAME}")]
        ])
    )

# ---------------- STATS / USERS ---------------- #
@Client.on_message(filters.command([ "status"]) & filters.user(Config.ADMIN))
async def get_stats(bot, message):
    total_users = await DARKXSIDE78.total_users_count()
    uptime = time.strftime("%Hh%Mm%Ss", time.gmtime(time.time() - bot.uptime))    
    start_t = time.time()
    st = await message.reply('**Aᴄᴄᴇssɪɴɢ Tʜᴇ Dᴇᴛᴀɪʟs.....**')    
    end_t = time.time()
    time_taken_s = (end_t - start_t) * 1000
    await st.edit(text=f"**--Bᴏᴛ Sᴛᴀᴛᴜs--** \n\n**Bᴏᴛ Uᴘᴛɪᴍᴇ:** {uptime} \n**Cᴜʀʀᴇɴᴛ Pɪɴɢ:** `{time_taken_s:.3f} ms` \n**Tᴏᴛᴀʟ Usᴇʀs:** `{total_users}`")
@Client.on_message(filters.command("stats") & filters.user(Config.ADMIN))
async def stats(client, message: Message):
    total_users = await DARKXSIDE78.col.count_documents({})
    premium_users = await DARKXSIDE78.col.count_documents({"is_premium": True})
    banned_users = await DARKXSIDE78.col.count_documents({"banned": True})
    
    stats_text = f"""
**🤖 Bot Statistics**

**👥 Total Users:** `{total_users}`
**⭐ Premium Users:** `{premium_users}`
**🚫 Banned Users:** `{banned_users}`
**🆓 Free Users:** `{total_users - premium_users - banned_users}`

**💾 Database:** MongoDB
**⚡ Status:** Running
    """
    
    await message.reply_text(stats_text)
@Client.on_message(filters.command(["users", "user"]) & filters.user(Config.ADMIN))
async def get_users(bot, message):
    total_users = await DARKXSIDE78.total_users_count()
    uptime = time.strftime("%Hh%Mm%Ss", time.gmtime(time.time() - bot.uptime))    
    start_t = time.time()
    st = await message.reply('**Aᴄᴄᴇssɪɴɢ Tʜᴇ Dᴇᴛᴀɪʟs.....**')    
    end_t = time.time()
    time_taken_s = (end_t - start_t) * 1000
    await st.edit(text=f"**--Bᴏᴛ Sᴛᴀᴛᴜs--** \n\n**Tᴏᴛᴀʟ Usᴇʀs :** `{total_users}`")

#from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram.errors import FloodWait, InputUserDeactivated, UserIsBlocked, PeerIdInvalid
import asyncio
import time
from datetime import datetime
from typing import Dict, List
import traceback

# ==============================
# BROADCAST MANAGER
# ==============================

class BroadcastManager:
    def __init__(self):
        self.active_broadcasts: Dict[int, Dict] = {}
        self.broadcast_history: List[Dict] = []
    
    def create_broadcast(self, message: Message, admin_id: int) -> int:
        """Create a new broadcast and return its ID"""
        broadcast_id = int(time.time())
        
        self.active_broadcasts[broadcast_id] = {
            "id": broadcast_id,
            "message": message,
            "admin_id": admin_id,
            "status": "preparing",  # preparing, running, paused, completed, cancelled, error
            "stats": {
                "total_users": 0,
                "processed": 0,
                "successful": 0,
                "failed": 0,
                "blocked": 0,
                "deactivated": 0,
                "invalid": 0,
                "start_time": None,
                "end_time": None,
                "duration": 0,
            },
            "task": None,
            "cancelled": False,
            "paused": False,
            "progress_msg_id": None,
        }
        
        return broadcast_id
    
    def get_broadcast(self, broadcast_id: int):
        """Get broadcast by ID"""
        return self.active_broadcasts.get(broadcast_id)
    
    def remove_broadcast(self, broadcast_id: int):
        """Remove broadcast from active list"""
        if broadcast_id in self.active_broadcasts:
            # Move to history before removing
            broadcast = self.active_broadcasts[broadcast_id]
            if broadcast["status"] in ["completed", "cancelled", "error"]:
                self.broadcast_history.append(broadcast)
            
            # Remove from active
            del self.active_broadcasts[broadcast_id]
    
    def get_active_broadcasts(self):
        """Get all active broadcasts"""
        return [b for b in self.active_broadcasts.values() if b["status"] in ["running", "paused"]]
    
    def get_history(self, limit: int = 10):
        """Get broadcast history"""
        return self.broadcast_history[-limit:]

# Initialize broadcast manager
broadcast_manager = BroadcastManager()

# ==============================
# HELPER FUNCTIONS
# ==============================

def get_message_type(message: Message) -> str:
    """Get human-readable message type"""
    if message.text:
        return "📝 Text"
    elif message.photo:
        return "🖼️ Photo"
    elif message.video:
        return "🎬 Video"
    elif message.document:
        return "📄 Document"
    elif message.audio:
        return "🎵 Audio"
    elif message.voice:
        return "🎤 Voice"
    elif message.video_note:
        return "📹 Video Note"
    elif message.sticker:
        return "🤡 Sticker"
    elif message.animation:
        return "🎞️ Animation"
    elif message.poll:
        return "📊 Poll"
    elif message.contact:
        return "👤 Contact"
    elif message.location:
        return "📍 Location"
    elif message.venue:
        return "🏢 Venue"
    elif message.game:
        return "🎮 Game"
    elif message.web_page:
        return "🌐 Web Page"
    elif message.media:
        return "📦 Media"
    else:
        return "❓ Unknown"

def get_message_preview(message: Message, max_length: int = 150) -> str:
    """Get preview text from message"""
    if message.text:
        text = message.text
    elif message.caption:
        text = message.caption
    elif message.poll:
        text = f"📊 Poll: {message.poll.question}"
    elif message.contact:
        text = f"👤 Contact: {message.contact.first_name}"
    elif message.location:
        text = f"📍 Location"
    elif message.venue:
        text = f"🏢 {message.venue.title}"
    elif message.sticker:
        text = f"🤡 Sticker: {message.sticker.emoji or ''}"
    else:
        text = f"[{get_message_type(message)}]"
    
    # Clean and truncate
    text = text.replace('\n', ' ').strip()
    if len(text) > max_length:
        return text[:max_length] + "..."
    return text

def format_time(seconds: float) -> str:
    """Format seconds to readable time"""
    if seconds < 60:
        return f"{int(seconds)}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"

def format_eta(processed: int, total: int, elapsed: float) -> str:
    """Calculate and format ETA"""
    if processed == 0 or total == 0:
        return "Calculating..."
    
    progress = processed / total
    if progress == 0:
        return "∞"
    
    total_estimated = elapsed / progress
    remaining = total_estimated - elapsed
    
    return format_time(remaining)

async def send_message_safe(bot: Client, user_id: int, message: Message, max_retries: int = 3) -> int:
    """
    Send message with error handling and retries
    Returns:
        200: Success
        400: User blocked bot
        401: User deactivated
        404: Invalid user ID
        500: Other error
    """
    for attempt in range(max_retries):
        try:
            await message.copy(chat_id=user_id)
            return 200
            
        except FloodWait as e:
            if attempt == max_retries - 1:
                return 500
            await asyncio.sleep(e.value)
            
        except UserIsBlocked:
            return 400
            
        except InputUserDeactivated:
            return 401
            
        except PeerIdInvalid:
            return 404
            
        except Exception as e:
            if attempt == max_retries - 1:
                print(f"Failed to send to {user_id}: {e}")
                return 500
            await asyncio.sleep(1)
    
    return 500

# ==============================
# GET USERS FUNCTION
# ==============================

async def get_all_users(bot: Client) -> List[int]:
    """
    Get all users from your source
    Replace this with your actual user fetching logic
    Example: Get users from your database or config
    """
    # TODO: Replace with your actual user fetching
    # For now, return an empty list
    return []

# Or if you have a Config.USERS list:
# async def get_all_users(bot: Client) -> List[int]:
#     return Config.USERS if hasattr(Config, 'USERS') else []

# ==============================
# BROADCAST HANDLERS
# ==============================

@Client.on_message(filters.command("broadcast") & filters.user(Config.ADMIN) & filters.reply)
async def broadcast_command_handler(bot: Client, message: Message):
    """Handle /broadcast command"""
    
    # Check for active broadcasts
    active_broadcasts = broadcast_manager.get_active_broadcasts()
    if active_broadcasts:
        active_text = "\n".join([f"• ID: {b['id']} ({b['status']})" for b in active_broadcasts[:3]])
        await message.reply_text(
            f"⚠️ **Active Broadcasts Found!**\n\n{active_text}\n\n"
            f"Wait for them to complete or use:\n"
            f"• `/broadcast_cancel ID` to cancel\n"
            f"• `/broadcast_status` to check status"
        )
        return
    
    # Get the message to broadcast
    broadcast_msg = message.reply_to_message
    
    # Create broadcast
    broadcast_id = broadcast_manager.create_broadcast(broadcast_msg, message.from_user.id)
    broadcast = broadcast_manager.get_broadcast(broadcast_id)
    
    # Get message info
    msg_type = get_message_type(broadcast_msg)
    msg_preview = get_message_preview(broadcast_msg)
    
    # Create confirmation message
    confirm_text = (
        f"📢 **Broadcast Confirmation**\n\n"
        f"**Type:** {msg_type}\n"
        f"**Preview:** {msg_preview}\n\n"
        f"**Broadcast ID:** `{broadcast_id}`\n"
        f"**Time:** {datetime.now().strftime('%H:%M:%S')}\n\n"
        f"⚠️ **This will send to ALL users!**"
    )
    
    confirm_buttons = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Start Now", callback_data=f"br_start:{broadcast_id}"),
            InlineKeyboardButton("❌ Cancel", callback_data=f"br_cancel:{broadcast_id}")
        ],
        [
            InlineKeyboardButton("🔧 Settings", callback_data=f"br_settings:{broadcast_id}")
        ]
    ])
    
    sent_msg = await message.reply_text(confirm_text, reply_markup=confirm_buttons)
    
    # Store message ID for later updates
    broadcast["confirm_msg_id"] = sent_msg.id

@Client.on_callback_query(filters.regex(r"^br_start:(\d+)$"))
async def start_broadcast_callback(bot: Client, callback_query):
    """Start broadcast from callback"""
    broadcast_id = int(callback_query.data.split(":")[1])
    broadcast = broadcast_manager.get_broadcast(broadcast_id)
    
    if not broadcast:
        await callback_query.answer("Broadcast not found!", show_alert=True)
        await callback_query.message.delete()
        return
    
    if broadcast["status"] != "preparing":
        await callback_query.answer(f"Broadcast is already {broadcast['status']}!", show_alert=True)
        return
    
    await callback_query.answer("Starting broadcast...")
    
    # Start the broadcast in background
    task = asyncio.create_task(
        execute_broadcast(bot, broadcast_id)
    )
    broadcast["task"] = task
    broadcast["status"] = "running"
    broadcast["stats"]["start_time"] = time.time()
    
    # Update confirmation message
    await callback_query.message.edit_text(
        "🚀 **Broadcast Started!**\n\n"
        f"**ID:** `{broadcast_id}`\n"
        "⏳ Processing users...\n\n"
        "Use these commands:\n"
        "• `/broadcast_status` - Check progress\n"
        "• `/broadcast_pause` - Pause/Resume\n"
        "• `/broadcast_cancel` - Cancel\n"
        "• `/broadcast_history` - View history"
    )

async def execute_broadcast(bot: Client, broadcast_id: int):
    """Main broadcast execution function"""
    broadcast = broadcast_manager.get_broadcast(broadcast_id)
    if not broadcast:
        return
    
    message = broadcast["message"]
    admin_id = broadcast["admin_id"]
    stats = broadcast["stats"]
    
    try:
        # Get all users
        all_users = await get_all_users(bot)
        stats["total_users"] = len(all_users)
        
        if stats["total_users"] == 0:
            broadcast["status"] = "error"
            await bot.send_message(
                admin_id,
                f"❌ **Broadcast Failed!**\n\n"
                f"No users found to broadcast to.\n"
                f"**ID:** `{broadcast_id}`"
            )
            broadcast_manager.remove_broadcast(broadcast_id)
            return
        
        # Create progress message
        progress_msg = await bot.send_message(
            admin_id,
            "📊 **Broadcast Progress**\n\n"
            f"🔄 Initializing...\n"
            f"📈 Users: 0/{stats['total_users']} (0%)\n"
            f"✅ Success: 0\n"
            f"❌ Failed: 0\n"
            f"⏱️ Time: 0s\n"
            f"⏳ ETA: Calculating..."
        )
        broadcast["progress_msg_id"] = progress_msg.id
        
        # Batch processing
        batch_size = 20  # Users per batch
        delay = 0.5  # Delay between batches (seconds)
        
        for i in range(0, len(all_users), batch_size):
            # Check if cancelled
            if broadcast.get("cancelled"):
                stats["status"] = "cancelled"
                break
            
            # Check if paused
            if broadcast.get("paused"):
                while broadcast.get("paused") and not broadcast.get("cancelled"):
                    await asyncio.sleep(1)
                if broadcast.get("cancelled"):
                    break
            
            # Process batch
            batch = all_users[i:i + batch_size]
            tasks = []
            
            for user_id in batch:
                if broadcast.get("cancelled"):
                    break
                
                task = asyncio.create_task(
                    send_message_safe(bot, user_id, message)
                )
                tasks.append(task)
            
            # Wait for batch completion
            if tasks:
                results = await asyncio.gather(*tasks, return_exceptions=True)
                
                # Process results
                for result in results:
                    if isinstance(result, Exception):
                        stats["failed"] += 1
                    elif result == 200:
                        stats["successful"] += 1
                    elif result == 400:
                        stats["blocked"] += 1
                    elif result == 401:
                        stats["deactivated"] += 1
                    elif result == 404:
                        stats["invalid"] += 1
                    else:
                        stats["failed"] += 1
                
                stats["processed"] += len(batch)
            
            # Update progress
            elapsed = time.time() - stats["start_time"]
            progress = (stats["processed"] / stats["total_users"]) * 100 if stats["total_users"] > 0 else 0
            
            # Update progress message every 100 users or every 10 seconds
            if i % 100 == 0 or elapsed % 10 < 1:
                try:
                    eta = format_eta(stats["processed"], stats["total_users"], elapsed)
                    
                    progress_text = (
                        f"📊 **Broadcast Progress**\n\n"
                        f"{'⏸️ Paused' if broadcast.get('paused') else '🔄 Running'}\n"
                        f"📈 Users: {stats['processed']}/{stats['total_users']} ({progress:.1f}%)\n"
                        f"✅ Success: {stats['successful']}\n"
                        f"❌ Failed: {stats['failed']}\n"
                        f"🚫 Blocked: {stats['blocked']}\n"
                        f"💀 Deactivated: {stats['deactivated']}\n"
                        f"⏱️ Time: {format_time(elapsed)}\n"
                        f"⏳ ETA: {eta}\n\n"
                        f"**ID:** `{broadcast_id}`"
                    )
                    
                    await progress_msg.edit_text(progress_text)
                except Exception as e:
                    print(f"Failed to update progress: {e}")
            
            # Rate limiting
            if i + batch_size < len(all_users):
                await asyncio.sleep(delay)
        
        # Broadcast completed
        stats["end_time"] = time.time()
        stats["duration"] = stats["end_time"] - stats["start_time"]
        broadcast["status"] = "cancelled" if broadcast.get("cancelled") else "completed"
        
        # Send completion report
        success_rate = (stats["successful"] / stats["total_users"]) * 100 if stats["total_users"] > 0 else 0
        
        completion_text = (
            f"🎉 **Broadcast {'Cancelled' if broadcast.get('cancelled') else 'Completed'}!**\n\n"
            f"**ID:** `{broadcast_id}`\n"
            f"**Status:** {broadcast['status'].title()}\n"
            f"**Total Users:** {stats['total_users']}\n"
            f"**✅ Success:** {stats['successful']}\n"
            f"**❌ Failed:** {stats['failed']}\n"
            f"**🚫 Blocked:** {stats['blocked']}\n"
            f"**💀 Deactivated:** {stats['deactivated']}\n"
            f"**⏱️ Duration:** {format_time(stats['duration'])}\n"
            f"**📊 Success Rate:** {success_rate:.1f}%\n\n"
            f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        
        await bot.send_message(admin_id, completion_text)
        
        # Clean up progress message
        try:
            await progress_msg.delete()
        except:
            pass
        
        # Move to history
        broadcast_manager.remove_broadcast(broadcast_id)
        
    except Exception as e:
        # Handle unexpected errors
        broadcast["status"] = "error"
        stats["end_time"] = time.time()
        
        error_msg = await bot.send_message(
            admin_id,
            f"❌ **Broadcast Error!**\n\n"
            f"**ID:** `{broadcast_id}`\n"
            f"**Error:** {str(e)[:200]}\n\n"
            f"Partial Results:\n"
            f"Processed: {stats['processed']}/{stats['total_users']}\n"
            f"Success: {stats['successful']}\n"
            f"Failed: {stats['failed']}"
        )
        
        print(f"Broadcast Error (ID: {broadcast_id}): {traceback.format_exc()}")
        
        # Clean up
        broadcast_manager.remove_broadcast(broadcast_id)

# ==============================
# CONTROL COMMANDS
# ==============================

@Client.on_message(filters.command("broadcast_status") & filters.user(Config.ADMIN))
async def broadcast_status_command(bot: Client, message: Message):
    """Check broadcast status"""
    active_broadcasts = broadcast_manager.get_active_broadcasts()
    
    if not active_broadcasts:
        await message.reply_text("📭 **No active broadcasts**")
        return
    
    status_text = "📊 **Active Broadcasts**\n\n"
    
    for broadcast in active_broadcasts[:5]:  # Show max 5
        stats = broadcast["stats"]
        elapsed = time.time() - (stats["start_time"] or time.time())
        progress = (stats["processed"] / stats["total_users"]) * 100 if stats["total_users"] > 0 else 0
        
        status_text += (
            f"**ID:** `{broadcast['id']}`\n"
            f"**Status:** {'⏸️ Paused' if broadcast.get('paused') else '🔄 Running'}\n"
            f"**Progress:** {stats['processed']}/{stats['total_users']} ({progress:.1f}%)\n"
            f"**Success:** {stats['successful']} | **Failed:** {stats['failed']}\n"
            f"**Time:** {format_time(elapsed)}\n"
            f"━━━━━━━━━━━━━━\n"
        )
    
    if len(active_broadcasts) > 5:
        status_text += f"\n...and {len(active_broadcasts) - 5} more"
    
    await message.reply_text(status_text)

@Client.on_message(filters.command("broadcast_cancel") & filters.user(Config.ADMIN))
async def broadcast_cancel_command(bot: Client, message: Message):
    """Cancel a broadcast"""
    if len(message.command) > 1:
        # Cancel specific broadcast
        try:
            broadcast_id = int(message.command[1])
            broadcast = broadcast_manager.get_broadcast(broadcast_id)
            
            if broadcast and broadcast["status"] == "running":
                broadcast["cancelled"] = True
                await message.reply_text(f"🛑 **Broadcast `{broadcast_id}` cancellation requested**")
            elif broadcast:
                await message.reply_text(f"📭 **Broadcast `{broadcast_id}` is not running**")
            else:
                await message.reply_text(f"❌ **Broadcast `{broadcast_id}` not found**")
        except ValueError:
            await message.reply_text("❌ **Invalid broadcast ID!**")
    else:
        # Show list to cancel
        active_broadcasts = broadcast_manager.get_active_broadcasts()
        
        if not active_broadcasts:
            await message.reply_text("📭 **No active broadcasts to cancel**")
            return
        
        buttons = []
        for broadcast in active_broadcasts[:5]:
            buttons.append([
                InlineKeyboardButton(
                    f"Cancel {broadcast['id']}",
                    callback_data=f"br_cancel:{broadcast['id']}"
                )
            ])
        
        await message.reply_text(
            "🛑 **Cancel which broadcast?**",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

@Client.on_message(filters.command("broadcast_pause") & filters.user(Config.ADMIN))
async def broadcast_pause_command(bot: Client, message: Message):
    """Pause or resume broadcast"""
    if len(message.command) > 1:
        try:
            broadcast_id = int(message.command[1])
            broadcast = broadcast_manager.get_broadcast(broadcast_id)
            
            if broadcast and broadcast["status"] == "running":
                if broadcast.get("paused"):
                    broadcast["paused"] = False
                    await message.reply_text(f"▶️ **Resumed broadcast `{broadcast_id}`**")
                else:
                    broadcast["paused"] = True
                    await message.reply_text(f"⏸️ **Paused broadcast `{broadcast_id}`**")
            elif broadcast:
                await message.reply_text(f"📭 **Broadcast `{broadcast_id}` is not running**")
            else:
                await message.reply_text(f"❌ **Broadcast `{broadcast_id}` not found**")
        except ValueError:
            await message.reply_text("❌ **Invalid broadcast ID!**")
    else:
        active_broadcasts = broadcast_manager.get_active_broadcasts()
        
        if not active_broadcasts:
            await message.reply_text("📭 **No active broadcasts to pause/resume**")
            return
        
        buttons = []
        for broadcast in active_broadcasts[:5]:
            action = "Resume" if broadcast.get("paused") else "Pause"
            buttons.append([
                InlineKeyboardButton(
                    f"{action} {broadcast['id']}",
                    callback_data=f"br_pause:{broadcast['id']}"
                )
            ])
        
        await message.reply_text(
            "⏸️ **Pause/Resume which broadcast?**",
            reply_markup=InlineKeyboardMarkup(buttons)
        )

@Client.on_message(filters.command("broadcast_history") & filters.user(Config.ADMIN))
async def broadcast_history_command(bot: Client, message: Message):
    """Show broadcast history"""
    history = broadcast_manager.get_history(limit=5)
    
    if not history:
        await message.reply_text("📭 **No broadcast history**")
        return
    
    history_text = "📜 **Recent Broadcasts**\n\n"
    
    for broadcast in history:
        stats = broadcast["stats"]
        success_rate = (stats["successful"] / stats["total_users"]) * 100 if stats["total_users"] > 0 else 0
        
        history_text += (
            f"**ID:** `{broadcast['id']}`\n"
            f"**Status:** {broadcast['status'].title()}\n"
            f"**Users:** {stats['total_users']} | **Success:** {success_rate:.1f}%\n"
            f"**Time:** {format_time(stats['duration'])}\n"
            f"━━━━━━━━━━━━━━\n"
        )
    
    await message.reply_text(history_text)

# ==============================
# CALLBACK HANDLERS
# ==============================

@Client.on_callback_query(filters.regex(r"^br_cancel:(\d+)$"))
async def cancel_broadcast_callback(bot: Client, callback_query):
    """Cancel broadcast from callback"""
    broadcast_id = int(callback_query.data.split(":")[1])
    broadcast = broadcast_manager.get_broadcast(broadcast_id)
    
    if broadcast and broadcast["status"] == "running":
        broadcast["cancelled"] = True
        await callback_query.answer("Broadcast cancellation requested!")
        await callback_query.message.edit_text(f"🛑 **Broadcast `{broadcast_id}` cancellation requested**")
    else:
        await callback_query.answer("Broadcast not found or not running!", show_alert=True)

@Client.on_callback_query(filters.regex(r"^br_pause:(\d+)$"))
async def pause_broadcast_callback(bot: Client, callback_query):
    """Pause/resume broadcast from callback"""
    broadcast_id = int(callback_query.data.split(":")[1])
    broadcast = broadcast_manager.get_broadcast(broadcast_id)
    
    if broadcast and broadcast["status"] == "running":
        if broadcast.get("paused"):
            broadcast["paused"] = False
            action = "resumed"
        else:
            broadcast["paused"] = True
            action = "paused"
        
        await callback_query.answer(f"Broadcast {action}!")
        await callback_query.message.edit_text(f"⏸️ **Broadcast `{broadcast_id}` {action}**")
    else:
        await callback_query.answer("Broadcast not found or not running!", show_alert=True)

@Client.on_callback_query(filters.regex(r"^br_settings:(\d+)$"))
async def broadcast_settings_callback(bot: Client, callback_query):
    """Show broadcast settings"""
    broadcast_id = int(callback_query.data.split(":")[1])
    
    settings_text = (
        f"🔧 **Broadcast Settings**\n\n"
        f"**ID:** `{broadcast_id}`\n\n"
        f"Available options:\n"
        f"• Change batch size\n"
        f"• Add delay between messages\n"
        f"• Filter users by type\n"
        f"• Schedule for later\n\n"
        f"*Coming soon in next update!*"
    )
    
    await callback_query.answer()
    await callback_query.message.edit_text(
        settings_text,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 Back", callback_data=f"br_start:{broadcast_id}")]
        ])
    )

# ==============================
# SIMPLE BROADCAST (Alternative)
# ==============================

@Client.on_message(filters.command("simple_broadcast") & filters.user(Config.ADMIN) & filters.reply)
async def simple_broadcast(bot: Client, message: Message):
    """Simple broadcast without tracking - for small user lists"""
    
    broadcast_msg = message.reply_to_message
    processing_msg = await message.reply_text("🔄 **Starting simple broadcast...**")
    
    try:
        # Get users
        users = await get_all_users(bot)
        total = len(users)
        
        if total == 0:
            await processing_msg.edit_text("❌ **No users found!**")
            return
        
        success = 0
        failed = 0
        
        # Send to all users
        for idx, user_id in enumerate(users, 1):
            try:
                await broadcast_msg.copy(chat_id=user_id)
                success += 1
            except Exception:
                failed += 1
            
            # Update progress every 10 users
            if idx % 10 == 0 or idx == total:
                progress = (idx / total) * 100
                await processing_msg.edit_text(
                    f"📤 **Sending...**\n\n"
                    f"Progress: {idx}/{total} ({progress:.1f}%)\n"
                    f"✅ Success: {success}\n"
                    f"❌ Failed: {failed}"
                )
        
        # Completion message
        await processing_msg.edit_text(
            f"🎉 **Broadcast Complete!**\n\n"
            f"**Total Users:** {total}\n"
            f"**✅ Success:** {success}\n"
            f"**❌ Failed:** {failed}\n"
            f"**📊 Success Rate:** {(success/total*100):.1f}%"
        )
        
    except Exception as e:
        await processing_msg.edit_text(f"❌ **Error:** {str(e)}")

# ==============================
# USAGE EXAMPLE
# ==============================

"""
USAGE GUIDE:

1. Send /broadcast and reply to a message
2. Click "Start Now" in the confirmation
3. Check progress with /broadcast_status
4. Control with /broadcast_pause and /broadcast_cancel
5. View history with /broadcast_history

Or use /simple_broadcast for quick broadcasting
"""
