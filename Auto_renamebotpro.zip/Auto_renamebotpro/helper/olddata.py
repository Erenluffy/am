import motor.motor_asyncio
from config import Config
import logging
from datetime import datetime, timedelta
import pytz
class Database:
    def __init__(self, uri, database_name):
        try:
            self._client = motor.motor_asyncio.AsyncIOMotorClient(uri)
            self._client.server_info()
            logging.info("Successfully connected to MongoDB")
        except Exception as e:
            logging.error(f"Failed to connect to MongoDB: {e}")
            raise e
        self.DARKXSIDE78 = self._client[database_name]
        self.col = self.DARKXSIDE78.user
        self.rename_logs = self.DARKXSIDE78.rename_logs
        self.sequence_logs = self.DARKXSIDE78.sequence_logs
        self.token_links = self.DARKXSIDE78.token_links
        self.global_settings = self.DARKXSIDE78.global_settings
        self.sort_logs = self.DARKXSIDE78.sort_logs  # Add this line
        self.fsub_data = self.DARKXSIDE78['fsub']   
        self.rqst_fsub_data = self.DARKXSIDE78['request_forcesub']
        self.rqst_fsub_Channel_data = self.DARKXSIDE78['request_forcesub_channel']
        

    
    async def new_user(self, id):
        """Create new user with all required fields - FIXED VERSION"""
        return dict(
            _id=int(id),
            join_date=datetime.now().date().isoformat(),
            file_id=None,
            caption=None,
            metadata=True,
            metadata_code="Telegram : @DARKXSIDE78",
            format_template=None,
            rename_count=0,
            sort_count=0,
            sequence_count=0,  # Added this
            files_processed_count=0,
            sorted_count=0,  # Added this
            total_renamed_size=0,  # Added this
            max_file_size=0,  # Added this
            first_name="",
            username="",
            token_tasks=[],
            is_premium=False,
            premium_expiry=None,
            token=Config.DEFAULT_TOKEN,
            ban_status=dict(
                is_banned=False,
                ban_duration=0,
                ban_reason=''
            ),
            last_active=datetime.now(),  # Added this
            daily_count=0  # Added this
        )
    async def is_premium(self, user_id: int):
        """Check if a user is a premium user."""
        try:
            user = await self.col.find_one({"_id": user_id})
            return user.get("is_premium", False) if user else False
        except Exception as e:
            logging.error(f"Error checking premium status for user {user_id}: {e}")
            return False

    async def add_user(self, b, m):
        u = m.from_user
        if not await self.is_user_exist(u.id):
            user = self.new_user(u.id)
            user["first_name"] = u.first_name or "Unknown"
            user["username"] = u.username or ""
            try:
                await self.col.insert_one(user)
                logging.info(f"User {u.id} added to database")
            except Exception as e:
                logging.error(f"Error adding user {u.id} to database: {e}")

    async def is_user_exist(self, id):
        try:
            user = await self.col.find_one({"_id": int(id)})
            return bool(user)
        except Exception as e:
            logging.error(f"Error checking if user {id} exists: {e}")
            return False

    async def total_users_count(self):
        try:
            count = await self.col.count_documents({})
            return count
        except Exception as e:
            logging.error(f"Error counting users: {e}")
            return 0

    async def get_all_users(self):
        try:
            all_users = self.col.find({})
            return all_users
        except Exception as e:
            logging.error(f"Error getting all users: {e}")
            return None

    async def delete_user(self, user_id):
        
        try:
            await self.col.delete_many({"_id": int(user_id)})
        except Exception as e:
            logging.error(f"Error deleting user {user_id}: {e}")

    async def set_thumbnail(self, id, file_id):
        try:
            await self.col.update_one({"_id": int(id)}, {"$set": {"file_id": file_id}})
        except Exception as e:
            logging.error(f"Error setting thumbnail for user {id}: {e}")

    async def get_thumbnail(self, id):
        try:
            user = await self.col.find_one({"_id": int(id)})
            return user.get("file_id", None) if user else None
        except Exception as e:
            logging.error(f"Error getting thumbnail for user {id}: {e}")
            return None

    async def set_caption(self, user_id: int, caption: str):
        """Set caption template for a user"""
        try:
            await self.col.update_one(
                {"_id": int(user_id)}, 
                {"$set": {"caption": caption}}
            )
        except Exception as e:
            logging.error(f"Error setting caption for user {user_id}: {e}")

    async def get_caption(self, user_id: int) -> str:
        """Get caption template for a user"""
        try:
            user = await self.col.find_one({"_id": int(user_id)})
            return user.get("caption") if user else None
        except Exception as e:
            logging.error(f"Error getting caption for user {user_id}: {e}")
            return None

    async def set_format_template(self, id, format_template):
        try:
            await self.col.update_one(
                {"_id": int(id)}, {"$set": {"format_template": format_template}}
            )
        except Exception as e:
            logging.error(f"Error setting format template for user {id}: {e}")

    async def get_format_template(self, id):
        try:
            user = await self.col.find_one({"_id": int(id)})
            return user.get("format_template", None) if user else None
        except Exception as e:
            logging.error(f"Error getting format template for user {id}: {e}")
            return None
    async def show_format_template(self, user_id: int):
        """
        Show the user's format template.
        If not set, return a default example format.
        """
        try:
            user = await self.col.find_one({"_id": int(user_id)})
            template = user.get("format_template") if user else None

            if not template:
                # Default fallback template
                template = (
                    "📂 <b>Format Template</b>\n\n"
                    "Available placeholders:\n"
                    " - {filename} → Original file name\n"
                    " - {date} → Current date\n"
                    " - {time} → Current time\n"
                    " - {username} → Your Telegram username\n"
                    " - {id} → Your Telegram ID\n\n"
                    "👉 Example:\n"
                    "<code>{filename}_Renamed_{date}</code>"
                )

            return template
        except Exception as e:
            logging.error(f"Error showing format template for user {user_id}: {e}")
            return "⚠️ Unable to fetch format template. Please try again later."

    async def is_user_banned(self, user_id: int):
        """Check if a user is banned and return the ban status and reason."""
        try:
            user = await self.col.find_one({"_id": user_id})
            if not user:
                return False, None
            ban_status = user.get("ban_status", {})
            return ban_status.get("is_banned", False), ban_status.get("ban_reason", "No reason provided")
        except Exception as e:
            logging.error(f"Error checking ban status for user {user_id}: {e}")
            return False, None

    async def add_rename_history(self, user_id: int, original_name: str, renamed_name: str):
        """Add a renamed file to the user's history."""
        await self.rename_logs.update_one(
            {"_id": user_id},
            {"$push": {"history": {"original_name": original_name, "renamed_name": renamed_name}}},
            upsert=True
        )

    async def get_rename_history(self, user_id: int):
        """Retrieve the rename history for a user."""
        user_data = await self.rename_logs.find_one({"_id": user_id})
        return user_data.get("history", []) if user_data else []
    # Add these methods to your Database class if they don't exist
    async def get_rename_count(self, user_id: int):
        """Get rename count for a user"""
        user = await self.col.find_one({"_id": user_id})
        return user.get("rename_count", 0) if user else 0
    
    async def get_user_stats(self, user_id: int):
        """Get all user stats - IMPROVED VERSION"""
        try:
            user = await self.col.find_one({"_id": user_id})
            if not user:
                return {
                    "rename_count": 0, 
                    "sort_count": 0, 
                    "files_processed_count": 0,
                    "total_renamed_size": 0,
                    "max_file_size": 0,
                    "sequence_count": 0,
                    "sorted_count": 0,
                    "is_premium": False,
                    "token": Config.DEFAULT_TOKEN
                }
            
            return {
                "rename_count": user.get("rename_count", 0),
                "sort_count": user.get("sort_count", 0),
                "files_processed_count": user.get("files_processed_count", 0),
                "total_renamed_size": user.get("total_renamed_size", 0),
                "max_file_size": user.get("max_file_size", 0),
                "sequence_count": user.get("sequence_count", 0),
                "sorted_count": user.get("sorted_count", 0),
                "is_premium": user.get("is_premium", False),
                "token": user.get("token", Config.DEFAULT_TOKEN)
            }
        except Exception as e:
            logging.error(f"Error getting user stats for {user_id}: {e}")
            return {
                "rename_count": 0, 
                "sort_count": 0, 
                "files_processed_count": 0,
                "total_renamed_size": 0,
                "max_file_size": 0,
                "sequence_count": 0,
                "sorted_count": 0,
                "is_premium": False,
                "token": Config.DEFAULT_TOKEN
            }
    async def create_token_link(self, user_id: int, token_id: str, tokens: int, expiry=None):
        if expiry is None:
            expiry = datetime.now(pytz.utc) + timedelta(hours=24)
        try:
            await self.token_links.update_one(
                {"_id": token_id},
                {
                    "$set": {
                        "user_id": user_id,
                        "tokens": tokens,
                        "used": False,
                        "expiry": expiry
                    }
                },
                upsert=True
            )
            logging.info(f"Token link created for user {user_id} with token ID {token_id}.")
        except Exception as e:
            logging.error(f"Error creating token link: {e}")
    async def get_token_link(self, token_id: str):
        try:
            token_data = await self.token_links.find_one({"_id": token_id})
            return token_data
        except Exception as e:
            logging.error(f"Error fetching token link for token ID {token_id}: {e}")
            return None

    async def mark_token_used(self, token_id: str):
        try:
            await self.token_links.update_one(
                {"_id": token_id},
                {"$set": {"used": True}}
            )
            logging.info(f"Token {token_id} marked as used.")
        except Exception as e:
            logging.error(f"Error marking token as used: {e}")

    async def set_token(self, user_id, token):
        try:
            await self.col.update_one(
                {"_id": int(user_id)},
                {"$set": {"token": token}}
            )
            logging.info(f"Token updated for user {user_id}.")
        except Exception as e:
            logging.error(f"Error setting token for user {user_id}: {e}")

    async def get_token(self, user_id):
        try:
            user = await self.col.find_one({"_id": int(user_id)})
            return user.get("token", Config.DEFAULT_TOKEN) if user else Config.DEFAULT_TOKEN
        except Exception as e:
            logging.error(f"Error getting token for user {user_id}: {e}")
            return Config.DEFAULT_TOKEN

    async def set_media_preference(self, id, media_type):
        try:
            await self.col.update_one(
                {"_id": int(id)}, {"$set": {"media_type": media_type}}
            )
        except Exception as e:
            logging.error(f"Error setting media preference for user {id}: {e}")

    async def get_media_preference(self, id):
        try:
            user = await self.col.find_one({"_id": int(id)})
            return user.get("media_type", None) if user else None
        except Exception as e:
            logging.error(f"Error getting media preference for user {id}: {e}")
            return None
# In helper/database.py

    async def set_autorename_status(self, user_id: int, status: bool):
        await self.col.update_one(
            {"_id": user_id},
            {"$set": {"autorename_enabled": status}},
            upsert=True
        )

    async def get_autorename_status(self, user_id: int) -> bool:
        user = await self.col.find_one({"_id": user_id})
        return user.get("autorename_enabled", False) if user else False

    async def set_metadata_source(self, user_id: int, source: str):
        await self.col.update_one(
            {"_id": user_id},
            {"$set": {"metadata_source": source}},
            upsert=True
        )

    async def get_metadata_source(self, user_id: int) -> str:
        user_data = await self.col.find_one({"_id": user_id})
        return user_data.get("metadata_source", "filename") if user_data else "filename"

    async def get_metadata(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('metadata', "Off")

    async def set_metadata(self, user_id, metadata):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'metadata': metadata}})

    async def get_title(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('title', '@R BOTS')

    async def set_title(self, user_id, title):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'title': title}})

    async def get_author(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('author', '[@R BOTS]')

    async def set_author(self, user_id, author):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'author': author}})

    async def get_artist(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('artist', '[@R BOTS]')

    async def set_artist(self, user_id, artist):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'artist': artist}})

    async def get_audio(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('audio', '[@R BOTS]')

    async def set_audio(self, user_id, audio):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'audio': audio}})

    async def get_subtitle(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('subtitle', "[@R BOTS]")

    async def set_subtitle(self, user_id, subtitle):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'subtitle': subtitle}})

    async def get_video(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('video', '[@R BOTS]')

    async def set_video(self, user_id, video):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'video': video}})

    async def get_encoded_by(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('encoded_by', "@R BOTS [RAVI]")

    async def set_encoded_by(self, user_id, encoded_by):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'encoded_by': encoded_by}})
        
    async def get_custom_tag(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('custom_tag', "[@R BOTS]")

    async def set_custom_tag(self, user_id, custom_tag):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'custom_tag': custom_tag}})

    async def get_commentz(self, user_id):
        user = await self.col.find_one({'_id': int(user_id)})
        return user.get('commentz', "[@R BOTS]")

    async def set_commentz(self, user_id, commentz):
        await self.col.update_one({'_id': int(user_id)}, {'$set': {'commentz': custom_tag}})
    async def set_all_metadata(self, user_id, metadata_value):
        """Set all metadata fields to the same value"""
        await self.col.update_one(
            {'_id': int(user_id)},
            {'$set': {
                'title': metadata_value,
                'author': metadata_value,
                'artist': metadata_value,
                'audio': metadata_value,
                'video': metadata_value,
                'subtitle': metadata_value,
                'encoded_by': metadata_value,
                'custom_tag': metadata_value,
                'commentz': metadata_value
            }}
        )

    # In your helper/database.py file, add these functions:
    
# In helper/database.py

    async def set_sorting_mode(self, user_id, mode):
        """Set user's sorting mode preference"""
        await self.col.update_one(
            {"_id": user_id},
            {"$set": {"sorting_mode": mode}},
            upsert=True
        )
    
    async def get_sorting_mode(self, user_id):
        """Get user's sorting mode preference"""
        user_data = await self.col.find_one({"_id": user_id})
        return user_data.get("sorting_mode") if user_data else None

    # Add these methods to your Database class:


    async def increment_rename_count(self, user_id: int):
        """Increment rename count for a user - FIXED VERSION"""
        try:
            result = await self.col.update_one(
                {"_id": user_id},
                {"$inc": {"rename_count": 1}},
                upsert=True
            )
            return result.modified_count > 0
        except Exception as e:
            logging.error(f"Error incrementing rename count for user {user_id}: {e}")
            return False
    async def increment_sort_count(self, user_id: int, increment: int = 1):
        """Increment the sequence/sort count for a user - FIXED VERSION"""
        try:
            result = await self.col.update_one(
                {"_id": user_id},
                {"$inc": {"sort_count": increment, "sequence_count": 1}},
                upsert=True
            )
            return result.modified_count > 0
        except Exception as e:
            logging.error(f"Error incrementing sort count for user {user_id}: {e}")
            return False
    
    async def increment_files_processed_count(self, user_id: int, count: int = 1):
        """Increment files processed count for a user - FIXED VERSION"""
        try:
            result = await self.col.update_one(
                {"_id": user_id},
                {"$inc": {"files_processed_count": count}},
                upsert=True
            )
            return result.modified_count > 0
        except Exception as e:
            logging.error(f"Error incrementing files processed count for user {user_id}: {e}")
            return False

    async def get_sort_count(self, user_id: int):
        """Get sort count for a user"""
        user = await self.col.find_one({"_id": user_id})
        return user.get("sort_count", 0) if user else 0
    
    async def get_files_processed_count(self, user_id: int):
        """Get files processed count for a user"""
        user = await self.col.find_one({"_id": user_id})
        return user.get("files_processed_count", 0) if user else 0
        
    async def add_rename_log_entry(self, user_id: int, original_name: str, renamed_name: str, 
                                  file_size: int = 0, is_sequence_file: bool = False):
        """Add a rename log entry with sequence file support - FIXED VERSION"""
        try:
            # Check if this rename already exists to prevent double counting
            existing_log = await self.rename_logs.find_one({
                "user_id": user_id,
                "original_name": original_name,
                "renamed_name": renamed_name,
                "timestamp": {
                    "$gte": datetime.now() - timedelta(minutes=5)  # Within last 5 minutes
                }
            })
            
            if not existing_log:
                await self.rename_logs.insert_one({
                    "user_id": user_id,
                    "type": "rename",
                    "original_name": original_name,
                    "renamed_name": renamed_name,
                    "file_size": file_size,
                    "is_sequence_file": is_sequence_file,  # Added this field
                    "timestamp": datetime.now()
                })
                logging.info(f"Logged rename for user {user_id}: {original_name} -> {renamed_name} (sequence: {is_sequence_file})")
            else:
                logging.warning(f"Duplicate rename detected for user {user_id}, skipping log")
        except Exception as e:
            logging.error(f"Error adding rename log for user {user_id}: {e}")

# In all methods, use datetime.now() instead of datetime.datetime.now()

    async def get_user_rename_stats(self, user_id: int, time_filter: str = "lifetime"):
        """Get accurate user rename statistics without double counting"""
        date_filter = self._get_date_filter(datetime.now(), time_filter)
        match_filter = {"user_id": user_id, "type": "rename"}
        
        if date_filter:
            match_filter["timestamp"] = date_filter
        
        pipeline = [
            {"$match": match_filter},
            {"$group": {
                "_id": "$user_id",
                "rename_count": {"$sum": 1},
                "total_size": {"$sum": "$file_size"},
                "max_file_size": {"$max": "$file_size"}
            }}
        ]
        
        result = await self.rename_logs.aggregate(pipeline).to_list(length=1)
        return result[0] if result else {"rename_count": 0, "total_size": 0, "max_file_size": 0}
    async def get_user_sort_stats(self, user_id: int, time_filter: dict = None):
        """Get user's sort statistics for a time period"""
        match_filter = {"user_id": user_id, "type": "sort"}
        if time_filter:
            match_filter["timestamp"] = time_filter
        
        pipeline = [
            {"$match": match_filter},
            {"$group": {
                "_id": "$user_id",
                "sort_count": {"$sum": 1},
                "files_sorted": {"$sum": "$file_count"}
            }}
        ]
        
        result = await self.rename_logs.aggregate(pipeline).to_list(length=1)
        return result[0] if result else {"sort_count": 0, "files_sorted": 0}

    # new file_rename 

    # In all methods, use datetime.now() instead of datetime.datetime.now()

    async def add_sort_log_entry(self, user_id: int, file_count: int):
        """Add a log entry for sorting operation - FIXED VERSION"""
        try:
            await self.sort_logs.insert_one({
                "user_id": user_id,
                "file_count": file_count,
                "timestamp": datetime.now(),
                "type": "sequence_sort"
            })
            logging.info(f"Sort log added for user {user_id}: {file_count} files")
        except Exception as e:
            logging.error(f"Error adding sort log for user {user_id}: {e}")


    async def add_sorted_history(self, user_id: int, file_count: int):
        """Add to user's sorted files history - FIXED VERSION"""
        try:
            # Check recent sequence to prevent double counting
            recent_sequence = await self.sequence_logs.find_one({
                "user_id": user_id,
                "timestamp": {
                    "$gte": datetime.now() - timedelta(minutes=5)  # Within last 5 minutes
                }
            })
            
            if not recent_sequence:
                await self.sequence_logs.insert_one({
                    "user_id": user_id,
                    "file_count": file_count,
                    "timestamp": datetime.now()
                })
                
                # Update user's total sorted count
                await self.col.update_one(
                    {"_id": user_id},
                    {
                        "$inc": {"sorted_count": file_count, "sequence_count": 1},
                        "$set": {"last_sorted": datetime.now()}
                    },
                    upsert=True
                )
                logging.info(f"Logged sequence for user {user_id} with {file_count} files")
            else:
                logging.warning(f"Duplicate sequence detected for user {user_id}, skipping")
        except Exception as e:
            logging.error(f"Error adding sorted history for user {user_id}: {e}")
    async def get_leaderboard_renames(self, limit: int = 10, time_filter: str = "lifetime"):
        """Get top users by rename count - FIXED VERSION"""
        try:
            now = datetime.now()
            date_filter = self._get_date_filter(now, time_filter)
            
            if date_filter:
                # Aggregate from rename logs for accurate time-filtered data
                pipeline = [
                    {"$match": {"timestamp": date_filter, "type": "rename", "is_sequence_file": False}},
                    {"$group": {
                        "_id": "$user_id",
                        "rename_count": {"$sum": 1},
                        "total_size": {"$sum": "$file_size"}
                    }},
                    {"$sort": {"rename_count": -1}},
                    {"$limit": limit}
                ]
                result = await self.rename_logs.aggregate(pipeline).to_list(length=limit)
            else:
                # For lifetime, use the user collection count (already aggregated)
                pipeline = [
                    {"$match": {"rename_count": {"$gt": 0}}},
                    {"$project": {
                        "_id": 1,
                        "rename_count": 1,
                        "total_size": "$total_renamed_size"
                    }},
                    {"$sort": {"rename_count": -1}},
                    {"$limit": limit}
                ]
                result = await self.col.aggregate(pipeline).to_list(length=limit)
            
            return result or []
        except Exception as e:
            logging.error(f"Error getting leaderboard renames: {e}")
            return []
    
    async def get_leaderboard_sorted(self, limit: int = 10, time_filter: str = "lifetime"):
        """Get top users by sorted count - FIXED VERSION"""
        try:
            now = datetime.now()
            date_filter = self._get_date_filter(now, time_filter)
            
            if date_filter:
                # For time-filtered sorted files, aggregate from sequence logs
                pipeline = [
                    {"$match": {"timestamp": date_filter}},
                    {"$group": {
                        "_id": "$user_id",
                        "sorted_count": {"$sum": "$file_count"},
                        "sequence_count": {"$sum": 1}
                    }},
                    {"$sort": {"sorted_count": -1}},
                    {"$limit": limit}
                ]
                result = await self.sequence_logs.aggregate(pipeline).to_list(length=limit)
            else:
                # For lifetime, use the user collection
                pipeline = [
                    {"$match": {"sort_count": {"$gt": 0}}},
                    {"$project": {
                        "_id": 1,
                        "sorted_count": "$files_processed_count",
                        "sequence_count": "$sort_count"
                    }},
                    {"$sort": {"sorted_count": -1}},
                    {"$limit": limit}
                ]
                result = await self.col.aggregate(pipeline).to_list(length=limit)
            
            return result or []
        except Exception as e:
            logging.error(f"Error getting leaderboard sorted: {e}")
            return []
    
    def _get_date_filter(self, now, time_filter):
        """Helper method to get date filter - FIXED VERSION"""
        try:
            if time_filter == "today":
                start_of_day = datetime(now.year, now.month, now.day)
                return {"$gte": start_of_day}
            elif time_filter == "week":
                start_of_week = now - timedelta(days=now.weekday())
                start_of_week = datetime(start_of_week.year, start_of_week.month, start_of_week.day)
                return {"$gte": start_of_week}
            elif time_filter == "month":
                start_of_month = datetime(now.year, now.month, 1)
                return {"$gte": start_of_month}
            elif time_filter == "year":
                start_of_year = datetime(now.year, 1, 1)
                return {"$gte": start_of_year}
            return None
        except Exception as e:
            logging.error(f"Error creating date filter: {e}")
            return None
    # Add to your existing Database class in database.py
    
    # ✅ ADD THESE METHODS TO YOUR EXISTING Database CLASS
    
    async def set_renaming_mode(self, user_id: int, mode: str):
        """Set user's renaming mode preference"""
        valid_modes = ["autorename", "manual", "replace"]
        if mode not in valid_modes:
            mode = "autorename"  # Default fallback
        
        await self.col.update_one(
            {"_id": user_id},
            {"$set": {"renaming_mode": mode}},
            upsert=True
        )
    
    async def get_renaming_mode(self, user_id: int):
        """Get user's renaming mode preference"""
        user_data = await self.col.find_one({"_id": user_id})
        return user_data.get("renaming_mode", "autorename") if user_data else "autorename"
    
    async def set_replace_pattern(self, user_id: int, old_text: str, new_text: str):
        """Set replace pattern for replace mode"""
        await self.col.update_one(
            {"_id": user_id},
            {"$set": {
                "replace_old": old_text,
                "replace_new": new_text
            }},
            upsert=True
        )
    
    async def get_replace_pattern(self, user_id: int):
        """Get replace pattern for replace mode"""
        user_data = await self.col.find_one({"_id": user_id})
        if user_data:
            return user_data.get("replace_old"), user_data.get("replace_new")
        return None, None
    
    async def log_manual_rename(self, user_id: int, original_name: str, manual_name: str):
        """Log manual rename operations"""
        await self.rename_logs.insert_one({
            "user_id": user_id,
            "type": "manual_rename",
            "original_name": original_name,
            "manual_name": manual_name,
            "timestamp": datetime.now()
        })

    async def set_pdf_lock_password(self, user_id, password):
        await self.col.update_one({"_id": user_id}, {"$set": {"pdf_lock_password": password}}, upsert=True)

    async def get_pdf_lock_password(self, user_id):
        user = await self.col.find_one({"_id": user_id})
        return user.get("pdf_lock_password") if user else None

    async def set_pdf_banner(self, user_id, file_id):
        await self.col.update_one({"_id": int(user_id)}, {"$set": {"pdf_banner": file_id}}, upsert=True)

    async def get_pdf_banner(self, user_id):
        user = await self.col.find_one({"_id": int(user_id)})
        return user.get("pdf_banner") if user else None

    async def set_metadata_source(self, user_id, source):
        await self.col.update_one({"_id": int(user_id)}, {"$set": {"metadata_source": source}}, upsert=True)

    async def get_metadata_source(self, user_id):
        user = await self.col.find_one({"_id": int(user_id)})
        return user.get("metadata_source", "filename") if user else "filename"
    
    async def set_pdf_banner_placement(self, user_id, placement):
        """
        Set the user's default PDF banner placement ('first', 'last', or 'both').
        """
        await self.col.update_one(
            {"_id": int(user_id)},
            {"$set": {"pdf_banner_placement": placement}},
            upsert=True
        )

    async def get_pdf_banner_placement(self, user_id):
        """
        Get the user's default PDF banner placement.
        Returns 'first' if not set.
        """
        user = await self.col.find_one({"_id": int(user_id)})
        return user.get("pdf_banner_placement", "first") if user else "first"

    async def set_pdf_banner_mode(self, user_id, mode: bool):
        await self.col.update_one(
            {"_id": int(user_id)},
            {"$set": {"pdf_banner_mode": bool(mode)}},
            upsert=True
        )

    async def get_pdf_banner_mode(self, user_id):
        user = await self.col.find_one({"_id": int(user_id)})
        return user.get("pdf_banner_mode", False) if user else False

    async def set_pdf_lock_mode(self, user_id, mode: bool):
        await self.col.update_one(
            {"_id": int(user_id)},
            {"$set": {"pdf_lock_mode": bool(mode)}},
            upsert=True
        )

    async def get_pdf_lock_mode(self, user_id):
        user = await self.col.find_one({"_id": int(user_id)})
        return user.get("pdf_lock_mode", False) if user else False


    async def update_last_active(self, user_id: int):
      """Update user's last active timestamp"""
      try:
          await self.col.update_one(
              {"_id": user_id},
              {"$set": {"last_active": datetime.now()}},
              upsert=True
          )
      except Exception as e:
          logging.error(f"Error updating last active for user {user_id}: {e}")
  
    async def reset_daily_count(self):
        """Reset daily counts for all users (call this daily)"""
        try:
            await self.col.update_many(
                {},
                {"$set": {"daily_count": 0}}
            )
            logging.info("Daily counts reset successfully")
        except Exception as e:
            logging.error(f"Error resetting daily counts: {e}")
    
    async def get_active_users_count(self, days: int = 30):
        """Get count of active users in the last N days"""
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            count = await self.col.count_documents({
                "last_active": {"$gte": cutoff_date}
            })
            return count
        except Exception as e:
            logging.error(f"Error getting active users count: {e}")
            return 0
    
    async def log_manual_rename(self, user_id: int, original_name: str, manual_name: str):
        """Log manual rename operations - FIXED VERSION"""
        try:
            await self.rename_logs.insert_one({
                "user_id": user_id,
                "type": "manual_rename",
                "original_name": original_name,
                "manual_name": manual_name,
                "timestamp": datetime.now()
            })
            logging.info(f"Manual rename logged for user {user_id}")
        except Exception as e:
            logging.error(f"Error logging manual rename for user {user_id}: {e}")
#------fsub---------

 # CHANNEL MANAGEMENT
    async def channel_exist(self, channel_id: int):
        found = await self.fsub_data.find_one({'_id': channel_id})
        return bool(found)

    async def add_channel(self, channel_id: int):
        if not await self.channel_exist(channel_id):
            await self.fsub_data.insert_one({'_id': channel_id})
            return

    async def rem_channel(self, channel_id: int):
        if await self.channel_exist(channel_id):
            await self.fsub_data.delete_one({'_id': channel_id})
            return

    async def show_channels(self):
        channel_docs = await self.fsub_data.find().to_list(length=None)
        channel_ids = [doc['_id'] for doc in channel_docs]
        return channel_ids

    
# Get current mode of a channel
    async def get_channel_mode(self, channel_id: int):
        data = await self.fsub_data.find_one({'_id': channel_id})
        return data.get("mode", "off") if data else "off"

    # Set mode of a channel
    async def set_channel_mode(self, channel_id: int, mode: str):
        await self.fsub_data.update_one(
            {'_id': channel_id},
            {'$set': {'mode': mode}},
            upsert=True
        )

    # REQUEST FORCE-SUB MANAGEMENT

    # Add the user to the set of users for a   specific channel
    async def req_user(self, channel_id: int, user_id: int):
        try:
            await self.rqst_fsub_Channel_data.update_one(
                {'_id': int(channel_id)},
                {'$addToSet': {'user_ids': int(user_id)}},
                upsert=True
            )
        except Exception as e:
            print(f"[DB ERROR] Failed to add user to request list: {e}")


    # Method 2: Remove a user from the channel set
    async def del_req_user(self, channel_id: int, user_id: int):
        # Remove the user from the set of users for the channel
        await self.rqst_fsub_Channel_data.update_one(
            {'_id': channel_id}, 
            {'$pull': {'user_ids': user_id}}
        )

    # Check if the user exists in the set of the channel's users
    async def req_user_exist(self, channel_id: int, user_id: int):
        try:
            found = await self.rqst_fsub_Channel_data.find_one({
                '_id': int(channel_id),
                'user_ids': int(user_id)
            })
            return bool(found)
        except Exception as e:
            print(f"[DB ERROR] Failed to check request list: {e}")
            return False  


    # Method to check if a channel exists using show_channels
    async def reqChannel_exist(self, channel_id: int):
    # Get the list of all channel IDs from the database
        channel_ids = await self.show_channels()
        #print(f"All channel IDs in the database: {channel_ids}")

    # Check if the given channel_id is in the list of channel IDs
        if channel_id in channel_ids:
            #print(f"Channel {channel_id} found in the database.")
            return True
        else:
            #print(f"Channel {channel_id} NOT found in the database.")
            return False

    async def reset_leaderboard(self):
        """Reset all leaderboard statistics"""
        try:
            # Reset user counts
            user_reset = await self.col.update_many(
                {},
                {
                    "$set": {
                        "rename_count": 0,
                        "files_processed_count": 0, 
                        "total_renamed_size": 0,
                        "max_file_size": 0,
                        "daily_count": 0,
                        "sorted_count": 0,
                        "sequence_count": 0
                    }
                }
            )
            
            # Clear logs
            rename_logs = await self.rename_logs.delete_many({})
            sequence_logs = await self.sequence_logs.delete_many({})
            
            return {
                "users_modified": user_reset.modified_count,
                "rename_logs_deleted": rename_logs.deleted_count,
                "sequence_logs_deleted": sequence_logs.deleted_count
            }
            
        except Exception as e:
            logger.error(f"Database reset_leaderboard error: {e}")
            raise
DARKXSIDE78 = Database(Config.DB_URL, Config.DB_NAME)
