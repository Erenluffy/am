import os
import re
import math
import time
import asyncio
import logging
import shutil
from pyrogram.enums import ChatMemberStatus
from pyrogram.errors.exceptions.bad_request_400 import UserNotParticipant
from pyrogram.errors import FloodWait
from datetime import datetime
from pytz import timezone
from config import Config , Txt 
from pyrogram import Client, filters
from pyrogram.errors import FloodWait
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message, CallbackQuery
from helper.database import DARKXSIDE78 as db

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

FORCE_MSG = os.environ.get("FORCE_SUB_MESSAGE", "ʜᴇʟʟᴏ {first}\n\n<b>ᴊᴏɪɴ ᴏᴜʀ ᴄʜᴀɴɴᴇʟs ᴀɴᴅ ᴛʜᴇɴ ᴄʟɪᴄᴋ ᴏɴ ʀᴇʟᴏᴀᴅ button.</b>")
FORCE_PIC   = os.environ.get("FORCE_PIC", "https://files.catbox.moe/3mtgb2.jpg")

ADMIN_USER_ID = Config.ADMIN
OWNER_ID = ADMIN_USER_ID

__all__ = [
    'progress_for_pyrogram',
    'humanbytes',
    'convert',
    'TimeFormatter',
    'handle_floodwait',
    'add_prefix_suffix',
    'safe_delete',
    'send_log',
    'is_subscribed',
    'not_joined'
]

LAST_UPDATE_TIMES = {}
USER_SEMAPHORES = {}

max_retries = Config.FLOODWAIT_RETRIES
initial_wait = Config.FLOODWAIT_WAIT

def handle_floodwait():
    def decorator(func):
        async def wrapper(*args, **kwargs):
            retries = 0
            wait_time = initial_wait
            while retries < max_retries:
                try:
                    return await func(*args, **kwargs)
                except FloodWait as e:
                    wait = min(e.value + 2, 60)
                    logger.warning(f"FloodWait: Sleeping {wait}s (Attempt {retries+1}/{max_retries})")
                    await asyncio.sleep(wait)
                    retries += 1
                    wait_time *= 1.5
            raise Exception(f"Max retries ({max_retries}) reached for FloodWait")
        return wrapper
    return decorator

async def progress_for_pyrogram(current, total, ud_type, message, start):
    now = time.time()
    message_id = message.id
    last_update = LAST_UPDATE_TIMES.get(message_id, 0)

    if current == total or (now - last_update >= Config.UPDATE_TIME):
        percentage = current * 100 / total
        speed = current / (now - start) if (now - start) > 0 else 0

        progress = "".join(
            "●" if i < math.floor(percentage / 5) else "○" 
            for i in range(20)
        )

        if speed > 0:
            eta_seconds = (total - current) / speed
            eta_formatted = TimeFormatter(eta_seconds * 1000)
        else:
            eta_formatted = "0s"

        progress_text = Txt.PROGRESS_BAR.format(
            round(percentage, 2),
            humanbytes(current),
            humanbytes(total),
            humanbytes(speed),
            eta_formatted
        )

        tmp = f"{progress}\n{progress_text}"

        try:
            user_id = message.chat.id
            semaphore = USER_SEMAPHORES.setdefault(user_id, asyncio.Semaphore(1))
            async with semaphore:
                await message.edit(
                    text=f"{ud_type}\n\n{tmp}",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("Cᴀɴᴄᴇʟ", callback_data="close")
                    ]])
                )
                LAST_UPDATE_TIMES[message_id] = now

                if current == total:
                    await asyncio.sleep(Config.PAUSE_AFTER_COMPLETE)

        except FloodWait as e:
            await asyncio.sleep(e.value + 1)
            LAST_UPDATE_TIMES[message_id] = now + e.value + 1
        except Exception as e:
            logger.error(f"Progress update error: {e}", exc_info=True)
        finally:
            if current == total:
                LAST_UPDATE_TIMES.pop(message_id, None)

def humanbytes(size: int) -> str:
    if not size:
        return "0 B"
    
    units = ["B", "KB", "MB", "GB", "TB"]
    unit_index = 0
    
    while size >= 1024 and unit_index < len(units)-1:
        size /= 1024
        unit_index += 1
        
    return f"{size:.2f} {units[unit_index]}"

def TimeFormatter(milliseconds: int) -> str:
    seconds, milliseconds = divmod(int(milliseconds), 1000)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    
    if hours > 0:
        return f"{hours}h {minutes}m {seconds}s"
    elif minutes > 0:
        return f"{minutes}m {seconds}s"
    elif seconds > 0:
        return f"{seconds}s"
    return f"{milliseconds}ms"

def convert(seconds: int) -> str:
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60
    return f"{hour:02d}:{minutes:02d}:{seconds:02d}"

@handle_floodwait()
async def send_log(bot, user):
    if not Config.LOG_CHANNEL:
        return
        
    try:
        curr = datetime.now(timezone("Asia/Kolkata"))
        await bot.send_message(
            Config.LOG_CHANNEL,
            f"**Nᴇᴡ Usᴇʀ Aᴄᴛɪᴠɪᴛʏ**\n\n"
            f"**➤ Usᴇʀ: {user.mention}**\n"
            f"**➤ ID: `{user.id}`**\n"
            f"**➤ Usᴇʀɴᴀᴍᴇ: @{user.username if user.username else 'N/A'}**\n\n"
            f"**➤ Dᴀᴛᴇ: {curr.strftime('%d %B, %Y')}**\n"
            f"**➤ Tɪᴍᴇ: {curr.strftime('%I:%M:%S %p')}**\n\n"
            f"**➤ Bᴏᴛ: {bot.mention}**",
            disable_web_page_preview=True
        )
    except Exception as e:
        logger.error(f"Logging error: {e}", exc_info=True)

def add_prefix_suffix(input_string, prefix='', suffix=''):
    pattern = r'(?P<filename>.*?)(\.\w+)?$'
    match = re.search(pattern, input_string)
    if match:
        filename = match.group('filename')
        extension = match.group(2) or ''
        return f"{prefix}{filename}{suffix}{extension}"
    return input_string

async def safe_delete(*paths):
    for path in paths:
        try:
            if path and os.path.exists(path):
                if os.path.isfile(path):
                    os.remove(path)
                else:
                    shutil.rmtree(path)
        except Exception as e:
            logger.error(f"Error deleting {path}: {e}")

#-------forcesub--------

async def is_subscribed(client, user_id):
    """Check if user is subscribed to all required channels"""
    try:
        channels = await db.show_channels()
        if not channels:
            return True
        
        for channel_id in channels:
            try:
                # Check if channel mode is on
                channel_mode = await db.get_channel_mode(channel_id)
                if channel_mode == "off":
                    continue
                    
                # Check if user is member of the channel
                member = await client.get_chat_member(channel_id, user_id)
                if member.status in [ChatMemberStatus.LEFT, ChatMemberStatus.BANNED]:
                    return False
            except UserNotParticipant:
                return False
            except Exception as e:
                logger.error(f"Error checking subscription for channel {channel_id}: {e}")
                return False
        
        return True
    except Exception as e:
        logger.error(f"Error in is_subscribed: {e}")
        return False

async def not_joined(client, message):
    """Check if user needs to join channels and show force sub message if needed"""
    try:
        channels = await db.show_channels()
        if not channels:
            return True

        # Check if user is already subscribed to all required channels
        if await is_subscribed(client, message.from_user.id):
            return True

        buttons = []
        active_channels = 0
        for channel_id in channels:
            try:
                # Check if channel mode is on
                channel_mode = await db.get_channel_mode(channel_id)
                if channel_mode == "off":
                    continue
                    
                chat = await client.get_chat(channel_id)
                if chat.username:
                    url = f"https://t.me/{chat.username}"
                else:
                    url = f"https://t.me/c/{str(channel_id)[4:]}"
                buttons.append([InlineKeyboardButton(text=chat.title, url=url)])
                active_channels += 1
            except Exception as e:
                logger.error(f"Error getting chat {channel_id}: {e}")
                continue

        # If no active channels found, return True
        if active_channels == 0:
            return True

        buttons.append([InlineKeyboardButton(text='♻️ Reload', callback_data='reload')])
        
        try:
            await message.reply_photo(
                photo=FORCE_PIC,
                caption=FORCE_MSG.format(first=message.from_user.first_name),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except:
            await message.reply_text(
                text=FORCE_MSG.format(first=message.from_user.first_name),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        return False
    except Exception as e:
        logger.error(f"Error in not_joined: {e}")
        return True

@Client.on_callback_query(filters.regex("^reload$"))
async def reload_callback(client, query: CallbackQuery):
    """Handle reload callback for force subscription check"""
    user = query.from_user
    
    # Edit the message to show "Checking..." status
    try:
        await query.message.edit_caption(
            caption="🔄 Checking subscription status..."
        )
    except:
        try:
            await query.message.edit_text(
                text="🔄 Checking subscription status..."
            )
        except Exception as e:
            logger.error(f"Error editing reload message: {e}")
            await query.answer("Error checking status", show_alert=True)
            return
    
    # Check if user is now subscribed
    if await is_subscribed(client, user.id):
        try:
            await query.message.edit_caption(
                caption=f"✅ Thanks {user.mention}, you are now subscribed!\n\nTap /start to continue."
            )
        except:
            await query.message.edit_text(
                text=f"✅ Thanks {user.mention}, you are now subscribed!\n\nTap /start to continue."
            )
    else:
        # User still not subscribed, show the force sub message again
        channels = await db.show_channels()
        buttons = []
        active_channels = 0
        
        for channel_id in channels:
            try:
                # Check if channel mode is on
                channel_mode = await db.get_channel_mode(channel_id)
                if channel_mode == "off":
                    continue
                    
                chat = await client.get_chat(channel_id)
                if chat.username:
                    url = f"https://t.me/{chat.username}"
                else:
                    url = f"https://t.me/c/{str(channel_id)[4:]}"
                buttons.append([InlineKeyboardButton(text=chat.title, url=url)])
                active_channels += 1
            except Exception as e:
                logger.error(f"Error getting chat {channel_id} for reload: {e}")
                continue
        
        # If no active channels, allow access
        if active_channels == 0:
            try:
                await query.message.edit_caption(
                    caption=f"✅ Thanks {user.mention}, you can now continue!\n\nTap /start to continue."
                )
            except:
                await query.message.edit_text(
                    text=f"✅ Thanks {user.mention}, you can now continue!\n\nTap /start to continue."
                )
            return
        
        buttons.append([InlineKeyboardButton(text='♻️ Reload', callback_data='reload')])
        
        try:
            await query.message.edit_caption(
                caption=FORCE_MSG.format(first=user.first_name),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        except:
            await query.message.edit_text(
                text=FORCE_MSG.format(first=user.first_name),
                reply_markup=InlineKeyboardMarkup(buttons)
            )
        
        await query.answer(
            "❌ You still haven't joined all required channels!",
            show_alert=True
        )
